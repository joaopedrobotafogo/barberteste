# BarberFlow (nome provisório)

SaaS multi-tenant de gestão para barbearias. Next.js 15 (App Router) + TypeScript + Tailwind 3 + Supabase (Postgres, Auth, RLS).

## Status

- [x] Etapa 1 - Banco: schema, RLS, regras de agenda (`supabase/migrations/0001_core_schema.sql`)
- [x] Etapa 2 - App base, autenticação, layout, permissões, Serviços, Equipe + convite (convite validado pelo usuário)
- [x] Etapa 3 - Clientes: lista (busca, filtros, ordenação, paginação), cadastro/edição e perfil com histórico  **(escrita; precisa de typecheck/build/teste local)**
- [x] Etapa 4 - Agenda: dia/semana, novo agendamento, edição/remarcação, status, cancelamento, bloqueios, conflito de horário  **(escrita; precisa de typecheck/build/teste local)**
- [x] Etapa 5 - Início (Dashboard)
- [x] Etapa 6 - Financeiro
- [x] Etapa 7 - Relatórios
- [x] Etapa 8 - Configurações (nome, horário de funcionamento, regras de agenda e de clientes)
- [ ] Pendente - Seed de demonstração e testes de RLS/conflito

## Rodar localmente

```bash
npm install
cp .env.example .env.local     # preencha as variáveis
npm run dev                    # http://localhost:3000
npm run typecheck && npm run lint && npm run build
```

### Variáveis de ambiente

| Variável | Onde | Uso |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | cliente + servidor | URL do projeto |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | cliente + servidor | chave anon (sujeita à RLS) |
| `SUPABASE_SERVICE_ROLE_KEY` | **somente servidor** | usada só em `inviteBarber` e para ler o status do convite na página Equipe |
| `NEXT_PUBLIC_SITE_URL` | servidor | base dos links de e-mail (local: `http://localhost:3000`; Vercel: URL de produção) |

Na Vercel, cadastre as 4 variáveis. Nunca exponha a service role com prefixo `NEXT_PUBLIC_`.

## Configuração obrigatória no Supabase

1. Rode `supabase/migrations/0001_core_schema.sql` (SQL Editor ou `supabase db push`).
2. **Authentication > URL Configuration**: `Site URL` = sua URL; em `Redirect URLs` adicione `http://localhost:3000/auth/callback` e a URL de produção `/auth/callback`.
3. **Authentication > Email Templates** (necessário para convite e recuperação de senha, pois o link precisa chegar ao servidor):
   - *Invite user*: `<a href="{{ .SiteURL }}/auth/callback?token_hash={{ .TokenHash }}&type=invite&next=/nova-senha">Criar minha senha</a>`
   - *Reset password*: `<a href="{{ .SiteURL }}/auth/callback?token_hash={{ .TokenHash }}&type=recovery&next=/nova-senha">Criar nova senha</a>`
   - *Confirm signup*: `<a href="{{ .SiteURL }}/auth/callback?token_hash={{ .TokenHash }}&type=email">Confirmar e-mail</a>`
4. Em Authentication > Providers > Email, "Confirm email" pode ficar ligado ou desligado; os dois caminhos são tratados.

## Como funciona (Etapa 2)

- **Cadastro**: `signUp` guarda nome da barbearia/dono/telefone no `user_metadata`. No primeiro acesso autenticado, `getContext()` chama a função `create_organization_with_owner` do banco (nenhuma lógica duplicada no front). Funciona com e sem confirmação de e-mail.
- **Sessão e rotas privadas**: `src/middleware.ts` renova a sessão e usa `getUser()` (validado no servidor). Públicas: `/login`, `/cadastro`, `/esqueci-senha`, `/auth/*`.
- **Permissões**: `requireOwner()` nas páginas/actions de Serviços, Equipe, Financeiro, Relatórios e Configurações; o menu esconde o que o BARBER não acessa. A proteção real continua sendo a RLS (`*_write` das tabelas `services` e `barbers` exige owner).
- **Convite de barbeiro** (`equipe/actions.ts → inviteBarber`): dono cria o barbeiro com e-mail -> `auth.admin.inviteUserByEmail` -> insere `profiles` (role `barber`, organização do dono) -> preenche `barbers.profile_id`. Falha em qualquer passo remove o usuário criado. O barbeiro abre o link, cria a senha em `/nova-senha` e já entra na barbearia certa.
- **Barbeiro desativado** (`is_active = false`) é bloqueado no login do app (`/sem-barbearia?motivo=inativo`).

## Notas e limitações conhecidas

- RLS atual deixa o BARBER **ler** a agenda e os clientes de toda a organização (o schema da Etapa 1 não restringe por barbeiro). "Ver só a agenda dele" será filtro de interface na Etapa 4; restringir no banco exigiria alterar policies (decisão pendente).
- BARBER consegue **ler** `barbers`/`profiles` da própria organização via API (necessário para agendar). A página Equipe fica oculta para ele, mas isso é UX, não segredo.
- Foto do barbeiro: o campo `photo_url` é exibido se existir, mas não há upload (exigiria Supabase Storage; fica para depois).
- Notificações: ícone no header desativado (sem tabela/fonte de dados no schema).
- Desativar barbeiro bloqueia o acesso ao app, mas não revoga a sessão já aberta até ela renovar.

## Não testado (sem rede/npm neste ambiente)

Nada foi instalado, compilado nem executado. Só foi feita checagem de sintaxe TypeScript (sem erros de sintaxe). Antes de seguir, rode `npm install`, `npm run typecheck`, `npm run lint`, `npm run build` e teste manualmente: cadastro, login, recuperação de senha, CRUD de serviços, CRUD de equipe, convite e reenvio (comportamento de `inviteUserByEmail` em usuário ainda não confirmado), login do barbeiro convidado e bloqueio de rotas de dono.

## Etapa 3 - Clientes (notas)

- Lista e perfil leem a view `client_overview` (status, VIP, visitas, total gasto, ticket médio e último atendimento são calculados no banco, só de atendimentos **concluídos**). Os limites de "em risco"/"perdido"/VIP vêm de `business_settings` (padrão: 30/60 dias, 10 visitas ou R$ 500); essas regras são editadas em Configurações (Etapa 8).
- Filtros: Todos, Ativos, Em risco, Perdidos, VIP. Cliente sem atendimento concluído tem status "Novo" e aparece só em "Todos".
- Telefone é único por barbearia (ignorando formatação). Duplicado mostra o nome do cliente existente.
- Barbeiro e dono podem criar/editar clientes (RLS `clients_all`). Não há exclusão de cliente nesta etapa.
- O histórico mostra todos os status (concluído, confirmado, aguardando, cancelado, no-show) e só passa a ter dados na Etapa 4. O botão "Agendar" fica desabilitado até lá.

## Etapa 4 - Agenda (notas)

- `/agenda?view=dia|semana&date=YYYY-MM-DD&barber=<id>`. Horários são exibidos no fuso de `business_settings.timezone` e gravados em UTC (`src/lib/agenda.ts`).
- **Conflito**: garantido pelo banco (constraint `appointments_no_overlap` + triggers de bloqueio). A tela só oferece horários livres (`getSlots`, que considera expediente, intervalo, antecedência mínima, agendamentos e bloqueios) e traduz o erro do banco se houver corrida entre dois usuários.
- **Duração**: vem do serviço; `end_at = start_at + duração`. Ao editar/remarcar é recalculada.
- **Valor**: preenchido pelo serviço, editável.
- **Status**: confirmar, concluir (gera o pagamento via trigger), no-show, cancelar (mantém o registro) e reabrir.
- **Encaixe**: só aparece se `allow_overbooking = true` (liga/desliga em Configurações > Agenda).
- **BARBER**: vê e usa só a própria agenda (filtro de interface + validação nas actions). A RLS ainda permite leitura da organização toda.
- **Novo cliente** pode ser criado dentro do agendamento. Se o agendamento falhar depois, o cliente criado permanece.
- Perfil do cliente > "Agendar" abre a agenda já com o cliente selecionado.
- **Preparação para IA**: `computeSlots` é função pura e `getSlots` é a lógica de `get_available_slots()`; criar/cancelar/remarcar usam as mesmas tabelas e regras.

## Etapa 6 - Financeiro (notas)

- `/financeiro?periodo=hoje|7d|30d|mes&pag=N` (só OWNER, via `requireOwner()`; padrão: Este mês). Códigos: `src/lib/finance.ts` (consultas), `src/components/finance.tsx` (telas), `src/app/(app)/financeiro/page.tsx`.
- **Fonte do faturamento**: tabela `payments` (ativos, `deleted_at is null`, da organização), criada pelo trigger `appointments_sync_payment` ao concluir o atendimento. Nenhuma lógica de pagamento nova. Cancelar, marcar no-show ou reabrir anula o pagamento (soft delete pelo trigger) e ele sai dos totais; agendamentos não concluídos nunca entram.
- **Data do faturamento**: `paid_at` (momento em que o atendimento foi concluído), igual ao Dashboard. Períodos usam o fuso de `business_settings.timezone`: Hoje; 7 dias = hoje e os 6 anteriores; 30 dias = hoje e os 29 anteriores; Este mês = dia 1 até hoje.
- Uma consulta agregada de pagamentos (paginada em blocos de 1.000 por causa do limite do PostgREST) + consultas pequenas de nomes. Totais, dia, serviço, barbeiro e clientes únicos são calculados em memória, em centavos.
- Serviço e barbeiro vêm das colunas copiadas para `payments` no momento da conclusão. Sem biblioteca de gráficos (barras em CSS).

## Etapa 7 - Relatórios (notas)

- `/relatorios?periodo=hoje|7d|30d|mes` (só OWNER, `requireOwner()`; padrão: Este mês). Código: `src/lib/reports.ts`, `src/components/reports.tsx`, `src/app/(app)/relatorios/page.tsx`.
- **Faturamento, atendimentos, ticket médio, evolução, serviços e equipe** usam `loadRevenueBase()` de `src/lib/finance.ts`, a mesma consulta do Financeiro (mesmos números). Serviços e equipe são ordenados por quantidade de atendimentos (desempate por faturamento).
- **Clientes novos** = `clients.created_at` dentro do período (mesma definição do Dashboard). **Recorrentes** = clientes atendidos (com pagamento) no período que têm 2+ atendimentos concluídos (`client_overview.visits`).
- **Clientes que não retornaram** = `client_overview.status` em `at_risk`/`lost` (regra centralizada no banco, limites de `business_settings`). Mostra a situação atual, independente do período.
- Sem comparação com o período anterior (ver notas da entrega).

## Etapa 8 - Configurações (notas)

- `/configuracoes` (só OWNER, `requireOwner()`). Código: `src/lib/settings.ts` (tipos, opções, leitura e validação), `src/app/(app)/configuracoes/actions.ts` (4 ações) e `src/components/settings.tsx` (4 seções, cada uma com o próprio botão Salvar).
- **Seções**: Barbearia (`organizations.name`); Horário de funcionamento (`opening_hours` por dia + `timezone`); Agenda (`slot_interval_minutes`, `min_notice_minutes`, `allow_overbooking`); Clientes (`risk_after_days`, `lost_after_days`, `vip_min_visits`, `vip_min_spent`).
- Não há migration nova. Cada ação grava em uma única tabela, filtrando por `organization_id` da sessão. A RLS (`settings_update`, `org_update`) exige owner. A validação roda no servidor (`validate*` em `settings.ts`) e espelha os `check` do banco (ex.: `lost_after_days > risk_after_days`, fechamento depois da abertura, ao menos um dia aberto).
- Os formulários usam estado controlado: se o servidor devolver erro, o que foi digitado é mantido.
- Salvar revalida o app inteiro (`revalidatePath("/", "layout")`), então Agenda, Início, Clientes e o nome no cabeçalho refletem a mudança. Alterar horário não mexe em agendamentos existentes. Alterar os limites de cliente muda o status de todos na hora (a view calcula em tempo de consulta).
- Fuso: lista fixa de fusos do Brasil (valor atual fora da lista é preservado no seletor).
- **Não exposto de propósito**: `default_duration_minutes` (nenhuma tela o usa hoje; a duração vem do serviço) e pausa de almoço (o schema não tem). Ficam para quando houver consumidor (ex.: IA/WhatsApp).
- O componente provisório `ComingSoon` foi removido (era usado só por esta página).

## Etapa 9 - API de integração para n8n / WhatsApp (notas)

- Documentação completa: **`docs/integration-api.md`** (autenticação, endpoints, erros, fluxo recomendado, testes).
- Endpoints em `src/app/api/integration/*` (business, services, barbers, clients, availability, appointments, appointments/:id, cancel, reschedule). Autenticação por token Bearer **por barbearia**; a organização vem só do token.
- **Núcleo compartilhado**: `src/lib/agenda-core.ts` (configurações, horários livres, tradução de erros do banco). A tela de Agenda (`agenda/actions.ts`, `getSlots`) e a API usam a MESMA função; `computeSlots` continua em `lib/agenda.ts`. O conflito final é do banco (`appointments_no_overlap` + trigger de bloqueios).
- API: `src/lib/integration/` (`auth.ts` token, `ops.ts` operações, `phone.ts` variantes de telefone sobre `phone_normalized`, `validate.ts`, `http.ts`, `route.ts`).
- **Migration pendente (manual)**: `supabase/migrations/0002_integration_tokens.sql` (só cria a tabela `integration_tokens`). Criar token: `supabase/manual/create_integration_token.sql`.
- O middleware deixa `/api/integration/*` passar sem sessão (a rota se protege pelo token).
- Diferente da tela, a API **revalida expediente/antecedência no servidor** antes de gravar (a tela só oferece slots válidos). `saveAppointment` da Agenda não foi alterado.
- Testes de lógica: `npx tsx scripts/test-integration.ts`.

## Etapa 10 — WhatsApp + IA (n8n)

Workflows, prompt e guia de configuração em [`n8n/README.md`](n8n/README.md). Novo endpoint: `GET /api/integration/appointments?phone=…` (ver `docs/integration-api.md`).

## Etapa 11 - Reativação de clientes (notas)

Inteligência de reativação baseada no **ritmo individual** de cada cliente (mediana dos intervalos entre atendimentos concluídos, com tratamento de outliers por MAD), não em "X dias sem vir". Detalhes completos no `CONTEXT.md`.

- **Migration obrigatória (manual):** `supabase/migrations/0003_reactivation.sql` (aditiva; 3 tabelas novas). Sem ela, Configurações mostra aviso e a seção de reativação do Início mostra estado de erro; o resto do app segue normal.
- Dashboard (dono): **Clientes para reativar** com métricas e botão **Reativar** (mobile-first). Página `/reativacao` lista todos. Configurações → **Reativação de clientes** (modo manual/automático e regras).
- API para o n8n: `docs/integration-api.md` seção 8. Workflow: `n8n/barberflow-reactivation.workflow.json` (travado, sem Evolution).
- Testes: `npm run test:reactivation` (70 asserções, banco em memória) e `npm run test:integration` (66, inalterado).
