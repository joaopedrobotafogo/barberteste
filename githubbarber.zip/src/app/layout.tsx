import type { Metadata, Viewport } from "next";
import { Inter } from "next/font/google";
import { cookies } from "next/headers";
import { THEME_COOKIE, themeOrDefault } from "@/lib/theme";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });

export const metadata: Metadata = { title: { default: "BarberFlow", template: "%s · BarberFlow" }, description: "Gestão para barbearias" };
export const viewport: Viewport = { width: "device-width", initialScale: 1, viewportFit: "cover", themeColor: "#F5F9FC" };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // A paleta vem de um cookie (lido no servidor => sem "flash" de cor). A fonte da verdade por usuário é o user_metadata do Supabase.
  const theme = themeOrDefault((await cookies()).get(THEME_COOKIE)?.value);
  return (
    <html lang="pt-BR" className={inter.variable} data-theme={theme}>
      <body className="font-sans">{children}</body>
    </html>
  );
}
