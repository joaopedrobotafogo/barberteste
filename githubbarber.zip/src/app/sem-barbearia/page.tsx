import type { Metadata } from "next";
import { Button, IconCircle } from "@/components/ui";
import { Logo } from "@/components/brand/logo";

export const metadata: Metadata = { title: "Acesso indisponível" };

export default async function NoOrgPage({ searchParams }: { searchParams: Promise<{ motivo?: string }> }) {
  const { motivo } = await searchParams;
  const inactive = motivo === "inativo";
  return (
    <main className="flex min-h-dvh items-center justify-center bg-background px-4 py-10">
      <div className="animate-fade-up w-full max-w-md">
        <div className="mb-8 flex justify-center"><Logo variant="full" height={40} /></div>
        <div className="rounded-3xl border border-border bg-card p-6 text-center shadow-card sm:p-8">
          <div className="mb-4 flex justify-center"><IconCircle name="alert" tone="warning" className="h-14 w-14" iconClass="h-7 w-7" /></div>
          <h1 className="mb-2 text-2xl font-bold tracking-tight">{inactive ? "Acesso desativado" : "Conta sem barbearia"}</h1>
          <p className="mb-8 text-[15px] text-muted">
            {inactive
              ? "O proprietário desativou o seu acesso. Fale com ele para voltar a usar o sistema."
              : "Não encontramos uma barbearia vinculada a esta conta. Se você foi convidado, peça um novo convite ao proprietário."}
          </p>
          <form action="/auth/signout" method="post"><Button variant="secondary" className="w-full">Sair</Button></form>
        </div>
      </div>
    </main>
  );
}
