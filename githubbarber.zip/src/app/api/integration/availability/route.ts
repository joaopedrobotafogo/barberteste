import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { getAvailability } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** GET /api/integration/availability?service_id=...&date=YYYY-MM-DD[&barber_id=...] */
export const GET = integrationRoute("get_availability", async (ctx, req) => {
  const sp = new URL(req.url).searchParams;
  return ok(await getAvailability(ctx, { serviceId: sp.get("service_id"), barberId: sp.get("barber_id"), date: sp.get("date") }));
});
