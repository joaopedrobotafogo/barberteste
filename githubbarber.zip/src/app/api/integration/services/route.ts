import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { listServices } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** GET /api/integration/services — serviços ativos. */
export const GET = integrationRoute("get_services", async (ctx) => ok(await listServices(ctx)));
