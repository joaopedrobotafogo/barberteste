import { integrationRoute } from "@/lib/integration/route";
import { ok, readJson } from "@/lib/integration/http";
import { createClientIdempotent, getClientByPhone } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** GET /api/integration/clients?phone=... — busca por telefone (tolerante a 55). Não cria nada. */
export const GET = integrationRoute("get_client", async (ctx, req) => {
  const phone = new URL(req.url).searchParams.get("phone");
  return ok(await getClientByPhone(ctx, phone));
});

/** POST /api/integration/clients — { name, phone }. Se o telefone já existir, devolve o existente (created:false). */
export const POST = integrationRoute("create_client", async (ctx, req) => {
  const r = await createClientIdempotent(ctx, await readJson(req));
  return ok({ ...r.client, created: r.created }, r.created ? 201 : 200);
});
