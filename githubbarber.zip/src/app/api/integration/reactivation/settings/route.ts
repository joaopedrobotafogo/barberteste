import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiSettings } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** GET /api/integration/reactivation/settings — modo (manual/automático), regras, janela e limite diário restante. */
export const GET = integrationRoute("reactivation_settings", async (ctx) => ok(await apiSettings(ctx)));
