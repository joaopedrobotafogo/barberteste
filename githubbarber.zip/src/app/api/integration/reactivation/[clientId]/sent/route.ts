import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiSent } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** POST /api/integration/reactivation/:clientId/sent — Confirma que a mensagem foi enviada (requested → sent). Idempotente. */
export const POST = integrationRoute<{ clientId: string }>("reactivation_sent", async (ctx, _req, { clientId }) => ok(await apiSent(ctx, clientId)));
