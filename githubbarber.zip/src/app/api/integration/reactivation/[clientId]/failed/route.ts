import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiFailed, readOptionalJson } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** POST /api/integration/reactivation/:clientId/failed — Informa falha no envio (requested → failed); body opcional { reason }. Idempotente. */
export const POST = integrationRoute<{ clientId: string }>("reactivation_failed", async (ctx, req, { clientId }) =>
  ok(await apiFailed(ctx, clientId, await readOptionalJson(req))));
