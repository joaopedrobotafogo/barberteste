import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiTrigger } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** POST /api/integration/reactivation/:clientId/trigger — pedido automático (exige modo automático). Idempotente. */
export const POST = integrationRoute<{ clientId: string }>("reactivation_trigger", async (ctx, _req, { clientId }) => {
  const r = await apiTrigger(ctx, clientId);
  return ok(r.data, r.replay ? 200 : 201);
});
