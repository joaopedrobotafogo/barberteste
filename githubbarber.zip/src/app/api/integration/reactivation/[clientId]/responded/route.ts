import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiResponded } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** POST /api/integration/reactivation/:clientId/responded — Cliente respondeu (sent → responded). Não é agendamento. Idempotente. */
export const POST = integrationRoute<{ clientId: string }>("reactivation_responded", async (ctx, _req, { clientId }) => ok(await apiResponded(ctx, clientId)));
