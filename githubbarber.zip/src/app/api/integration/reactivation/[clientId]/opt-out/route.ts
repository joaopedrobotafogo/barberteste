import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiOptOut, readOptionalJson } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** POST /api/integration/reactivation/:clientId/opt-out — Cliente não quer receber; bloqueia reativações futuras; body opcional { note }. Idempotente. */
export const POST = integrationRoute<{ clientId: string }>("reactivation_opt_out", async (ctx, req, { clientId }) =>
  ok(await apiOptOut(ctx, clientId, await readOptionalJson(req))));
