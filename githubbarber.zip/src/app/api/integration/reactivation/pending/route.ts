import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiPending } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** GET /api/integration/reactivation/pending[?limit=20] — pedidos aguardando envio (só dentro da janela de envio). */
export const GET = integrationRoute("reactivation_pending", async (ctx, req) =>
  ok(await apiPending(ctx, { limit: new URL(req.url).searchParams.get("limit") })));
