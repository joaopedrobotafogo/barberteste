import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { apiCandidates } from "@/lib/reactivation/integration";

export const dynamic = "force-dynamic";

/** GET /api/integration/reactivation/candidates[?limit=20] — candidatos elegíveis agora (já filtrados pelas proteções). */
export const GET = integrationRoute("reactivation_candidates", async (ctx, req) =>
  ok(await apiCandidates(ctx, { limit: new URL(req.url).searchParams.get("limit") })));
