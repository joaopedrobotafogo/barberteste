import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { getBusiness } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** GET /api/integration/business — dados da barbearia, fuso, horário de funcionamento e "agora". */
export const GET = integrationRoute("get_business", async (ctx) => ok(await getBusiness(ctx)));
