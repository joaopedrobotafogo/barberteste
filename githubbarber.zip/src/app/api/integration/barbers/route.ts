import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { listBarbers } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** GET /api/integration/barbers — barbeiros ativos (id e nome). */
export const GET = integrationRoute("get_barbers", async (ctx) => ok(await listBarbers(ctx)));
