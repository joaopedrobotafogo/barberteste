import { integrationRoute } from "@/lib/integration/route";
import { ok } from "@/lib/integration/http";
import { getAppointment } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** GET /api/integration/appointments/:id[?client_id=...|phone=...] — o filtro de cliente é opcional aqui. */
export const GET = integrationRoute<{ id: string }>("get_appointment", async (ctx, req, { id }) => {
  const sp = new URL(req.url).searchParams;
  return ok(await getAppointment(ctx, id, { client_id: sp.get("client_id"), phone: sp.get("phone") }));
});
