import { integrationRoute } from "@/lib/integration/route";
import { ok, readJson } from "@/lib/integration/http";
import { cancelAppointment } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** POST /api/integration/appointments/:id/cancel — { client_id | phone } (dono do agendamento). */
export const POST = integrationRoute<{ id: string }>("cancel_appointment", async (ctx, req, { id }) => {
  const r = await cancelAppointment(ctx, id, await readJson(req));
  return ok({ ...r.appointment, already_cancelled: r.already });
});
