import { integrationRoute } from "@/lib/integration/route";
import { ok, readJson } from "@/lib/integration/http";
import { rescheduleAppointment } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/** POST /api/integration/appointments/:id/reschedule — { client_id | phone, date, time, barber_id? } */
export const POST = integrationRoute<{ id: string }>("reschedule_appointment", async (ctx, req, { id }) => {
  const r = await rescheduleAppointment(ctx, id, await readJson(req));
  return ok({ ...r.appointment, unchanged: r.unchanged });
});
