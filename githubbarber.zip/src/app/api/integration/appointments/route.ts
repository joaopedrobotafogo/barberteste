import { integrationRoute } from "@/lib/integration/route";
import { ok, readJson } from "@/lib/integration/http";
import { createAppointment, listAppointments } from "@/lib/integration/ops";

export const dynamic = "force-dynamic";

/**
 * GET /api/integration/appointments?phone=...[&client_id=...][&limit=10]
 * Próximos agendamentos ATIVOS (aguardando/confirmado, ainda não iniciados) de um cliente, do mais próximo ao mais distante.
 * Exige `phone` ou `client_id`: não existe listagem geral da agenda por esta API.
 */
export const GET = integrationRoute("list_appointments", async (ctx, req) => {
  const sp = new URL(req.url).searchParams;
  return ok(await listAppointments(ctx, { phone: sp.get("phone"), clientId: sp.get("client_id"), limit: sp.get("limit") }));
});

/** POST /api/integration/appointments — { client_id | phone, service_id, barber_id, date, time, notes?, source? } */
export const POST = integrationRoute("create_appointment", async (ctx, req) => {
  const r = await createAppointment(ctx, await readJson(req));
  return ok({ ...r.appointment, idempotent_replay: r.replay }, r.replay ? 200 : 201);
});
