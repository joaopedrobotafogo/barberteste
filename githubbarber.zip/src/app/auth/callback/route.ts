import { NextResponse, type NextRequest } from "next/server";
import type { EmailOtpType } from "@supabase/supabase-js";
import { createClient } from "@/lib/supabase/server";

const safeNext = (n: string | null, fallback: string) =>
  n && n.startsWith("/") && !n.startsWith("//") ? n : fallback;

/**
 * Recebe os links de e-mail do Supabase:
 *  - ?code=...                      (fluxo PKCE: confirmação de cadastro)
 *  - ?token_hash=...&type=invite    (convite de barbeiro / recuperação de senha;
 *                                    requer o template de e-mail descrito no README)
 */
export async function GET(request: NextRequest) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const tokenHash = searchParams.get("token_hash");
  const type = searchParams.get("type") as EmailOtpType | null;
  const needsPassword = type === "invite" || type === "recovery";
  const next = safeNext(searchParams.get("next"), needsPassword ? "/nova-senha" : "/");

  const supabase = await createClient();
  let failed = false;
  if (code) {
    failed = !!(await supabase.auth.exchangeCodeForSession(code)).error;
  } else if (tokenHash && type) {
    failed = !!(await supabase.auth.verifyOtp({ type, token_hash: tokenHash })).error;
  } else {
    failed = true;
  }
  return NextResponse.redirect(`${origin}${failed ? "/login?erro=link" : next}`);
}
