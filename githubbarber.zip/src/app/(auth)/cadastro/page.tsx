import type { Metadata } from "next";
import { SignUpForm } from "@/components/auth-forms";

export const metadata: Metadata = { title: "Criar conta" };

export default function SignUpPage() {
  return (
    <>
      <h1 className="mb-1 text-[28px] font-semibold tracking-tight">Crie sua barbearia</h1>
      <p className="mb-8 text-[15px] text-muted">Leva menos de um minuto.</p>
      <SignUpForm />
    </>
  );
}
