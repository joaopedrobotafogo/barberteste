import type { Metadata } from "next";
import { LoginForm } from "@/components/auth-forms";

export const metadata: Metadata = { title: "Entrar" };

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ erro?: string }> }) {
  const { erro } = await searchParams;
  return (
    <>
      <h1 className="mb-1 text-[28px] font-semibold tracking-tight">Entrar</h1>
      <p className="mb-8 text-[15px] text-muted">Acesse a agenda da sua barbearia.</p>
      <LoginForm linkError={erro === "link"} />
    </>
  );
}
