"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { siteUrl } from "@/lib/auth";
import type { FormState } from "@/lib/types";

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

export async function signIn(_: FormState, fd: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email: str(fd, "email"), password: String(fd.get("password") ?? "") });
  if (error) return { error: "E-mail ou senha incorretos." };
  redirect("/");
}

export async function signUp(_: FormState, fd: FormData): Promise<FormState> {
  const orgName = str(fd, "org_name");
  const ownerName = str(fd, "owner_name");
  const phone = str(fd, "phone");
  const email = str(fd, "email");
  const password = String(fd.get("password") ?? "");

  if (!orgName || !ownerName) return { error: "Informe o nome da barbearia e o seu nome." };
  if (password.length < 8) return { error: "A senha precisa ter pelo menos 8 caracteres." };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      // A barbearia é criada pelo banco (create_organization_with_owner) no primeiro acesso autenticado.
      data: { org_name: orgName, owner_name: ownerName, phone },
      emailRedirectTo: `${await siteUrl()}/auth/callback`,
    },
  });
  if (error) {
    return { error: /registered|already/i.test(error.message) ? "Este e-mail já possui cadastro." : "Não foi possível criar a conta. Tente novamente." };
  }
  if (data.session) redirect("/");
  return { ok: true, message: "Enviamos um link de confirmação para o seu e-mail. Abra-o para entrar." };
}

export async function requestPasswordReset(_: FormState, fd: FormData): Promise<FormState> {
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(str(fd, "email"), {
    redirectTo: `${await siteUrl()}/auth/callback?next=/nova-senha`,
  });
  // Mesma resposta exista ou não a conta (não revelar e-mails cadastrados)
  return { ok: true, message: "Se o e-mail estiver cadastrado, você receberá um link para criar uma nova senha." };
}

export async function updatePassword(_: FormState, fd: FormData): Promise<FormState> {
  const password = String(fd.get("password") ?? "");
  if (password.length < 8) return { error: "A senha precisa ter pelo menos 8 caracteres." };
  if (password !== String(fd.get("confirm") ?? "")) return { error: "As senhas não conferem." };
  const supabase = await createClient();
  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { error: "Não foi possível atualizar a senha. Peça um novo link." };
  redirect("/");
}
