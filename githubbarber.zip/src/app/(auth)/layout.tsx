import { Logo } from "@/components/brand/logo";

export default function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="flex min-h-dvh items-center justify-center bg-background px-4 py-10">
      <div className="animate-fade-up w-full max-w-md">
        <div className="mb-8 flex justify-center"><Logo variant="full" tone="light" height={40} /></div>
        <div className="rounded-3xl border border-border bg-card p-6 shadow-card sm:p-8">{children}</div>
      </div>
    </main>
  );
}
