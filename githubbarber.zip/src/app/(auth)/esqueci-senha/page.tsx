import type { Metadata } from "next";
import { ForgotForm } from "@/components/auth-forms";

export const metadata: Metadata = { title: "Recuperar senha" };

export default function ForgotPage() {
  return (
    <>
      <h1 className="mb-1 text-[28px] font-semibold tracking-tight">Recuperar senha</h1>
      <p className="mb-8 text-[15px] text-muted">Enviaremos um link para você criar uma nova senha.</p>
      <ForgotForm />
    </>
  );
}
