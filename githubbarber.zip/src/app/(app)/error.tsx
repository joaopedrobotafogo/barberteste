"use client";

import { useEffect } from "react";
import { Button, EmptyState } from "@/components/ui";

export default function AppError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => { console.error(error); }, [error]);
  return (
    <EmptyState title="Algo deu errado."
      text="Não foi possível carregar esta tela. Tente novamente."
      action={<Button onClick={reset}>Tentar novamente</Button>} />
  );
}
