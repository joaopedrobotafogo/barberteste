import { Suspense } from "react";
import type { Metadata } from "next";
import { getContext } from "@/lib/auth";
import { Dashboard, DashboardSkeleton } from "@/components/dashboard";

export const metadata: Metadata = { title: "Início" };

export default async function HomePage() {
  const ctx = await getContext();
  // Suspense: o layout aparece já e o painel carrega com skeleton enquanto as consultas rodam.
  return (
    <Suspense fallback={<DashboardSkeleton />}>
      <Dashboard ctx={ctx} />
    </Suspense>
  );
}
