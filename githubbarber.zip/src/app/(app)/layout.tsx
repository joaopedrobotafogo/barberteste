import { Header } from "@/components/header";
import { BottomNav, Sidebar } from "@/components/nav";
import { ThemeSync } from "@/components/theme-sync";
import { getContext } from "@/lib/auth";
import { themeOrDefault } from "@/lib/theme";

export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const { profile, org, user } = await getContext();
  return (
    <div className="min-h-dvh md:flex">
      <ThemeSync theme={themeOrDefault(user.user_metadata?.theme)} />
      <Sidebar role={profile.role} />
      <div className="flex min-w-0 flex-1 flex-col">
        <Header orgName={org.name} userName={profile.full_name} role={profile.role} />
        <main className="mx-auto w-full max-w-6xl flex-1 px-4 pb-28 pt-6 md:px-6 md:pb-12 md:pt-8">{children}</main>
      </div>
      <BottomNav role={profile.role} />
    </div>
  );
}
