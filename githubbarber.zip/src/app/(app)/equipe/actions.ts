"use server";

import { revalidatePath } from "next/cache";
import { requireOwner, siteUrl } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import type { FormState } from "@/lib/types";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function saveBarber(_: FormState, fd: FormData): Promise<FormState> {
  const { supabase, org } = await requireOwner();
  const id = String(fd.get("id") ?? "");
  const name = String(fd.get("name") ?? "").trim();
  const phone = String(fd.get("phone") ?? "").trim();
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const rawCommission = String(fd.get("commission_percent") ?? "").trim().replace(",", ".");
  const commission = rawCommission === "" ? null : Number(rawCommission);

  if (!name) return { error: "Informe o nome do barbeiro." };
  if (email && !EMAIL.test(email)) return { error: "E-mail inválido." };
  if (commission !== null && (!Number.isFinite(commission) || commission < 0 || commission > 100)) {
    return { error: "A comissão deve ficar entre 0 e 100%." };
  }

  const payload: Record<string, unknown> = {
    name,
    phone: phone || null,
    commission_percent: commission,
    is_active: fd.get("is_active") === "on",
  };

  if (id) {
    // Depois do convite, o e-mail fica atrelado à conta de login e não é alterado aqui.
    const { data: current } = await supabase.from("barbers").select("profile_id").eq("id", id).maybeSingle();
    if (!current?.profile_id) payload.email = email || null;
    const { error } = await supabase.from("barbers").update(payload).eq("id", id);
    if (error) return { error: "Não foi possível salvar. Tente novamente." };
  } else {
    const { error } = await supabase.from("barbers").insert({ ...payload, email: email || null, organization_id: org.id });
    if (error) return { error: "Não foi possível salvar. Tente novamente." };
  }
  revalidatePath("/equipe");
  return { ok: true, message: id ? "Barbeiro atualizado" : "Barbeiro adicionado" };
}

export async function toggleBarber(id: string, active: boolean): Promise<FormState> {
  const { supabase } = await requireOwner();
  const { error } = await supabase.from("barbers").update({ is_active: active }).eq("id", id);
  if (error) return { error: "Não foi possível alterar o barbeiro." };
  revalidatePath("/equipe");
  return { ok: true, message: active ? "Barbeiro ativado" : "Barbeiro desativado" };
}

type AuthLikeError = { message: string; status?: number; code?: string; name?: string };

const describe = (e: AuthLikeError) =>
  `${e.message}${e.code ? ` [${e.code}]` : ""}${e.status ? ` (HTTP ${e.status})` : ""}`;

function inviteHint(msg: string): string {
  if (/already|registered|exists/i.test(msg)) return "Este e-mail já possui uma conta. Use outro e-mail.";
  if (/rate limit/i.test(msg)) return "Limite de envio de e-mails do Supabase atingido. Aguarde um pouco ou configure um SMTP próprio.";
  if (/not authorized/i.test(msg)) return "O SMTP padrão do Supabase só envia para membros da equipe do projeto. Configure um SMTP próprio (Project Settings > Authentication > SMTP).";
  return "";
}

/**
 * Convite via Supabase Auth (inviteUserByEmail). Passos:
 * 1) dono validado (requireOwner) e barbeiro lido pela RLS da própria organização;
 * 2) convite enviado (se falhar, NADA é criado: nem usuário, nem profile);
 * 3) profile (role=barber) criado com service role já na organização do dono;
 * 4) barbers.profile_id preenchido. Falha em 3 ou 4 desfaz o usuário criado.
 * Todo erro é logado no terminal (prefixo [inviteBarber]) e devolvido à interface.
 */
export async function inviteBarber(barberId: string): Promise<FormState> {
  try {
    return await inviteBarberImpl(barberId);
  } catch (e) {
    // requireOwner() usa redirect(), que lança um erro especial do Next: deve seguir adiante.
    if (e instanceof Error && "digest" in e && String((e as { digest?: unknown }).digest).startsWith("NEXT_REDIRECT")) throw e;
    console.error("[inviteBarber] erro inesperado:", e);
    return { error: `Erro inesperado ao convidar: ${e instanceof Error ? e.message : String(e)}` };
  }
}

async function inviteBarberImpl(barberId: string): Promise<FormState> {
  const { supabase, org } = await requireOwner();

  const { data: barber, error: readErr } = await supabase
    .from("barbers")
    .select("id, name, phone, email, profile_id")
    .eq("id", barberId)
    .is("deleted_at", null)
    .maybeSingle();
  if (readErr) {
    console.error("[inviteBarber] falha ao ler o barbeiro:", readErr);
    return { error: `Não foi possível ler o barbeiro: ${readErr.message}` };
  }
  if (!barber) return { error: "Barbeiro não encontrado." };
  if (!barber.email) return { error: "Cadastre um e-mail para enviar o convite." };

  let admin: ReturnType<typeof createAdminClient>;
  try {
    admin = createAdminClient();
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("[inviteBarber] configuração do cliente admin:", msg);
    return { error: msg };
  }

  // Sem query string: precisa bater com a lista "Redirect URLs" do Supabase.
  // O /auth/callback já envia type=invite/recovery para /nova-senha.
  const redirectTo = `${await siteUrl()}/auth/callback`;
  console.log(`[inviteBarber] enviando convite barber=${barber.id} redirectTo=${redirectTo}`);

  // Reenvio: conta já criada, mas ainda sem primeiro login.
  if (barber.profile_id) {
    const { data: existing, error: getErr } = await admin.auth.admin.getUserById(barber.profile_id);
    if (getErr) {
      console.error("[inviteBarber] getUserById falhou:", getErr);
      return { error: `Não foi possível consultar a conta do barbeiro: ${describe(getErr)}` };
    }
    if (existing.user?.last_sign_in_at) return { error: "Este barbeiro já acessou o sistema." };
    const { error } = await admin.auth.admin.inviteUserByEmail(barber.email, { redirectTo });
    if (error) {
      console.error("[inviteBarber] reenvio falhou:", { message: error.message, status: error.status, code: error.code });
      return { error: [`Não foi possível reenviar o convite: ${describe(error)}`, inviteHint(error.message)].filter(Boolean).join(" ") };
    }
    console.log("[inviteBarber] convite reenviado");
    return { ok: true, message: "Convite reenviado" };
  }

  const { data, error } = await admin.auth.admin.inviteUserByEmail(barber.email, {
    redirectTo,
    data: { full_name: barber.name },
  });
  if (error || !data?.user) {
    const e: AuthLikeError = error ?? { message: "resposta sem usuário" };
    console.error("[inviteBarber] inviteUserByEmail falhou:", { message: e.message, status: e.status, code: e.code, name: e.name });
    return { error: [`O Supabase recusou o convite: ${describe(e)}`, inviteHint(e.message)].filter(Boolean).join(" ") };
  }

  const uid = data.user.id;
  console.log(`[inviteBarber] usuário de Auth criado id=${uid}`);

  const rollback = async (why: string) => {
    const { error: delErr } = await admin.auth.admin.deleteUser(uid); // cascade remove o profile
    if (delErr) console.error("[inviteBarber] ROLLBACK FALHOU, remova o usuário manualmente:", uid, delErr);
    return { error: `${why} O convite foi cancelado; tente novamente.` };
  };

  const { error: pErr } = await admin.from("profiles").insert({
    id: uid, organization_id: org.id, full_name: barber.name, phone: barber.phone, role: "barber",
  });
  if (pErr) {
    console.error("[inviteBarber] insert em profiles falhou:", pErr);
    return rollback(`Falha ao criar o perfil (${pErr.message}).`);
  }

  const { data: linked, error: bErr } = await admin
    .from("barbers")
    .update({ profile_id: uid })
    .eq("id", barber.id)
    .eq("organization_id", org.id)
    .select("id");
  if (bErr || !linked?.length) {
    console.error("[inviteBarber] vincular barbers.profile_id falhou:", bErr ?? "0 linhas atualizadas");
    return rollback(`Falha ao vincular o barbeiro (${bErr?.message ?? "nenhuma linha atualizada"}).`);
  }

  revalidatePath("/equipe");
  console.log("[inviteBarber] convite concluído");
  return { ok: true, message: "Convite enviado" };
}
