import type { Metadata } from "next";
import { requireOwner } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { TeamManager, type TeamMember } from "@/components/team-manager";
import type { AccessStatus, Barber, Role } from "@/lib/types";

export const metadata: Metadata = { title: "Equipe" };

export default async function TeamPage() {
  const { supabase } = await requireOwner();

  const { data } = await supabase
    .from("barbers")
    .select("id, profile_id, name, phone, email, photo_url, is_active, commission_percent")
    .is("deleted_at", null)
    .order("name");
  const barbers = (data ?? []) as Barber[];

  const ids = barbers.map((b) => b.profile_id).filter((x): x is string => !!x);
  const roles = new Map<string, Role>();
  if (ids.length) {
    const { data: profiles } = await supabase.from("profiles").select("id, role").in("id", ids);
    (profiles ?? []).forEach((p: { id: string; role: Role }) => roles.set(p.id, p.role));
  }

  // Convite pendente = conta criada que ainda não fez login. Só o service role enxerga o Auth.
  const access = new Map<string, AccessStatus>();
  try {
    const admin = createAdminClient();
    await Promise.all(
      ids.map(async (id) => {
        const { data: u } = await admin.auth.admin.getUserById(id);
        access.set(id, u.user?.last_sign_in_at ? "active" : "pending");
      })
    );
  } catch (e) {
    console.warn("[equipe] status de convite indisponível:", e instanceof Error ? e.message : e);
    ids.forEach((id) => access.set(id, "active")); // sem service role: não dá para saber
  }

  const members: TeamMember[] = barbers.map((b) => ({
    ...b,
    role: b.profile_id ? roles.get(b.profile_id) ?? null : null,
    access: b.profile_id ? access.get(b.profile_id) ?? "pending" : "none",
  }));
  return <TeamManager members={members} />;
}
