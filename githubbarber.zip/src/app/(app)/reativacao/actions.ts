"use server";

import { revalidatePath } from "next/cache";
import { requireOwner } from "@/lib/auth";
import { ApiError } from "@/lib/integration/http";
import { ownerReactivationCtx } from "@/lib/reactivation/owner";
import { cancelRequest, dismissCandidate, requestReactivation } from "@/lib/reactivation/service";
import type { FormState } from "@/lib/types";

const FAIL = "Não foi possível concluir. Tente novamente.";

/**
 * Ações do DONO sobre a reativação. Mesmo service da API do n8n (origem "manual").
 * A organização vem da sessão; o cliente só informa o id do cliente/tentativa e o service revalida TUDO no backend.
 */
async function run(fn: (r: ReturnType<typeof ownerReactivationCtx>, userId: string) => Promise<string>): Promise<FormState> {
  const ctx = await requireOwner();
  try {
    const message = await fn(ownerReactivationCtx(ctx.org.id), ctx.user.id);
    revalidatePath("/", "layout");
    return { ok: true, message };
  } catch (e) {
    if (e instanceof ApiError && e.status < 500) { revalidatePath("/", "layout"); return { error: e.message }; }
    console.error("[reativacao] ação:", e instanceof Error ? e.message : e);
    return { error: FAIL };
  }
}

export async function reactivateClient(clientId: string): Promise<FormState> {
  return run(async (r, userId) => {
    const res = await requestReactivation(r, clientId, { origin: "manual", requestedBy: userId });
    return res.replay ? "Esta reativação já estava registrada." : "Reativação registrada. A mensagem sai pela automação do WhatsApp.";
  });
}

export async function dismissClient(clientId: string): Promise<FormState> {
  return run(async (r, userId) => {
    await dismissCandidate(r, clientId, { requestedBy: userId });
    return "Cliente ignorado por enquanto.";
  });
}

export async function cancelReactivation(attemptId: string): Promise<FormState> {
  return run(async (r) => {
    await cancelRequest(r, attemptId);
    return "Pedido cancelado.";
  });
}
