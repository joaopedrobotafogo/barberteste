import type { Metadata } from "next";
import { requireOwner } from "@/lib/auth";
import { loadReactivationView } from "@/lib/reactivation/view";
import { PageHeader } from "@/components/ui";
import { ReactivationSection } from "@/components/reactivation";

export const metadata: Metadata = { title: "Reativação" };

export default async function ReativacaoPage() {
  const ctx = await requireOwner();
  const view = await loadReactivationView(ctx);
  return (
    <>
      <PageHeader title="Reativação" subtitle="Clientes que passaram do próprio ritmo de retorno." />
      <div className="max-w-3xl"><ReactivationSection view={view} /></div>
    </>
  );
}
