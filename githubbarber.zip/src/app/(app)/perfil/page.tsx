import type { Metadata } from "next";
import { getContext } from "@/lib/auth";
import { PageHeader } from "@/components/ui";
import { ProfileForm } from "@/components/profile-form";

export const metadata: Metadata = { title: "Meu perfil" };

export default async function ProfilePage() {
  const { profile, user } = await getContext();
  return (
    <>
      <PageHeader title="Meu perfil" subtitle={profile.role === "owner" ? "Proprietário" : "Barbeiro"} />
      <div className="max-w-md">
        <ProfileForm name={profile.full_name} phone={profile.phone ?? ""} email={user.email ?? ""} />
      </div>
    </>
  );
}
