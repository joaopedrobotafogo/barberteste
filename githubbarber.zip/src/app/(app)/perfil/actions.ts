"use server";

import { revalidatePath } from "next/cache";
import { getContext } from "@/lib/auth";
import type { FormState } from "@/lib/types";

export async function saveProfile(_: FormState, fd: FormData): Promise<FormState> {
  const { supabase, profile } = await getContext();
  const full_name = String(fd.get("full_name") ?? "").trim();
  const phone = String(fd.get("phone") ?? "").trim();
  if (!full_name) return { error: "Informe seu nome." };
  // RLS (profiles_update_self) só permite alterar o próprio perfil; o trigger bloqueia mudar papel/organização.
  const { error } = await supabase.from("profiles").update({ full_name, phone: phone || null }).eq("id", profile.id);
  if (error) return { error: "Não foi possível salvar. Tente novamente." };
  revalidatePath("/", "layout");
  return { ok: true, message: "Perfil atualizado" };
}
