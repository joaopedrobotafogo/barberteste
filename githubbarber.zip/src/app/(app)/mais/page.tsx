import Link from "next/link";
import { getContext } from "@/lib/auth";
import { moreItemsFor, type NavItem } from "@/lib/nav";
import { Icon, PageHeader } from "@/components/ui";

export default async function MorePage() {
  const { profile } = await getContext();
  const items: Pick<NavItem, "href" | "label" | "icon">[] = [
    ...moreItemsFor(profile.role),
    { href: "/perfil", label: "Meu perfil", icon: "user" },
  ];
  return (
    <>
      <PageHeader title="Mais" />
      <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">
        {items.map((i) => (
          <li key={i.href}>
            <Link href={i.href} className="flex min-h-14 items-center gap-3 px-4 text-[15px] hover:bg-muted-bg">
              <Icon name={i.icon} className="h-5 w-5 text-muted" />
              <span className="flex-1">{i.label}</span>
              <Icon name="chevron" className="h-4 w-4 text-muted" />
            </Link>
          </li>
        ))}
      </ul>
      <form action="/auth/signout" method="post" className="mt-6">
        <button className="flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-line bg-surface text-[15px] font-medium text-danger">
          <Icon name="logout" className="h-4 w-4" /> Sair
        </button>
      </form>
    </>
  );
}
