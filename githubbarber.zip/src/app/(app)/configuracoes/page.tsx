import type { Metadata } from "next";
import { requireOwner } from "@/lib/auth";
import { loadBusinessSettings } from "@/lib/settings";
import { ownerReactivationCtx } from "@/lib/reactivation/owner";
import { loadReactivationSettings, type ReactivationSettings } from "@/lib/reactivation/settings";
import { EmptyState, PageHeader } from "@/components/ui";
import { SettingsForms } from "@/components/settings";

export const metadata: Metadata = { title: "Configurações" };

export default async function ConfiguracoesPage() {
  const ctx = await requireOwner();
  const settings = await loadBusinessSettings(ctx);
  // null = não foi possível carregar (ex.: migration 0003 ainda não aplicada); a tela avisa em vez de inventar valores.
  let reactivation: ReactivationSettings | null = null;
  try {
    const r = ownerReactivationCtx(ctx.org.id);
    reactivation = await loadReactivationSettings(r.db, r.orgId);
  } catch (e) {
    console.error("[configuracoes] reativação:", e instanceof Error ? e.message : e);
  }

  return (
    <>
      <PageHeader title="Configurações" subtitle="Ajuste sua barbearia, a aparência e as regras do sistema." />
      {settings ? (
        <SettingsForms orgName={ctx.org.name} settings={settings} reactivation={reactivation} theme={ctx.user.user_metadata?.theme} />
      ) : (
        <EmptyState title="Não foi possível carregar as configurações" text="Atualize a página. Se o problema continuar, tente sair e entrar de novo." />
      )}
    </>
  );
}
