"use server";

import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { requireOwner } from "@/lib/auth";
import { validateAgendaRules, validateClientRules, validateHoursForm, validateOrgName } from "@/lib/settings";
import { ownerReactivationCtx } from "@/lib/reactivation/owner";
import { saveReactivationSettings, validateReactivationSettings } from "@/lib/reactivation/settings";
import { THEME_COOKIE, THEME_COOKIE_MAX_AGE, isThemeId } from "@/lib/theme";
import type { FormState } from "@/lib/types";

const FAIL = "Não foi possível salvar. Tente novamente.";
const NOT_FOUND = "Não foi possível localizar as configurações desta barbearia.";

type Ctx = Awaited<ReturnType<typeof requireOwner>>;

// Agenda, Início, Clientes e o nome no cabeçalho leem estes dados: revalida o app inteiro (como em Meu perfil).
const revalidateAll = () => revalidatePath("/", "layout");

/** organization_id vem da sessão, nunca do cliente; a RLS (settings_update) também exige papel owner. */
async function updateSettings(ctx: Ctx, patch: Record<string, unknown>, message: string): Promise<FormState> {
  const { data, error } = await ctx.supabase
    .from("business_settings")
    .update(patch)
    .eq("organization_id", ctx.org.id)
    .select("organization_id");
  if (error) { console.error("[configuracoes] salvar:", error); return { error: FAIL }; }
  if (!data || data.length === 0) return { error: NOT_FOUND };
  revalidateAll();
  return { ok: true, message };
}

export async function saveBusinessName(input: unknown): Promise<FormState> {
  const ctx = await requireOwner();
  const checked = validateOrgName(input);
  if (!checked.ok) return { error: checked.error };

  const { data, error } = await ctx.supabase
    .from("organizations")
    .update({ name: checked.value })
    .eq("id", ctx.org.id)
    .select("id");
  if (error) { console.error("[configuracoes] nome:", error); return { error: FAIL }; }
  if (!data || data.length === 0) return { error: NOT_FOUND };
  revalidateAll();
  return { ok: true, message: "Dados da barbearia atualizados" };
}

export async function saveHours(input: unknown): Promise<FormState> {
  const ctx = await requireOwner();
  const checked = validateHoursForm(input);
  if (!checked.ok) return { error: checked.error };
  return updateSettings(
    ctx,
    { timezone: checked.value.timezone, opening_hours: checked.value.hours },
    "Horário de funcionamento atualizado",
  );
}

export async function saveAgenda(input: unknown): Promise<FormState> {
  const ctx = await requireOwner();
  const checked = validateAgendaRules(input);
  if (!checked.ok) return { error: checked.error };
  return updateSettings(
    ctx,
    {
      slot_interval_minutes: checked.value.slotInterval,
      min_notice_minutes: checked.value.minNotice,
      allow_overbooking: checked.value.allowOverbooking,
    },
    "Regras da agenda atualizadas",
  );
}

export async function saveClientRules(input: unknown): Promise<FormState> {
  const ctx = await requireOwner();
  const checked = validateClientRules(input);
  if (!checked.ok) return { error: checked.error };
  return updateSettings(
    ctx,
    {
      risk_after_days: checked.value.riskDays,
      lost_after_days: checked.value.lostDays,
      vip_min_visits: checked.value.vipVisits,
      vip_min_spent: checked.value.vipSpent,
    },
    "Regras de clientes atualizadas",
  );
}

/**
 * Reativação (Etapa 11): configuração da ORGANIZAÇÃO. A tabela só aceita escrita pelo servidor (service role),
 * então a ação confirma que é o dono (requireOwner) e usa o organization_id da sessão.
 */
export async function saveReactivation(input: unknown): Promise<FormState> {
  const ctx = await requireOwner();
  const checked = validateReactivationSettings(input);
  if (!checked.ok) return { error: checked.error };
  try {
    const r = ownerReactivationCtx(ctx.org.id);
    await saveReactivationSettings(r.db, r.orgId, checked.value);
  } catch (e) {
    console.error("[configuracoes] reativação:", e instanceof Error ? e.message : e);
    return { error: FAIL };
  }
  revalidateAll();
  return { ok: true, message: "Regras de reativação atualizadas" };
}

/**
 * Aparência: paleta de cores da interface. Sem migration: fica no user_metadata do Supabase Auth
 * (por usuário, vale em qualquer aparelho) e é espelhada em cookie para o servidor pintar a página sem "flash".
 * Só a cor muda; nenhuma regra de negócio é tocada.
 */
export async function saveTheme(input: unknown): Promise<FormState> {
  const ctx = await requireOwner();
  if (!isThemeId(input)) return { error: "Paleta inválida." };
  const { error } = await ctx.supabase.auth.updateUser({ data: { theme: input } });
  if (error) { console.error("[configuracoes] tema:", error.message); return { error: FAIL }; }
  (await cookies()).set(THEME_COOKIE, input, { path: "/", maxAge: THEME_COOKIE_MAX_AGE, sameSite: "lax" });
  return { ok: true, message: "Aparência atualizada" };
}
