import { Suspense } from "react";
import type { Metadata } from "next";
import { requireOwner } from "@/lib/auth";
import { DEFAULT_PERIOD, isPeriod } from "@/lib/finance";
import { PageHeader } from "@/components/ui";
import { PeriodFilter } from "@/components/finance";
import { ReportsContent, ReportsSkeleton } from "@/components/reports";

export const metadata: Metadata = { title: "Relatórios" };

export default async function RelatoriosPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  // Mesmo controle de acesso já existente (somente dono); a RLS de payments também só libera leitura ao owner.
  const ctx = await requireOwner();
  const sp = await searchParams;
  const period = isPeriod(sp.periodo) ? sp.periodo : DEFAULT_PERIOD;

  return (
    <>
      <PageHeader title="Relatórios" />
      <PeriodFilter active={period} basePath="/relatorios" />
      <Suspense key={period} fallback={<ReportsSkeleton />}>
        <ReportsContent ctx={ctx} period={period} />
      </Suspense>
    </>
  );
}
