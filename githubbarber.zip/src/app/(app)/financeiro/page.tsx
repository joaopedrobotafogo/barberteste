import { Suspense } from "react";
import type { Metadata } from "next";
import { requireOwner } from "@/lib/auth";
import { DEFAULT_PERIOD, isPeriod } from "@/lib/finance";
import { PageHeader } from "@/components/ui";
import { FinanceContent, FinanceSkeleton, PeriodFilter } from "@/components/finance";

export const metadata: Metadata = { title: "Financeiro" };

export default async function FinanceiroPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  // Mesmo controle de acesso das demais áreas do dono (a RLS de payments também só libera leitura ao owner).
  const ctx = await requireOwner();
  const sp = await searchParams;
  const period = isPeriod(sp.periodo) ? sp.periodo : DEFAULT_PERIOD;
  const page = Math.max(1, parseInt(sp.pag ?? "1", 10) || 1);

  return (
    <>
      <PageHeader title="Financeiro" />
      <PeriodFilter active={period} />
      {/* key: trocar período/página volta ao skeleton enquanto as consultas rodam */}
      <Suspense key={`${period}-${page}`} fallback={<FinanceSkeleton />}>
        <FinanceContent ctx={ctx} period={period} page={page} />
      </Suspense>
    </>
  );
}
