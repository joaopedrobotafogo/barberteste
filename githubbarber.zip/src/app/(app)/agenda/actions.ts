"use server";

import { revalidatePath } from "next/cache";
import { getContext } from "@/lib/auth";
import { parseMoney } from "@/lib/format";
import { UUID_RE } from "@/lib/clients";
import { ALL_STATUSES, isValidYmd, zonedToUtc, type ClientPick } from "@/lib/agenda";
import { dbErrorMessage, getAvailableSlots, loadAgendaSettings } from "@/lib/agenda-core";
import type { AppointmentStatus, FormState } from "@/lib/types";

type Ctx = Awaited<ReturnType<typeof getContext>>;

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

async function ownBarberId(ctx: Ctx): Promise<string | null> {
  const { data } = await ctx.supabase.from("barbers").select("id").eq("profile_id", ctx.profile.id).is("deleted_at", null).maybeSingle();
  return (data?.id as string | undefined) ?? null;
}

/** BARBER só mexe na própria agenda. (A RLS atual libera a organização toda; a regra fica aqui e na UI.) */
async function canUseBarber(ctx: Ctx, barberId: string): Promise<boolean> {
  if (ctx.profile.role === "owner") return true;
  return (await ownBarberId(ctx)) === barberId;
}

// Lógica de configurações e de erros do banco vive em lib/agenda-core.ts (compartilhada com a API de integração).
const getSettings = (supabase: Ctx["supabase"], orgId: string) => loadAgendaSettings(supabase, orgId);
const dbMessage = dbErrorMessage;

// ---------------------------------------------------------------- consultas auxiliares da tela
export async function searchClients(q: string): Promise<ClientPick[]> {
  const { supabase } = await getContext();
  const term = q.trim().slice(0, 60);
  if (term.length < 2) return [];
  const safe = term.replace(/[,()%*\\"]/g, " ").trim();
  const digits = term.replace(/\D/g, "");
  const parts: string[] = [];
  if (safe) parts.push(`name.ilike.*${safe}*`);
  if (digits.length >= 3) parts.push(`phone_normalized.ilike.*${digits}*`);
  if (!parts.length) return [];
  const { data, error } = await supabase.from("clients").select("id, name, phone").is("deleted_at", null)
    .or(parts.join(",")).order("name").limit(8);
  if (error) { console.error("[agenda:searchClients]", error); return []; }
  return (data ?? []) as ClientPick[];
}

/**
 * Horários livres de um barbeiro num dia para um serviço (considera expediente, intervalo,
 * antecedência mínima, agendamentos e bloqueios). A lógica fica em lib/agenda-core.ts e é
 * a mesma usada pela API de integração (n8n/WhatsApp).
 */
export async function getSlots(input: { barberId: string; serviceId: string; date: string; excludeId?: string }):
  Promise<{ slots: string[]; closed: boolean; error?: string }> {
  const { supabase, org } = await getContext();
  return getAvailableSlots(supabase, org.id, input);
}

// ---------------------------------------------------------------- agendamentos
export async function saveAppointment(_: FormState, fd: FormData): Promise<FormState> {
  const ctx = await getContext();
  const { supabase, org, user } = ctx;

  const id = str(fd, "id");
  const serviceId = str(fd, "service_id");
  const barberId = str(fd, "barber_id");
  const date = str(fd, "date");
  const time = str(fd, "time");
  const status = str(fd, "status") as AppointmentStatus;
  const notes = str(fd, "notes");
  const overbook = fd.get("is_overbook") === "on";

  if (!UUID_RE.test(serviceId)) return { error: "Selecione o serviço." };
  if (!UUID_RE.test(barberId)) return { error: "Selecione o barbeiro." };
  if (!isValidYmd(date)) return { error: "Informe a data." };
  if (!TIME_RE.test(time)) return { error: "Escolha o horário." };
  if (!ALL_STATUSES.includes(status)) return { error: "Status inválido." };
  if (!(await canUseBarber(ctx, barberId))) return { error: "Você só pode usar a sua própria agenda." };

  let existing: { service_id: string; barber_id: string } | null = null;
  if (id) {
    if (!UUID_RE.test(id)) return { error: "Agendamento inválido." };
    const { data } = await supabase.from("appointments").select("service_id, barber_id").eq("id", id).is("deleted_at", null).maybeSingle();
    if (!data) return { error: "Agendamento não encontrado." };
    if (!(await canUseBarber(ctx, data.barber_id as string))) return { error: "Você só pode editar a sua própria agenda." };
    existing = data as { service_id: string; barber_id: string };
  }

  const [{ data: svc }, { data: barber }, st] = await Promise.all([
    supabase.from("services").select("price, duration_minutes, is_active").eq("id", serviceId).is("deleted_at", null).maybeSingle(),
    supabase.from("barbers").select("is_active").eq("id", barberId).is("deleted_at", null).maybeSingle(),
    getSettings(supabase, org.id),
  ]);
  if (!svc) return { error: "Serviço não encontrado." };
  if (!svc.is_active && existing?.service_id !== serviceId) return { error: "Este serviço está inativo." };
  if (!barber) return { error: "Barbeiro não encontrado." };
  if (!barber.is_active && existing?.barber_id !== barberId) return { error: "Este barbeiro está inativo." };
  if (overbook && !st.allowOverbooking) return { error: "Encaixes não estão habilitados para esta barbearia." };

  const rawPrice = str(fd, "price");
  const price = rawPrice === "" ? (svc.price as number) : parseMoney(rawPrice);
  if (price === null) return { error: "Informe um valor válido." };

  // Cliente: existente ou novo (criado já na organização do usuário)
  let clientId = str(fd, "client_id");
  if (fd.get("new_client") === "1") {
    const name = str(fd, "new_name");
    const phone = str(fd, "new_phone");
    const digits = phone.replace(/\D/g, "");
    if (!name) return { error: "Informe o nome do novo cliente." };
    if (digits.length < 10 || digits.length > 13) return { error: "Telefone do cliente inválido. Informe o DDD e o número." };
    const { data: created, error: cErr } = await supabase.from("clients")
      .insert({ organization_id: org.id, name, phone }).select("id");
    if (cErr) {
      if (cErr.code === "23505") {
        const { data: dup } = await supabase.from("clients").select("name").eq("phone_normalized", digits).is("deleted_at", null).limit(1).maybeSingle();
        return { error: `Já existe um cliente com este telefone${dup ? `: ${dup.name}` : ""}. Busque-o pelo nome.` };
      }
      console.error("[agenda:newClient]", cErr);
      return { error: "Não foi possível criar o cliente." };
    }
    clientId = created?.[0]?.id as string;
  }
  if (!UUID_RE.test(clientId)) return { error: "Selecione o cliente." };

  const start = zonedToUtc(date, time, st.timezone);
  const end = new Date(start.getTime() + (svc.duration_minutes as number) * 60_000);

  const payload = {
    client_id: clientId, barber_id: barberId, service_id: serviceId,
    start_at: start.toISOString(), end_at: end.toISOString(),
    status, price, notes: notes || null, is_overbook: overbook,
  };

  const { data, error } = id
    ? await supabase.from("appointments").update(payload).eq("id", id).is("deleted_at", null).select("id")
    : await supabase.from("appointments").insert({ ...payload, organization_id: org.id, source: "app", created_by: user.id }).select("id");
  if (error) return { error: dbMessage(error, "appointment") };
  if (!data?.length) return { error: "Agendamento não encontrado." };

  revalidatePath("/agenda");
  revalidatePath("/clientes");
  return { ok: true, id: data[0].id as string, message: id ? "Agendamento atualizado" : "Agendamento criado" };
}

const STATUS_MESSAGE: Record<AppointmentStatus, string> = {
  pending: "Marcado como aguardando", confirmed: "Agendamento confirmado", completed: "Atendimento concluído",
  cancelled: "Agendamento cancelado", no_show: "Marcado como no-show",
};

/** Confirmar, concluir, cancelar, no-show ou reabrir. Concluir gera o pagamento (trigger do banco). */
export async function setAppointmentStatus(id: string, status: AppointmentStatus): Promise<FormState> {
  const ctx = await getContext();
  if (!UUID_RE.test(id) || !ALL_STATUSES.includes(status)) return { error: "Dados inválidos." };
  const { data: appt } = await ctx.supabase.from("appointments").select("barber_id").eq("id", id).is("deleted_at", null).maybeSingle();
  if (!appt) return { error: "Agendamento não encontrado." };
  if (!(await canUseBarber(ctx, appt.barber_id as string))) return { error: "Você só pode alterar a sua própria agenda." };

  const { data, error } = await ctx.supabase.from("appointments").update({ status }).eq("id", id).select("id");
  if (error) return { error: dbMessage(error, "status") };
  if (!data?.length) return { error: "Agendamento não encontrado." };
  revalidatePath("/agenda");
  revalidatePath("/clientes");
  return { ok: true, message: STATUS_MESSAGE[status] };
}

// ---------------------------------------------------------------- bloqueios
export async function saveBlock(_: FormState, fd: FormData): Promise<FormState> {
  const ctx = await getContext();
  const barberId = str(fd, "barber_id");
  const date = str(fd, "date");
  const from = str(fd, "start");
  const to = str(fd, "end");
  if (!UUID_RE.test(barberId)) return { error: "Selecione o barbeiro." };
  if (!isValidYmd(date)) return { error: "Informe a data." };
  if (!TIME_RE.test(from) || !TIME_RE.test(to)) return { error: "Informe o horário inicial e o final." };
  if (to <= from) return { error: "O horário final deve ser depois do inicial." };
  if (!(await canUseBarber(ctx, barberId))) return { error: "Você só pode bloquear a sua própria agenda." };

  const st = await getSettings(ctx.supabase, ctx.org.id);
  const { data, error } = await ctx.supabase.from("time_blocks").insert({
    organization_id: ctx.org.id, barber_id: barberId,
    start_at: zonedToUtc(date, from, st.timezone).toISOString(),
    end_at: zonedToUtc(date, to, st.timezone).toISOString(),
    reason: str(fd, "reason") || null,
  }).select("id");
  if (error) return { error: dbMessage(error, "block") };
  if (!data?.length) return { error: "Não foi possível salvar o bloqueio." };
  revalidatePath("/agenda");
  return { ok: true, message: "Horário bloqueado" };
}

export async function deleteBlock(id: string): Promise<FormState> {
  const ctx = await getContext();
  if (!UUID_RE.test(id)) return { error: "Dados inválidos." };
  const { data: blk } = await ctx.supabase.from("time_blocks").select("barber_id").eq("id", id).is("deleted_at", null).maybeSingle();
  if (!blk) return { error: "Bloqueio não encontrado." };
  if (!(await canUseBarber(ctx, blk.barber_id as string))) return { error: "Você só pode alterar a sua própria agenda." };
  const { error } = await ctx.supabase.from("time_blocks").update({ deleted_at: new Date().toISOString() }).eq("id", id);
  if (error) return { error: dbMessage(error, "block") };
  revalidatePath("/agenda");
  return { ok: true, message: "Bloqueio removido" };
}
