import type { Metadata } from "next";
import Link from "next/link";
import { getContext } from "@/lib/auth";
import {
  addDays, dayLong, dayMonth, dayNum, isValidYmd, localParts, mondayOf, todayIn, weekdayShort, zonedToUtc,
  type AgendaAppt, type AgendaBlock,
} from "@/lib/agenda";
import { UUID_RE } from "@/lib/clients";
import type { AppointmentStatus } from "@/lib/types";
import { ErrorNote, Icon, PageHeader } from "@/components/ui";
import { AgendaBoard } from "@/components/agenda-board";

export const metadata: Metadata = { title: "Agenda" };

interface ApptRow { id: string; client_id: string; barber_id: string; service_id: string; start_at: string; end_at: string; status: AppointmentStatus; price: number; notes: string | null; is_overbook: boolean }
interface BlockRow { id: string; barber_id: string; start_at: string; end_at: string; reason: string | null }

function agendaHref(o: { view: "dia" | "semana"; date: string; barber?: string | null }) {
  const sp = new URLSearchParams({ view: o.view, date: o.date });
  if (o.barber) sp.set("barber", o.barber);
  return `/agenda?${sp.toString()}`;
}

export default async function AgendaPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const { supabase, profile } = await getContext();
  const isOwner = profile.role === "owner";

  const [settingsRes, barbersRes, servicesRes] = await Promise.all([
    supabase.from("business_settings").select("timezone, allow_overbooking").maybeSingle(),
    supabase.from("barbers").select("id, name, profile_id, is_active").is("deleted_at", null).order("name"),
    supabase.from("services").select("id, name, price, duration_minutes, is_active").is("deleted_at", null).order("name"),
  ]);
  const tz = (settingsRes.data?.timezone as string | undefined) ?? "America/Sao_Paulo";
  const allowOverbooking = (settingsRes.data?.allow_overbooking as boolean | undefined) ?? false;

  const allBarbers = (barbersRes.data ?? []) as { id: string; name: string; profile_id: string | null; is_active: boolean }[];
  const allServices = (servicesRes.data ?? []) as { id: string; name: string; price: number; duration_minutes: number; is_active: boolean }[];
  const activeBarbers = allBarbers.filter((b) => b.is_active).map((b) => ({ id: b.id, name: b.name }));
  const activeServices = allServices.filter((s) => s.is_active);

  // BARBER vê e usa só a própria agenda (filtro de interface + validação nas actions).
  const own = allBarbers.find((b) => b.profile_id === profile.id) ?? null;
  const lockedBarberId = !isOwner && own ? own.id : null;
  const filterBarberId = lockedBarberId ?? (sp.barber && allBarbers.some((b) => b.id === sp.barber) ? sp.barber : null);

  const today = todayIn(tz);
  const view: "dia" | "semana" = sp.view === "semana" ? "semana" : "dia";
  const date = sp.date && isValidYmd(sp.date) ? sp.date : today;
  const first = view === "semana" ? mondayOf(date) : date;
  const days = view === "semana" ? Array.from({ length: 7 }, (_, i) => addDays(first, i)) : [date];
  const rangeStart = zonedToUtc(first, "00:00", tz).toISOString();
  const rangeEnd = zonedToUtc(addDays(first, days.length), "00:00", tz).toISOString();

  let aq = supabase.from("appointments")
    .select("id, client_id, barber_id, service_id, start_at, end_at, status, price, notes, is_overbook")
    .is("deleted_at", null).gte("start_at", rangeStart).lt("start_at", rangeEnd).order("start_at");
  let bq = supabase.from("time_blocks").select("id, barber_id, start_at, end_at, reason")
    .is("deleted_at", null).gte("start_at", rangeStart).lt("start_at", rangeEnd).order("start_at");
  if (filterBarberId) { aq = aq.eq("barber_id", filterBarberId); bq = bq.eq("barber_id", filterBarberId); }
  const [apptRes, blockRes] = await Promise.all([aq, bq]);
  if (apptRes.error || blockRes.error) console.error("[agenda] consulta falhou:", apptRes.error ?? blockRes.error);
  const loadError = !!(apptRes.error || blockRes.error);

  const apptRows = (apptRes.data ?? []) as ApptRow[];
  const clientIds = [...new Set(apptRows.map((a) => a.client_id))];
  const clientMap = new Map<string, { name: string; phone: string }>();
  if (clientIds.length) {
    const { data } = await supabase.from("clients").select("id, name, phone").in("id", clientIds);
    (data ?? []).forEach((c: { id: string; name: string; phone: string }) => clientMap.set(c.id, c));
  }
  const svcName = new Map(allServices.map((s) => [s.id, s.name]));
  const barberName = new Map(allBarbers.map((b) => [b.id, b.name]));

  const appts: AgendaAppt[] = apptRows.map((a) => {
    const s = localParts(a.start_at, tz);
    const e = localParts(a.end_at, tz);
    const c = clientMap.get(a.client_id);
    return {
      id: a.id, clientId: a.client_id, clientName: c?.name ?? "Cliente removido", clientPhone: c?.phone ?? "",
      serviceId: a.service_id, serviceName: svcName.get(a.service_id) ?? "Serviço removido",
      barberId: a.barber_id, barberName: barberName.get(a.barber_id) ?? "—",
      date: s.date, time: s.time, endTime: e.time, price: Number(a.price), status: a.status, notes: a.notes, isOverbook: a.is_overbook,
    };
  });
  const blocks: AgendaBlock[] = ((blockRes.data ?? []) as BlockRow[]).map((b) => {
    const s = localParts(b.start_at, tz);
    return { id: b.id, barberId: b.barber_id, barberName: barberName.get(b.barber_id) ?? "—", date: s.date, time: s.time, endTime: localParts(b.end_at, tz).time, reason: b.reason };
  });

  // Vindo de "Agendar" no perfil do cliente
  let prefillClient: { id: string; name: string; phone: string } | null = null;
  if (sp.cliente && UUID_RE.test(sp.cliente)) {
    const { data } = await supabase.from("clients").select("id, name, phone").eq("id", sp.cliente).is("deleted_at", null).maybeSingle();
    prefillClient = (data as typeof prefillClient) ?? null;
  }

  const step = view === "semana" ? 7 : 1;
  const barberParam = lockedBarberId ? null : filterBarberId;
  const label = view === "dia" ? dayLong(date) : `${dayMonth(days[0])} – ${dayMonth(days[6])}`;
  const weekStrip = Array.from({ length: 7 }, (_, i) => addDays(mondayOf(date), i));
  const chip = (on: boolean) => `flex h-10 shrink-0 items-center rounded-full border px-4 text-sm font-medium transition-colors ${on ? "border-primary bg-primary text-primary-foreground" : "border-line bg-surface text-ink/70 hover:text-ink"}`;

  return (
    <>
      <PageHeader title="Agenda" subtitle={`${label}${date === today && view === "dia" ? " · Hoje" : ""}`} />

      <div className="mb-3 flex items-center gap-2">
        <Link href={agendaHref({ view, date: addDays(date, -step), barber: barberParam })} aria-label="Anterior" className="flex h-11 w-11 items-center justify-center rounded-xl border border-line bg-surface">
          <Icon name="chevron" className="h-4 w-4 rotate-180" />
        </Link>
        <Link href={agendaHref({ view, date: addDays(date, step), barber: barberParam })} aria-label="Próximo" className="flex h-11 w-11 items-center justify-center rounded-xl border border-line bg-surface">
          <Icon name="chevron" className="h-4 w-4" />
        </Link>
        <Link href={agendaHref({ view, date: today, barber: barberParam })} className="flex h-11 items-center rounded-xl border border-line bg-surface px-4 text-sm font-medium">Hoje</Link>
        <div className="ml-auto flex rounded-xl border border-line bg-surface p-1" role="group" aria-label="Visualização">
          {(["dia", "semana"] as const).map((v) => (
            <Link key={v} href={agendaHref({ view: v, date, barber: barberParam })} aria-current={view === v ? "true" : undefined}
              className={`flex h-9 items-center rounded-lg px-3 text-sm font-medium ${view === v ? "bg-primary text-primary-foreground" : "text-ink/70"}`}>{v === "dia" ? "Dia" : "Semana"}</Link>
          ))}
        </div>
      </div>

      {view === "dia" && (
        <nav aria-label="Dias da semana" className="mb-4 grid grid-cols-7 gap-1">
          {weekStrip.map((d) => (
            <Link key={d} href={agendaHref({ view: "dia", date: d, barber: barberParam })} aria-current={d === date ? "date" : undefined}
              className={`flex h-14 flex-col items-center justify-center rounded-xl text-xs ${d === date ? "bg-primary text-primary-foreground" : "text-muted hover:bg-ink/5"}`}>
              <span>{weekdayShort(d)}</span>
              <span className={`text-base font-semibold ${d === date ? "" : d === today ? "text-ink" : ""}`}>{dayNum(d)}</span>
            </Link>
          ))}
        </nav>
      )}

      {isOwner && activeBarbers.length > 1 && (
        <nav aria-label="Barbeiro" className="-mx-4 mb-5 flex gap-2 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
          <Link href={agendaHref({ view, date })} className={chip(!filterBarberId)}>Todos</Link>
          {activeBarbers.map((b) => <Link key={b.id} href={agendaHref({ view, date, barber: b.id })} className={chip(filterBarberId === b.id)}>{b.name}</Link>)}
        </nav>
      )}

      {loadError && <div className="mb-4"><ErrorNote>Não foi possível carregar a agenda. Atualize a página.</ErrorNote></div>}

      {activeServices.length === 0 || activeBarbers.length === 0 ? (
        <ErrorNote>
          Para agendar, cadastre {activeServices.length === 0 ? "ao menos um serviço" : ""}{activeServices.length === 0 && activeBarbers.length === 0 ? " e " : ""}{activeBarbers.length === 0 ? "ao menos um barbeiro ativo" : ""}
          {isOwner ? " em Serviços e Equipe." : ". Fale com o proprietário."}
        </ErrorNote>
      ) : (
        <AgendaBoard
          view={view} date={date} today={today} days={days} appts={appts} blocks={blocks}
          barbers={activeBarbers} services={activeServices.map((s) => ({ id: s.id, name: s.name, price: Number(s.price), duration_minutes: s.duration_minutes }))}
          isOwner={isOwner} lockedBarberId={lockedBarberId} filterBarberId={filterBarberId}
          allowOverbooking={allowOverbooking} prefillClient={prefillClient}
          cleanHref={agendaHref({ view, date, barber: barberParam })}
        />
      )}
    </>
  );
}
