import Link from "next/link";
import { EmptyState } from "@/components/ui";

export default function NotFound() {
  return (
    <EmptyState title="Cliente não encontrado."
      text="Ele pode ter sido removido ou pertence a outra barbearia."
      action={<Link href="/clientes" className="flex h-12 items-center rounded-xl bg-primary px-5 text-[15px] font-medium text-primary-foreground">Voltar para clientes</Link>} />
  );
}
