import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getContext } from "@/lib/auth";
import { APPT_LABEL, APPT_STYLE, UUID_RE, formatDate, formatDateOnly, getTimezone, lastVisitLabel, shortDate } from "@/lib/clients";
import { brl } from "@/lib/format";
import type { AppointmentStatus, ClientOverview } from "@/lib/types";
import { Avatar, EmptyState, ErrorNote, Icon } from "@/components/ui";
import { EditClientButton } from "@/components/client-forms";
import { StatusBadge, VipBadge } from "@/components/client-badges";

export const metadata: Metadata = { title: "Cliente" };

const HISTORY_LIMIT = 50;
interface Appt { id: string; start_at: string; status: AppointmentStatus; price: number; service_id: string; barber_id: string }

export default async function ClientProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();

  const { supabase } = await getContext();
  const { data: client, error } = await supabase.from("client_overview").select("*").eq("id", id).maybeSingle();
  if (error) {
    console.error("[cliente] consulta falhou:", error);
    return <ErrorNote>Não foi possível carregar este cliente. Tente novamente.</ErrorNote>;
  }
  if (!client) notFound();
  const c = client as ClientOverview;

  const [tz, apptRes, svcRes, barRes] = await Promise.all([
    getTimezone(supabase),
    supabase.from("appointments").select("id, start_at, status, price, service_id, barber_id")
      .eq("client_id", id).is("deleted_at", null).order("start_at", { ascending: false }).limit(HISTORY_LIMIT),
    supabase.from("services").select("id, name"),
    supabase.from("barbers").select("id, name"),
  ]);
  if (apptRes.error) console.error("[cliente] histórico falhou:", apptRes.error);

  const services = new Map((svcRes.data ?? []).map((s: { id: string; name: string }) => [s.id, s.name]));
  const barbers = new Map((barRes.data ?? []).map((b: { id: string; name: string }) => [b.id, b.name]));
  const history = (apptRes.data ?? []) as Appt[];

  const metrics: [string, string][] = [
    ["Último atendimento", lastVisitLabel(c.last_visit_at, tz)],
    ["Atendimentos", String(c.visits)],
    ["Total gasto", brl(c.total_spent)],
    ["Ticket médio", c.visits > 0 ? brl(c.avg_ticket) : "—"],
  ];

  return (
    <>
      <Link href="/clientes" className="-ml-2 mb-4 inline-flex h-11 items-center gap-1 px-2 text-sm text-muted hover:text-ink">
        <Icon name="chevron" className="h-4 w-4 rotate-180" /> Clientes
      </Link>

      <header className="flex items-start gap-4">
        <Avatar name={c.name} className="h-14 w-14 text-base" />
        <div className="min-w-0">
          <h1 className="truncate text-[26px] font-semibold leading-tight tracking-tight">{c.name}</h1>
          <a href={`tel:${c.phone.replace(/\D/g, "")}`} className="text-[15px] text-muted underline-offset-4 hover:underline">{c.phone}</a>
          <div className="mt-2 flex items-center gap-2"><StatusBadge status={c.status} />{c.is_vip && <VipBadge />}</div>
        </div>
      </header>

      <div className="mt-5 flex gap-3 md:max-w-xs">
        <Link href={`/agenda?cliente=${c.id}`} className="flex h-12 flex-1 items-center justify-center rounded-xl bg-primary px-5 text-[15px] font-medium text-primary-foreground shadow-sm transition-colors hover:bg-primary-hover">Agendar</Link>
        <EditClientButton client={{ id: c.id, name: c.name, phone: c.phone, email: c.email, birth_date: c.birth_date, preferences: c.preferences, notes: c.notes }} />
      </div>

      <dl className="mt-6 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line">
        {metrics.map(([label, value]) => (
          <div key={label} className="bg-surface px-4 py-3.5">
            <dt className="text-xs text-muted">{label}</dt>
            <dd className="mt-0.5 text-lg font-semibold tracking-tight">{value}</dd>
          </div>
        ))}
      </dl>

      <section className="mt-8" aria-labelledby="pref">
        <h2 id="pref" className="mb-2 text-sm font-medium text-muted">Preferências</h2>
        {c.preferences ? <p className="whitespace-pre-line text-[15px]">{c.preferences}</p>
          : <p className="text-[15px] text-muted">Nenhuma preferência registrada. Use “Editar” para anotar corte, máquina, barba…</p>}
      </section>

      {c.notes && (
        <section className="mt-6" aria-labelledby="obs">
          <h2 id="obs" className="mb-2 text-sm font-medium text-muted">Observações</h2>
          <p className="whitespace-pre-line text-[15px]">{c.notes}</p>
        </section>
      )}

      <section className="mt-6" aria-label="Dados do cliente">
        <dl className="space-y-1 text-sm text-muted">
          {c.email && <div>E-mail: <span className="text-ink">{c.email}</span></div>}
          {c.birth_date && <div>Nascimento: <span className="text-ink">{formatDateOnly(c.birth_date)}</span></div>}
          <div>Primeiro atendimento: <span className="text-ink">{c.first_visit_at ? formatDate(c.first_visit_at, tz) : "—"}</span></div>
        </dl>
      </section>

      <section className="mt-8" aria-labelledby="hist">
        <h2 id="hist" className="mb-3 text-lg font-semibold tracking-tight">Histórico</h2>
        {apptRes.error ? (
          <ErrorNote>Não foi possível carregar o histórico.</ErrorNote>
        ) : history.length === 0 ? (
          <EmptyState title="Nenhum atendimento registrado." text="Os atendimentos deste cliente aparecem aqui assim que forem agendados." />
        ) : (
          <>
            <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">
              {history.map((a) => (
                <li key={a.id} className="flex items-center gap-3 px-4 py-3.5">
                  <span className="w-12 shrink-0 text-sm tabular-nums text-muted">{shortDate(a.start_at, tz)}</span>
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-[15px] font-medium">{services.get(a.service_id) ?? "Serviço removido"}</span>
                    <span className="block truncate text-sm text-muted">{barbers.get(a.barber_id) ?? "—"}</span>
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="block text-[15px] font-medium">{brl(a.price)}</span>
                    <span className={`block text-xs font-medium ${APPT_STYLE[a.status]}`}>{APPT_LABEL[a.status]}</span>
                  </span>
                </li>
              ))}
            </ul>
            {history.length === HISTORY_LIMIT && <p className="mt-3 text-center text-xs text-muted">Mostrando os {HISTORY_LIMIT} atendimentos mais recentes.</p>}
          </>
        )}
      </section>
    </>
  );
}
