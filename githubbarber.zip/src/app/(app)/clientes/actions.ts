"use server";

import { revalidatePath } from "next/cache";
import { getContext } from "@/lib/auth";
import type { FormState } from "@/lib/types";

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

function validBirth(s: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s && d.getUTCFullYear() >= 1900 && d.getTime() <= Date.now();
}

/** Cria ou edita cliente. Barbeiros e dono podem (RLS clients_all); organization_id só é enviado na criação. */
export async function saveClient(_: FormState, fd: FormData): Promise<FormState> {
  const { supabase, org } = await getContext();
  const id = str(fd, "id");
  const name = str(fd, "name");
  const phone = str(fd, "phone");
  const digits = phone.replace(/\D/g, "");
  const email = str(fd, "email").toLowerCase();
  const birth = str(fd, "birth_date");

  if (!name) return { error: "Informe o nome do cliente." };
  if (digits.length < 10 || digits.length > 13) return { error: "Telefone inválido. Informe o DDD e o número." };
  if (email && !EMAIL.test(email)) return { error: "E-mail inválido." };
  if (birth && !validBirth(birth)) return { error: "Data de nascimento inválida." };

  const payload = {
    name,
    phone,
    email: email || null,
    birth_date: birth || null,
    preferences: str(fd, "preferences") || null,
    notes: str(fd, "notes") || null,
  };

  const { data, error } = id
    ? await supabase.from("clients").update(payload).eq("id", id).is("deleted_at", null).select("id")
    : await supabase.from("clients").insert({ ...payload, organization_id: org.id }).select("id");

  if (error) {
    if (error.code === "23505") {
      let q = supabase.from("clients").select("name").eq("phone_normalized", digits).is("deleted_at", null);
      if (id) q = q.neq("id", id);
      const { data: dup } = await q.limit(1).maybeSingle();
      return { error: dup ? `Já existe um cliente com este telefone: ${dup.name}.` : "Já existe um cliente com este telefone." };
    }
    console.error("[saveClient]", error);
    return { error: "Não foi possível salvar o cliente. Tente novamente." };
  }
  if (!data?.length) return { error: "Cliente não encontrado." };

  revalidatePath("/clientes");
  if (id) revalidatePath(`/clientes/${id}`);
  return { ok: true, id: data[0].id as string, message: id ? "Cliente atualizado" : "Cliente adicionado" };
}
