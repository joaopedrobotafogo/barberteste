export default function Loading() {
  return (
    <div aria-busy="true" aria-label="Carregando clientes">
      <div className="mb-6 h-9 w-40 animate-pulse rounded-lg bg-ink/[0.06]" />
      <div className="mb-3 h-12 animate-pulse rounded-xl bg-ink/[0.06]" />
      <div className="mb-5 flex gap-2">{[0, 1, 2, 3].map((i) => <div key={i} className="h-10 w-20 animate-pulse rounded-full bg-ink/[0.06]" />)}</div>
      <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">
        {[0, 1, 2, 3, 4, 5].map((i) => (
          <li key={i} className="flex h-[72px] items-center gap-3 px-4">
            <div className="h-11 w-11 animate-pulse rounded-full bg-ink/[0.06]" />
            <div className="flex-1 space-y-2"><div className="h-4 w-1/2 animate-pulse rounded bg-ink/[0.06]" /><div className="h-3 w-1/3 animate-pulse rounded bg-ink/[0.06]" /></div>
          </li>
        ))}
      </ul>
    </div>
  );
}
