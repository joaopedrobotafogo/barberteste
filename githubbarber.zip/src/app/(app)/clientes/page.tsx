import type { Metadata } from "next";
import Link from "next/link";
import { getContext } from "@/lib/auth";
import { FILTERS, getTimezone, isFilter, isSort, lastVisitLabel, type FilterKey, type SortKey } from "@/lib/clients";
import { brl } from "@/lib/format";
import type { ClientOverview } from "@/lib/types";
import { Avatar, EmptyState, ErrorNote, Icon, PageHeader } from "@/components/ui";
import { NewClientButton, SortSelect } from "@/components/client-forms";
import { StatusBadge, VipBadge } from "@/components/client-badges";

export const metadata: Metadata = { title: "Clientes" };

const PAGE_SIZE = 20;
type Row = Pick<ClientOverview, "id" | "name" | "phone" | "status" | "is_vip" | "visits" | "total_spent" | "last_visit_at">;

function href(p: { q?: string; filtro?: FilterKey; ordem?: SortKey; page?: number }) {
  const sp = new URLSearchParams();
  if (p.q) sp.set("q", p.q);
  if (p.filtro && p.filtro !== "todos") sp.set("filtro", p.filtro);
  if (p.ordem && p.ordem !== "nome") sp.set("ordem", p.ordem);
  if (p.page && p.page > 1) sp.set("page", String(p.page));
  const s = sp.toString();
  return s ? `/clientes?${s}` : "/clientes";
}

export default async function ClientsPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const sp = await searchParams;
  const q = (sp.q ?? "").trim().slice(0, 60);
  const filtro: FilterKey = isFilter(sp.filtro) ? sp.filtro : "todos";
  const ordem: SortKey = isSort(sp.ordem) ? sp.ordem : "nome";
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const { supabase } = await getContext();
  const tz = await getTimezone(supabase);

  // Métricas e status vêm da view client_overview (calculados no banco, respeitando a RLS).
  let query = supabase
    .from("client_overview")
    .select("id, name, phone, status, is_vip, visits, total_spent, last_visit_at", { count: "exact" });

  if (filtro === "ativos") query = query.eq("status", "active");
  if (filtro === "risco") query = query.eq("status", "at_risk");
  if (filtro === "perdidos") query = query.eq("status", "lost");
  if (filtro === "vip") query = query.eq("is_vip", true);

  if (q) {
    const safe = q.replace(/[,()%*\\"]/g, " ").trim(); // caracteres que quebram a sintaxe do or()
    const digits = q.replace(/\D/g, "");
    const parts: string[] = [];
    if (safe) parts.push(`name.ilike.*${safe}*`);
    if (digits.length >= 3) parts.push(`phone_normalized.ilike.*${digits}*`);
    if (parts.length) query = query.or(parts.join(","));
  }

  if (ordem === "nome") query = query.order("name");
  if (ordem === "recentes") query = query.order("last_visit_at", { ascending: false, nullsFirst: false }).order("name");
  if (ordem === "gasto") query = query.order("total_spent", { ascending: false }).order("name");
  if (ordem === "visitas") query = query.order("visits", { ascending: false }).order("name");
  query = query.order("id"); // desempate estável para a paginação

  const from = (page - 1) * PAGE_SIZE;
  const { data, count, error } = await query.range(from, from + PAGE_SIZE - 1);
  if (error) console.error("[clientes] consulta falhou:", error);

  const rows = (data ?? []) as Row[];
  const total = count ?? 0;
  const lastPage = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const filtered = !!q || filtro !== "todos";

  return (
    <>
      <PageHeader title="Clientes" subtitle={error ? undefined : `${total} ${total === 1 ? "cliente" : "clientes"}${filtered ? " encontrados" : ""}`}
        action={<NewClientButton compact />} />

      <form action="/clientes" method="get" className="mb-3 flex gap-2">
        {filtro !== "todos" && <input type="hidden" name="filtro" value={filtro} />}
        <label className="relative min-w-0 flex-1">
          <span className="sr-only">Buscar por nome ou telefone</span>
          <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 h-[18px] w-[18px] -translate-y-1/2 text-muted" />
          <input name="q" defaultValue={q} type="search" placeholder="Buscar nome ou telefone" autoComplete="off"
            className="h-12 w-full rounded-xl border border-line bg-surface pl-10 pr-4 text-base outline-none placeholder:text-muted/70 focus:border-primary focus:ring-2 focus:ring-primary/15" />
        </label>
        <SortSelect defaultValue={ordem} />
      </form>

      <nav aria-label="Filtros" className="-mx-4 mb-5 flex gap-2 overflow-x-auto px-4 pb-1 md:mx-0 md:px-0">
        {FILTERS.map((f) => (
          <Link key={f.key} href={href({ q, filtro: f.key, ordem })} aria-current={filtro === f.key ? "true" : undefined}
            className={`flex h-10 shrink-0 items-center rounded-full border px-4 text-sm font-medium transition-colors ${filtro === f.key ? "border-primary bg-primary text-primary-foreground" : "border-line bg-surface text-ink/70 hover:text-ink"}`}>
            {f.label}
          </Link>
        ))}
      </nav>

      {error ? (
        <ErrorNote>Não foi possível carregar os clientes. Atualize a página ou tente novamente em instantes.</ErrorNote>
      ) : total === 0 && !filtered ? (
        <EmptyState title="Você ainda não possui clientes."
          text="Cadastre seus clientes para acompanhar histórico, gastos e quem está há muito tempo sem voltar."
          action={<NewClientButton />} />
      ) : total === 0 ? (
        <EmptyState title="Nenhum cliente encontrado."
          text="Tente outra busca ou outro filtro."
          action={<Link href="/clientes" className="flex h-12 items-center rounded-xl border border-line bg-surface px-5 text-[15px] font-medium">Limpar filtros</Link>} />
      ) : (
        <>
          <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">
            {rows.map((c) => (
              <li key={c.id}>
                <Link href={`/clientes/${c.id}`} className="flex min-h-[72px] items-center gap-3 px-4 py-3 hover:bg-muted-bg">
                  <Avatar name={c.name} />
                  <span className="min-w-0 flex-1">
                    <span className="flex items-center gap-2">
                      <span className="truncate text-[15px] font-medium">{c.name}</span>
                      {c.is_vip && <VipBadge />}
                    </span>
                    <span className="block truncate text-sm text-muted">{c.phone}</span>
                    <span className="mt-1 flex items-center gap-2 text-xs text-muted">
                      <StatusBadge status={c.status} /> {lastVisitLabel(c.last_visit_at, tz)}
                    </span>
                  </span>
                  <span className="shrink-0 text-right">
                    <span className="block text-[15px] font-medium">{brl(c.total_spent)}</span>
                    <span className="block text-xs text-muted">{c.visits} {c.visits === 1 ? "atendimento" : "atendimentos"}</span>
                  </span>
                </Link>
              </li>
            ))}
          </ul>

          {lastPage > 1 && (
            <nav aria-label="Paginação" className="mt-5 flex items-center justify-between text-sm">
              {page > 1 ? (
                <Link href={href({ q, filtro, ordem, page: page - 1 })} className="flex h-11 items-center rounded-xl border border-line bg-surface px-4 font-medium">Anterior</Link>
              ) : <span className="h-11 w-24" />}
              <span className="text-muted">Página {page} de {lastPage}</span>
              {page < lastPage ? (
                <Link href={href({ q, filtro, ordem, page: page + 1 })} className="flex h-11 items-center rounded-xl border border-line bg-surface px-4 font-medium">Próxima</Link>
              ) : <span className="h-11 w-24" />}
            </nav>
          )}
        </>
      )}
    </>
  );
}
