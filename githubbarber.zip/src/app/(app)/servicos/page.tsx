import type { Metadata } from "next";
import { requireOwner } from "@/lib/auth";
import { ServiceManager } from "@/components/service-manager";
import type { Service } from "@/lib/types";

export const metadata: Metadata = { title: "Serviços" };

export default async function ServicesPage() {
  const { supabase } = await requireOwner();
  const { data } = await supabase
    .from("services")
    .select("id, name, description, price, duration_minutes, is_active")
    .is("deleted_at", null)
    .order("name");
  return <ServiceManager services={(data ?? []) as Service[]} />;
}
