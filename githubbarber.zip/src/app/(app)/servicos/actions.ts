"use server";

import { revalidatePath } from "next/cache";
import { requireOwner } from "@/lib/auth";
import { parseMoney } from "@/lib/format";
import type { FormState } from "@/lib/types";

const FAIL = "Não foi possível salvar. Tente novamente.";

export async function saveService(_: FormState, fd: FormData): Promise<FormState> {
  const { supabase, org } = await requireOwner();
  const id = String(fd.get("id") ?? "");
  const name = String(fd.get("name") ?? "").trim();
  const description = String(fd.get("description") ?? "").trim();
  const price = parseMoney(String(fd.get("price") ?? ""));
  const duration = Number(fd.get("duration_minutes"));

  if (!name) return { error: "Informe o nome do serviço." };
  if (price === null) return { error: "Informe um preço válido." };
  if (!Number.isInteger(duration) || duration < 5 || duration > 480) {
    return { error: "A duração deve ficar entre 5 e 480 minutos." };
  }

  const payload = {
    name,
    description: description || null,
    price,
    duration_minutes: duration,
    is_active: fd.get("is_active") === "on",
  };
  // A RLS garante organização e papel; organization_id é enviado só na criação.
  const { error } = id
    ? await supabase.from("services").update(payload).eq("id", id)
    : await supabase.from("services").insert({ ...payload, organization_id: org.id });
  if (error) return { error: FAIL };

  revalidatePath("/servicos");
  return { ok: true, message: id ? "Serviço atualizado" : "Serviço criado" };
}

export async function toggleService(id: string, active: boolean): Promise<FormState> {
  const { supabase } = await requireOwner();
  const { error } = await supabase.from("services").update({ is_active: active }).eq("id", id);
  if (error) return { error: "Não foi possível alterar o serviço." };
  revalidatePath("/servicos");
  return { ok: true, message: active ? "Serviço ativado" : "Serviço desativado" };
}
