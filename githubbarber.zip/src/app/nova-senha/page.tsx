import type { Metadata } from "next";
import { NewPasswordForm } from "@/components/auth-forms";
import { Logo } from "@/components/brand/logo";

export const metadata: Metadata = { title: "Nova senha" };

// Rota protegida pelo middleware: só chega aqui com sessão (link de convite ou recuperação já validado).
export default function NewPasswordPage() {
  return (
    <main className="flex min-h-dvh items-center justify-center bg-background px-4 py-10">
      <div className="animate-fade-up w-full max-w-md">
        <div className="mb-8 flex justify-center"><Logo variant="full" height={40} /></div>
        <div className="rounded-3xl border border-border bg-card p-6 shadow-card sm:p-8">
          <h1 className="mb-1 text-[28px] font-bold tracking-tight">Crie sua senha</h1>
          <p className="mb-8 text-[15px] text-muted">Use pelo menos 8 caracteres.</p>
          <NewPasswordForm />
        </div>
      </div>
    </main>
  );
}
