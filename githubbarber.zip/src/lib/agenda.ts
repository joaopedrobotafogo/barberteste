import type { AppointmentStatus } from "@/lib/types";

export interface OpeningDay { open: string; close: string }
export type OpeningHours = Record<string, OpeningDay | null>;

export interface AgendaAppt {
  id: string;
  clientId: string; clientName: string; clientPhone: string;
  serviceId: string; serviceName: string;
  barberId: string; barberName: string;
  date: string;      // YYYY-MM-DD no fuso da barbearia
  time: string;      // HH:MM
  endTime: string;   // HH:MM
  price: number;
  status: AppointmentStatus;
  notes: string | null;
  isOverbook: boolean;
}

export interface AgendaBlock {
  id: string; barberId: string; barberName: string;
  date: string; time: string; endTime: string; reason: string | null;
}

export interface ClientPick { id: string; name: string; phone: string }
export interface BarberOpt { id: string; name: string }
export interface ServiceOpt { id: string; name: string; price: number; duration_minutes: number }

/** Status que ocupam o horário do barbeiro (espelha a constraint appointments_no_overlap). */
export const ACTIVE_STATUSES = ["pending", "confirmed", "completed"] as const;
export const ALL_STATUSES: AppointmentStatus[] = ["pending", "confirmed", "completed", "cancelled", "no_show"];
export const isActiveStatus = (s: AppointmentStatus) => (ACTIVE_STATUSES as readonly string[]).includes(s);

const WEEKDAY_KEYS = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"];

// ---------------------------------------------------------------- datas (strings YYYY-MM-DD)
export const isValidYmd = (s: string): boolean => {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return false;
  const d = new Date(`${s}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s;
};

export function addDays(ymd: string, n: number): string {
  const [y, m, d] = ymd.split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

export const weekdayOf = (ymd: string): number => new Date(`${ymd}T00:00:00Z`).getUTCDay();
export const weekdayKey = (ymd: string): string => WEEKDAY_KEYS[weekdayOf(ymd)];
export const mondayOf = (ymd: string): string => addDays(ymd, -((weekdayOf(ymd) + 6) % 7));

export const todayIn = (tz: string): string =>
  new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());

const cap = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
const fmtUtc = (ymd: string, o: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat("pt-BR", { timeZone: "UTC", ...o }).format(new Date(`${ymd}T00:00:00Z`));

export const dayLong = (ymd: string) => cap(fmtUtc(ymd, { weekday: "long", day: "2-digit", month: "long" }));
export const weekdayShort = (ymd: string) => cap(fmtUtc(ymd, { weekday: "short" }).replace(".", ""));
export const dayNum = (ymd: string) => ymd.slice(8, 10);
export const dayMonth = (ymd: string) => `${ymd.slice(8, 10)}/${ymd.slice(5, 7)}`;

// ---------------------------------------------------------------- fuso horário da barbearia
function tzOffsetMs(utcMs: number, tz: string): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  }).formatToParts(new Date(utcMs));
  const g = (t: string) => Number(parts.find((p) => p.type === t)?.value);
  const asUtc = Date.UTC(g("year"), g("month") - 1, g("day"), g("hour"), g("minute"), g("second"));
  return asUtc - Math.floor(utcMs / 1000) * 1000;
}

/** Data + hora locais da barbearia -> instante UTC. */
export function zonedToUtc(ymd: string, hm: string, tz: string): Date {
  const [y, m, d] = ymd.split("-").map(Number);
  const [h, mi] = hm.split(":").map(Number);
  const guess = Date.UTC(y, m - 1, d, h, mi);
  const first = guess - tzOffsetMs(guess, tz);
  return new Date(guess - tzOffsetMs(first, tz));
}

/** Instante -> data e hora locais da barbearia. */
export function localParts(iso: string, tz: string): { date: string; time: string } {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit",
  }).formatToParts(new Date(iso));
  const g = (t: string) => parts.find((p) => p.type === t)?.value ?? "00";
  return { date: `${g("year")}-${g("month")}-${g("day")}`, time: `${g("hour")}:${g("minute")}` };
}

// ---------------------------------------------------------------- horários livres
const toMin = (hm: string) => { const [h, m] = hm.split(":").map(Number); return h * 60 + m; };
const fromMin = (n: number) => `${String(Math.floor(n / 60)).padStart(2, "0")}:${String(n % 60).padStart(2, "0")}`;

export interface BusyRange { start: number; end: number } // epoch ms

/**
 * Horários de início possíveis num dia, para uma duração. Função pura:
 * usada pela tela de agenda hoje e por get_available_slots() (IA/WhatsApp) no futuro.
 */
export function computeSlots(o: {
  date: string; tz: string; hours: OpeningDay | null; durationMin: number;
  intervalMin: number; minNoticeMin: number; busy: BusyRange[]; now?: number;
}): string[] {
  if (!o.hours) return [];
  const now = o.now ?? Date.now();
  const open = toMin(o.hours.open);
  const close = toMin(o.hours.close);
  const step = Math.max(5, o.intervalMin);
  const out: string[] = [];
  for (let t = open; t + o.durationMin <= close; t += step) {
    const hm = fromMin(t);
    const start = zonedToUtc(o.date, hm, o.tz).getTime();
    const end = start + o.durationMin * 60_000;
    if (start < now + o.minNoticeMin * 60_000) continue;
    if (o.busy.some((b) => start < b.end && end > b.start)) continue;
    out.push(hm);
  }
  return out;
}
