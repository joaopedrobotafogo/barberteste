import type { getContext } from "@/lib/auth";
import type { OpeningDay } from "@/lib/agenda";
import { parseMoney } from "@/lib/format";

type Ctx = Awaited<ReturnType<typeof getContext>>;

// ---------------------------------------------------------------- tipos
export const DAYS = [
  { key: "mon", label: "Segunda-feira" },
  { key: "tue", label: "Terça-feira" },
  { key: "wed", label: "Quarta-feira" },
  { key: "thu", label: "Quinta-feira" },
  { key: "fri", label: "Sexta-feira" },
  { key: "sat", label: "Sábado" },
  { key: "sun", label: "Domingo" },
] as const;

export type DayKey = (typeof DAYS)[number]["key"];
/** Mesmo formato de business_settings.opening_hours; dia fechado = null. */
export type HoursInput = Record<DayKey, OpeningDay | null>;

/** Colunas de business_settings editáveis na tela de Configurações. */
export interface BusinessSettings {
  timezone: string;
  opening_hours: HoursInput;
  slot_interval_minutes: number;
  min_notice_minutes: number;
  allow_overbooking: boolean;
  risk_after_days: number;
  lost_after_days: number;
  vip_min_visits: number;
  vip_min_spent: number;
}

export interface HoursForm { timezone: string; hours: HoursInput }
export interface AgendaForm { slotInterval: number; minNotice: number; allowOverbooking: boolean }
/** vipSpent chega como texto digitado (ex.: "500,00"). */
export interface ClientRulesForm { riskDays: string; lostDays: string; vipVisits: string; vipSpent: string }

// ---------------------------------------------------------------- opções de tela
export const TIMEZONES: { value: string; label: string }[] = [
  { value: "America/Sao_Paulo", label: "Brasília, São Paulo, Rio (UTC−3)" },
  { value: "America/Bahia", label: "Salvador (UTC−3)" },
  { value: "America/Fortaleza", label: "Fortaleza (UTC−3)" },
  { value: "America/Recife", label: "Recife (UTC−3)" },
  { value: "America/Belem", label: "Belém (UTC−3)" },
  { value: "America/Maceio", label: "Maceió (UTC−3)" },
  { value: "America/Araguaina", label: "Araguaína (UTC−3)" },
  { value: "America/Santarem", label: "Santarém (UTC−3)" },
  { value: "America/Campo_Grande", label: "Campo Grande (UTC−4)" },
  { value: "America/Cuiaba", label: "Cuiabá (UTC−4)" },
  { value: "America/Manaus", label: "Manaus (UTC−4)" },
  { value: "America/Porto_Velho", label: "Porto Velho (UTC−4)" },
  { value: "America/Boa_Vista", label: "Boa Vista (UTC−4)" },
  { value: "America/Rio_Branco", label: "Rio Branco (UTC−5)" },
  { value: "America/Eirunepe", label: "Eirunepé (UTC−5)" },
  { value: "America/Noronha", label: "Fernando de Noronha (UTC−2)" },
];

export const INTERVAL_OPTIONS = [5, 10, 15, 20, 30, 45, 60];
export const NOTICE_OPTIONS = [0, 15, 30, 60, 120, 240, 720, 1440];

export function minutesLabel(min: number): string {
  if (min === 0) return "Sem antecedência";
  if (min % 1440 === 0) return min === 1440 ? "1 dia" : `${min / 1440} dias`;
  if (min % 60 === 0) return min === 60 ? "1 hora" : `${min / 60} horas`;
  return `${min} minutos`;
}

// ---------------------------------------------------------------- leitura
const isRecord = (x: unknown): x is Record<string, unknown> =>
  typeof x === "object" && x !== null && !Array.isArray(x);

/** Aceita o jsonb do banco e devolve sempre os 7 dias (ausente/inválido = fechado). */
export function normalizeHours(raw: unknown): HoursInput {
  const src = isRecord(raw) ? raw : {};
  const out = {} as HoursInput;
  for (const { key } of DAYS) {
    const d = src[key];
    out[key] = isRecord(d) && typeof d.open === "string" && typeof d.close === "string"
      ? { open: d.open, close: d.close }
      : null;
  }
  return out;
}

/** null = erro ao consultar ou linha inexistente (a tela mostra estado de erro, nunca valores inventados). */
export async function loadBusinessSettings(ctx: Ctx): Promise<BusinessSettings | null> {
  const { data, error } = await ctx.supabase
    .from("business_settings")
    .select("timezone, opening_hours, slot_interval_minutes, min_notice_minutes, allow_overbooking, risk_after_days, lost_after_days, vip_min_visits, vip_min_spent")
    .eq("organization_id", ctx.org.id)
    .maybeSingle();
  if (error) { console.error("[configuracoes] carregar:", error); return null; }
  if (!data) return null;
  const r = data as unknown as Record<string, unknown>;
  return {
    timezone: String(r.timezone),
    opening_hours: normalizeHours(r.opening_hours),
    slot_interval_minutes: Number(r.slot_interval_minutes),
    min_notice_minutes: Number(r.min_notice_minutes),
    allow_overbooking: Boolean(r.allow_overbooking),
    risk_after_days: Number(r.risk_after_days),
    lost_after_days: Number(r.lost_after_days),
    vip_min_visits: Number(r.vip_min_visits),
    vip_min_spent: Number(r.vip_min_spent),
  };
}

// ---------------------------------------------------------------- validação (roda no servidor)
export type Checked<T> = { ok: true; value: T } | { ok: false; error: string };
const fail = (error: string): { ok: false; error: string } => ({ ok: false, error });

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const toMin = (hm: string) => { const [h, m] = hm.split(":").map(Number); return h * 60 + m; };

function wholeNumber(x: unknown, min: number, max: number): number | null {
  const n = typeof x === "number" ? x : typeof x === "string" && x.trim() !== "" ? Number(x) : NaN;
  return Number.isInteger(n) && n >= min && n <= max ? n : null;
}

export function validateOrgName(input: unknown): Checked<string> {
  const name = typeof input === "string" ? input.trim() : "";
  if (!name) return fail("Informe o nome da barbearia.");
  if (name.length > 100) return fail("O nome pode ter no máximo 100 caracteres.");
  return { ok: true, value: name };
}

export function validateHoursForm(input: unknown): Checked<HoursForm> {
  if (!isRecord(input)) return fail("Dados inválidos.");
  const timezone = typeof input.timezone === "string" ? input.timezone : "";
  if (!TIMEZONES.some((t) => t.value === timezone)) return fail("Escolha um fuso horário válido.");
  if (!isRecord(input.hours)) return fail("Dados inválidos.");

  const hours = {} as HoursInput;
  for (const { key, label } of DAYS) {
    const d = input.hours[key];
    if (d === null || d === undefined) { hours[key] = null; continue; }
    if (!isRecord(d) || typeof d.open !== "string" || typeof d.close !== "string"
      || !TIME_RE.test(d.open) || !TIME_RE.test(d.close)) {
      return fail(`${label}: informe horários válidos.`);
    }
    if (toMin(d.close) <= toMin(d.open)) return fail(`${label}: o fechamento deve ser depois da abertura.`);
    hours[key] = { open: d.open, close: d.close };
  }
  if (DAYS.every(({ key }) => hours[key] === null)) return fail("Deixe pelo menos um dia aberto.");
  return { ok: true, value: { timezone, hours } };
}

export function validateAgendaRules(input: unknown): Checked<AgendaForm> {
  if (!isRecord(input)) return fail("Dados inválidos.");
  const slotInterval = wholeNumber(input.slotInterval, 5, 120);
  if (slotInterval === null) return fail("O intervalo entre horários deve ficar entre 5 e 120 minutos.");
  const minNotice = wholeNumber(input.minNotice, 0, 10080);
  if (minNotice === null) return fail("A antecedência mínima deve ficar entre 0 minutos e 7 dias.");
  if (typeof input.allowOverbooking !== "boolean") return fail("Dados inválidos.");
  return { ok: true, value: { slotInterval, minNotice, allowOverbooking: input.allowOverbooking } };
}

export interface ClientRules { riskDays: number; lostDays: number; vipVisits: number; vipSpent: number }

export function validateClientRules(input: unknown): Checked<ClientRules> {
  if (!isRecord(input)) return fail("Dados inválidos.");
  const riskDays = wholeNumber(input.riskDays, 1, 3650);
  if (riskDays === null) return fail("Informe os dias para \"em risco\" (de 1 a 3650).");
  const lostDays = wholeNumber(input.lostDays, 1, 3650);
  if (lostDays === null) return fail("Informe os dias para \"perdido\" (de 1 a 3650).");
  if (lostDays <= riskDays) return fail("O prazo de \"perdido\" deve ser maior que o de \"em risco\".");
  const vipVisits = wholeNumber(input.vipVisits, 1, 1000);
  if (vipVisits === null) return fail("Informe as visitas para VIP (de 1 a 1000).");
  // parseMoney("abc") devolve 0 (remove tudo que não é dígito); aqui exigimos ao menos um dígito.
  const vipSpent = typeof input.vipSpent === "string" && /\d/.test(input.vipSpent) ? parseMoney(input.vipSpent) : null;
  if (vipSpent === null || vipSpent > 99_999_999.99) return fail("Informe um valor válido para VIP.");
  return { ok: true, value: { riskDays, lostDays, vipVisits, vipSpent } };
}
