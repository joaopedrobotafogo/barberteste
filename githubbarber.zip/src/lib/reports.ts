import type { getContext } from "@/lib/auth";
import { localParts } from "@/lib/agenda";
import {
  daysBetween, loadRevenueBase, periodRange, type DayPoint, type GroupStat, type PeriodKey,
} from "@/lib/finance";
import { getTimezone } from "@/lib/clients";
import type { ClientStatus } from "@/lib/types";

type Ctx = Awaited<ReturnType<typeof getContext>>;

export const NOT_RETURNED_LIMIT = 10;
const NEW_CLIENT_ROWS = 1000; // limite padrão do PostgREST por requisição
const ID_CHUNK = 100;         // ids por consulta .in() (evita URL gigante)

export interface NotReturnedItem {
  id: string; name: string; status: ClientStatus; isVip: boolean; visits: number; lastVisitAt: string | null;
}

export interface ReportsData {
  tz: string; period: PeriodKey; startDay: string; today: string;
  revenue: {
    error: boolean; truncated: boolean;
    total: number; count: number; avgTicket: number; servedClients: number;
    days: DayPoint[]; byService: GroupStat[]; byBarber: GroupStat[];
  };
  newClients: { error: boolean; count: number; perDay: { date: string; count: number }[] | null };
  recurring: { error: boolean; count: number };
  notReturned: { error: boolean; atRisk: number; lost: number; items: NotReturnedItem[] };
}

const byCount = (a: GroupStat, b: GroupStat) =>
  b.count - a.count || b.revenue - a.revenue || a.name.localeCompare(b.name, "pt-BR");

/**
 * Relatórios reaproveitam a base do Financeiro (loadRevenueBase): mesma consulta de pagamentos, mesmo
 * faturamento/atendimentos/ticket. Todo o resto vem de clients/client_overview (RLS + organization_id).
 */
export async function loadReports(ctx: Ctx, period: PeriodKey): Promise<ReportsData> {
  const { supabase, org } = ctx;
  const tz = await getTimezone(supabase);
  const { from, to, startDay, today } = periodRange(period, tz);

  const overview = () => supabase.from("client_overview");
  const [base, newRes, riskRes, lostRes, listRes] = await Promise.all([
    loadRevenueBase(ctx, period, tz),
    // clientes novos = clientes cadastrados no período (mesma definição do Dashboard)
    supabase.from("clients").select("created_at", { count: "exact" })
      .eq("organization_id", org.id).is("deleted_at", null)
      .gte("created_at", from).lt("created_at", to)
      .order("created_at").range(0, NEW_CLIENT_ROWS - 1),
    // clientes que não retornaram: status centralizado no banco (client_status via client_overview)
    overview().select("id", { count: "exact", head: true }).eq("organization_id", org.id).eq("status", "at_risk"),
    overview().select("id", { count: "exact", head: true }).eq("organization_id", org.id).eq("status", "lost"),
    overview().select("id, name, status, is_vip, visits, last_visit_at")
      .eq("organization_id", org.id).in("status", ["at_risk", "lost"])
      .order("status") // 'at_risk' antes de 'lost'
      .order("visits", { ascending: false })
      .order("last_visit_at", { ascending: false, nullsFirst: false })
      .order("id")
      .limit(NOT_RETURNED_LIMIT),
  ]);

  if (newRes.error) console.error("[relatorios] clientes novos:", newRes.error);
  if (riskRes.error || lostRes.error || listRes.error) {
    console.error("[relatorios] não retornaram:", riskRes.error ?? lostRes.error ?? listRes.error);
  }

  // ---- clientes novos (+ evolução por dia, só se todas as linhas couberam na consulta)
  const newTotal = newRes.count ?? 0;
  let perDay: { date: string; count: number }[] | null = null;
  if (!newRes.error && newTotal <= NEW_CLIENT_ROWS) {
    const acc = new Map<string, number>();
    for (const r of (newRes.data ?? []) as { created_at: string }[]) {
      const d = localParts(r.created_at, tz).date;
      acc.set(d, (acc.get(d) ?? 0) + 1);
    }
    perDay = daysBetween(startDay, today).map((date) => ({ date, count: acc.get(date) ?? 0 }));
  }

  // ---- clientes recorrentes: atendidos no período (com pagamento) que têm 2+ atendimentos concluídos
  //      no total (client_overview.visits). Consulta em blocos de ids, em paralelo.
  let recurringCount = 0;
  let recurringError = false;
  if (!base.error && base.clientIds.length) {
    const chunks: string[][] = [];
    for (let i = 0; i < base.clientIds.length; i += ID_CHUNK) chunks.push(base.clientIds.slice(i, i + ID_CHUNK));
    const results = await Promise.all(chunks.map((ids) =>
      overview().select("id, visits").eq("organization_id", org.id).in("id", ids)));
    for (const res of results) {
      if (res.error) { console.error("[relatorios] recorrentes:", res.error); recurringError = true; break; }
      recurringCount += ((res.data ?? []) as { visits: number | string }[]).filter((c) => Number(c.visits) >= 2).length;
    }
  }

  return {
    tz, period, startDay, today,
    revenue: {
      error: base.error, truncated: base.truncated,
      total: base.total, count: base.count, avgTicket: base.avgTicket, servedClients: base.clientIds.length,
      days: base.days,
      byService: [...base.byService].sort(byCount),
      byBarber: [...base.byBarber].sort(byCount),
    },
    newClients: { error: !!newRes.error, count: newTotal, perDay },
    recurring: { error: base.error || recurringError, count: recurringCount },
    notReturned: {
      error: !!(riskRes.error || lostRes.error || listRes.error),
      atRisk: riskRes.count ?? 0,
      lost: lostRes.count ?? 0,
      items: ((listRes.data ?? []) as { id: string; name: string; status: ClientStatus; is_vip: boolean; visits: number | string; last_visit_at: string | null }[])
        .map((r) => ({ id: r.id, name: r.name, status: r.status, isVip: r.is_vip, visits: Number(r.visits), lastVisitAt: r.last_visit_at })),
    },
  };
}
