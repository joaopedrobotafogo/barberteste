import type { SupabaseClient } from "@supabase/supabase-js";
import type { AppointmentStatus, ClientStatus } from "@/lib/types";

export const FILTERS = [
  { key: "todos", label: "Todos" },
  { key: "ativos", label: "Ativos" },
  { key: "risco", label: "Em risco" },
  { key: "perdidos", label: "Perdidos" },
  { key: "vip", label: "VIP" },
] as const;
export type FilterKey = (typeof FILTERS)[number]["key"];
export const isFilter = (v?: string): v is FilterKey => FILTERS.some((f) => f.key === v);

export const SORTS = [
  { key: "nome", label: "Nome" },
  { key: "recentes", label: "Mais recentes" },
  { key: "gasto", label: "Maior gasto" },
  { key: "visitas", label: "Mais visitas" },
] as const;
export type SortKey = (typeof SORTS)[number]["key"];
export const isSort = (v?: string): v is SortKey => SORTS.some((s) => s.key === v);

/** Rótulos e cores. A DEFINIÇÃO de ativo/em risco/perdido/VIP fica no banco (client_status + client_overview). */
export const STATUS_LABEL: Record<ClientStatus, string> = {
  new: "Novo", active: "Ativo", at_risk: "Em risco", lost: "Perdido",
};
export const STATUS_STYLE: Record<ClientStatus, string> = {
  new: "bg-ink/5 text-muted",
  active: "bg-ok/10 text-ok",
  at_risk: "bg-warning/10 text-warning",
  lost: "bg-danger/10 text-danger",
};
export const APPT_LABEL: Record<AppointmentStatus, string> = {
  pending: "Aguardando", confirmed: "Confirmado", completed: "Concluído", cancelled: "Cancelado", no_show: "No-show",
};
export const APPT_STYLE: Record<AppointmentStatus, string> = {
  pending: "text-warning", confirmed: "text-ink", completed: "text-ok", cancelled: "text-muted", no_show: "text-danger",
};

export const DEFAULT_TZ = "America/Sao_Paulo";

export async function getTimezone(supabase: SupabaseClient): Promise<string> {
  const { data } = await supabase.from("business_settings").select("timezone").maybeSingle();
  return (data?.timezone as string | undefined) ?? DEFAULT_TZ;
}

const ymd = (d: Date, tz: string) =>
  new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);

export function daysSince(iso: string, tz: string, now = new Date()): number {
  const [y1, m1, d1] = ymd(new Date(iso), tz).split("-").map(Number);
  const [y2, m2, d2] = ymd(now, tz).split("-").map(Number);
  return Math.round((Date.UTC(y2, m2 - 1, d2) - Date.UTC(y1, m1 - 1, d1)) / 86_400_000);
}

export function lastVisitLabel(iso: string | null, tz: string): string {
  if (!iso) return "Sem atendimentos";
  const d = daysSince(iso, tz);
  return d <= 0 ? "Hoje" : d === 1 ? "Ontem" : `Há ${d} dias`;
}

export function formatDate(iso: string, tz: string): string {
  return new Intl.DateTimeFormat("pt-BR", { timeZone: tz, day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(iso));
}

/** 18/09, ou 18/09/25 quando não é o ano atual. */
export function shortDate(iso: string, tz: string): string {
  const same = ymd(new Date(iso), tz).slice(0, 4) === ymd(new Date(), tz).slice(0, 4);
  return new Intl.DateTimeFormat("pt-BR", { timeZone: tz, day: "2-digit", month: "2-digit", ...(same ? {} : { year: "2-digit" }) }).format(new Date(iso));
}

/** 'YYYY-MM-DD' (coluna date) -> dd/MM/yyyy, sem passar por fuso. */
export function formatDateOnly(s: string): string {
  const [y, m, d] = s.split("-");
  return `${d}/${m}/${y}`;
}

export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
