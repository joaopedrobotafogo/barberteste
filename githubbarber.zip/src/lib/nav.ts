import type { Role } from "./types";

export type IconName =
  | "home" | "calendar" | "user" | "scissors" | "users" | "wallet" | "chart"
  | "settings" | "search" | "more" | "bell" | "plus" | "logout" | "mail" | "chevron" | "check"
  | "clock" | "userPlus" | "ticket" | "palette" | "refresh" | "alert" | "send";

export interface NavItem { href: string; label: string; icon: IconName; ownerOnly?: boolean }

export const NAV: NavItem[] = [
  { href: "/", label: "Início", icon: "home" },
  { href: "/agenda", label: "Agenda", icon: "calendar" },
  { href: "/clientes", label: "Clientes", icon: "user" },
  { href: "/servicos", label: "Serviços", icon: "scissors", ownerOnly: true },
  { href: "/equipe", label: "Equipe", icon: "users", ownerOnly: true },
  { href: "/financeiro", label: "Financeiro", icon: "wallet", ownerOnly: true },
  { href: "/relatorios", label: "Relatórios", icon: "chart", ownerOnly: true },
  { href: "/configuracoes", label: "Configurações", icon: "settings", ownerOnly: true },
];

export const itemsFor = (role: Role) => NAV.filter((i) => !i.ownerOnly || role === "owner");

/** Itens do bottom nav (mobile). O restante fica em "Mais". */
export const bottomItemsFor = (role: Role) =>
  itemsFor(role).filter((i) => ["/", "/agenda", "/clientes", "/financeiro"].includes(i.href));

export const moreItemsFor = (role: Role) =>
  itemsFor(role).filter((i) => !["/", "/agenda", "/clientes", "/financeiro"].includes(i.href));
