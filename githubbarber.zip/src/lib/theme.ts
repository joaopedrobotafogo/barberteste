/**
 * Paletas do BarberFlow. As CORES em si ficam em src/app/globals.css (variáveis CSS por [data-theme]).
 * Este arquivo só guarda o catálogo (ids, nomes e amostras para a tela de Aparência).
 *
 * Para adicionar uma 7ª paleta: (1) acrescente um item em THEMES, (2) copie um bloco [data-theme="..."]
 * em globals.css com o mesmo id. Nenhuma página ou componente precisa mudar.
 */
export const THEME_COOKIE = "bf-theme";
export const THEME_COOKIE_MAX_AGE = 60 * 60 * 24 * 365;

export interface ThemeOption {
  id: string;
  name: string;
  description: string;
  /** Amostras só para o preview na tela de Aparência (as cores reais vêm do CSS). */
  swatch: { sidebar: string; primary: string; light: string };
}

export const THEMES = [
  { id: "ocean", name: "Ocean", description: "Azul e azul-marinho", swatch: { sidebar: "#0B1F3F", primary: "#2563EB", light: "#E8F0FE" } },
  { id: "royal", name: "Royal", description: "Roxo e índigo", swatch: { sidebar: "#1C163D", primary: "#6D28D9", light: "#F3EEFE" } },
  { id: "emerald", name: "Emerald", description: "Verde e verde-escuro", swatch: { sidebar: "#062C24", primary: "#047857", light: "#E3F6EE" } },
  { id: "sunset", name: "Sunset", description: "Laranja e terracota", swatch: { sidebar: "#331C14", primary: "#C2410C", light: "#FFF0E6" } },
  { id: "burgundy", name: "Burgundy", description: "Vinho e vermelho escuro", swatch: { sidebar: "#340E1C", primary: "#9F1239", light: "#FDECF0" } },
  { id: "obsidian", name: "Obsidian", description: "Preto e grafite", swatch: { sidebar: "#0F0F12", primary: "#18181B", light: "#F0F0F2" } },
] as const satisfies readonly ThemeOption[];

export type ThemeId = (typeof THEMES)[number]["id"];
export const DEFAULT_THEME: ThemeId = "ocean";

export const isThemeId = (v: unknown): v is ThemeId => typeof v === "string" && THEMES.some((t) => t.id === v);
export const themeOrDefault = (v: unknown): ThemeId => (isThemeId(v) ? v : DEFAULT_THEME);
