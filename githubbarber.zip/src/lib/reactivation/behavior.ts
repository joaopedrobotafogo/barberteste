import { localParts } from "@/lib/agenda";

/**
 * Comportamento individual de retorno do cliente (Etapa 11).
 *
 * FUNÇÕES PURAS: não acessam banco nem relógio (o "agora" entra como parâmetro).
 * Entrada: instantes (ISO) dos atendimentos CONCLUÍDOS do cliente. Cancelados, no-show e futuros
 * nunca chegam aqui (o service filtra por status = 'completed') e, por segurança, instantes futuros são ignorados.
 *
 * MODELO
 *  1. Visitas = DIAS distintos (no fuso da barbearia). Dois atendimentos no mesmo dia (ex.: corte + barba
 *     lançados separadamente) são uma visita só; senão apareceria um "intervalo 0".
 *  2. Intervalos = dias corridos entre visitas consecutivas.
 *  3. Outliers: com 4+ intervalos, descarta os que fogem muito do padrão do próprio cliente
 *     (escore z modificado por MAD > 3,5, com escala mínima para não punir variações normais de poucos dias).
 *  4. Intervalo habitual = MEDIANA dos intervalos mantidos (robusta; ex.: 30,31,32,33,90 → 32, e não a média 43).
 *  5. Elegível quando: visitas >= mínimo configurado  E  dias desde a última visita > habitual × (1 + margem).
 *  6. Confiança (0–100): cresce com o nº de intervalos e cai com dispersão alta/outliers.
 *     1 visita = nenhuma · 2 visitas (1 intervalo) = baixa · 3+ = melhora conforme regularidade.
 */

export type Confidence = "none" | "low" | "medium" | "high";
export type BehaviorReason = "no_visits" | "insufficient_history" | "within_habitual_range" | "behavior_due";

export interface BehaviorParams {
  /** Margem sobre o intervalo habitual (15 = 15%). */
  marginPercent: number;
  /** Mínimo de VISITAS (dias distintos) para considerar o comportamento conhecido. */
  minVisits: number;
}

export interface Behavior {
  /** Atendimentos concluídos (brutos, sem futuros). */
  completedCount: number;
  /** Visitas = dias distintos com atendimento concluído. Base de todo o cálculo. */
  visits: number;
  lastVisitAt: string | null;
  lastVisitDate: string | null;
  /** Intervalos (dias) entre visitas consecutivas, na ordem cronológica. */
  intervals: number[];
  intervalsUsed: number[];
  outliersDropped: number;
  meanIntervalDays: number | null;
  medianIntervalDays: number | null;
  /** Intervalo habitual estimado (mediana dos intervalos mantidos). null = sem histórico suficiente. */
  habitualIntervalDays: number | null;
  daysSinceLastVisit: number | null;
  /** Dias sem vir a partir dos quais o cliente entra como candidato: habitual × (1 + margem). */
  dueAfterDays: number | null;
  /** Dias sem vir MENOS o habitual (negativo = ainda dentro do ritmo normal). */
  overdueDays: number | null;
  confidence: Confidence;
  confidenceScore: number;
  /** true somente com visitas >= minVisits (e ao menos 1 intervalo). Sem isso nada é "inventado". */
  behaviorKnown: boolean;
  eligible: boolean;
  reason: BehaviorReason;
}

export const OUTLIER_Z = 3.5;
export const MIN_INTERVALS_FOR_OUTLIER_FILTER = 4;
const DAY_MS = 86_400_000;

// ---------------------------------------------------------------- estatística
const round1 = (n: number) => Math.round(n * 10) / 10;

export function median(xs: number[]): number {
  if (xs.length === 0) return NaN;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}
const mean = (xs: number[]) => xs.reduce((a, b) => a + b, 0) / xs.length;

/** Mediana dos desvios absolutos em relação à mediana. */
export function mad(xs: number[]): number {
  const m = median(xs);
  return median(xs.map((x) => Math.abs(x - m)));
}

/**
 * Remove intervalos anormais. Só age com 4+ intervalos (com menos, não há base para dizer o que é "anormal").
 * escala = max(MAD, 10% da mediana, 1 dia): evita descartar 35 num histórico 30,30,30,30 (variação normal).
 */
export function filterOutliers(intervals: number[]): { kept: number[]; dropped: number[] } {
  if (intervals.length < MIN_INTERVALS_FOR_OUTLIER_FILTER) return { kept: [...intervals], dropped: [] };
  const m = median(intervals);
  const scale = Math.max(mad(intervals), 0.1 * m, 1);
  const kept: number[] = [];
  const dropped: number[] = [];
  for (const x of intervals) {
    if ((0.6745 * Math.abs(x - m)) / scale > OUTLIER_Z) dropped.push(x);
    else kept.push(x);
  }
  return { kept, dropped };
}

// ---------------------------------------------------------------- datas
const ymdToDayNumber = (ymd: string) => {
  const [y, m, d] = ymd.split("-").map(Number);
  return Math.round(Date.UTC(y, m - 1, d) / DAY_MS);
};
export const dayDiff = (fromYmd: string, toYmd: string) => ymdToDayNumber(toYmd) - ymdToDayNumber(fromYmd);

/** Dias distintos (YYYY-MM-DD no fuso da barbearia), em ordem, ignorando instantes futuros ou inválidos. */
export function visitDays(isoDates: string[], tz: string, now: Date): { days: string[]; lastAt: string | null; count: number } {
  const set = new Set<string>();
  let lastAt: string | null = null;
  let count = 0;
  for (const iso of isoDates) {
    const t = Date.parse(iso);
    if (!Number.isFinite(t) || t > now.getTime()) continue;
    count++;
    set.add(localParts(new Date(t).toISOString(), tz).date);
    if (lastAt === null || t > Date.parse(lastAt)) lastAt = iso;
  }
  return { days: [...set].sort(), lastAt, count };
}

export function intervalsBetween(days: string[]): number[] {
  const out: number[] = [];
  for (let i = 1; i < days.length; i++) out.push(dayDiff(days[i - 1], days[i]));
  return out;
}

// ---------------------------------------------------------------- confiança
const BASE_BY_INTERVALS = [0, 30, 50, 60, 70, 80]; // índice = nº de intervalos mantidos (5+ usa o último)

export function confidenceFor(kept: number[], droppedCount: number): { level: Confidence; score: number } {
  if (kept.length === 0) return { level: "none", score: 0 };
  let score = BASE_BY_INTERVALS[Math.min(kept.length, BASE_BY_INTERVALS.length - 1)];
  if (kept.length >= 2) {
    const m = median(kept);
    const rel = m > 0 ? (1.4826 * mad(kept)) / m : 1; // dispersão relativa robusta
    score += rel <= 0.15 ? 15 : rel <= 0.3 ? 5 : rel > 0.5 ? -15 : 0;
  }
  score -= Math.min(droppedCount * 5, 15);
  score = Math.max(0, Math.min(95, score));
  return { level: score < 40 ? "low" : score < 70 ? "medium" : "high", score };
}

// ---------------------------------------------------------------- principal
export function computeBehavior(completedAt: string[], now: Date, tz: string, params: BehaviorParams): Behavior {
  const { days, lastAt, count } = visitDays(completedAt, tz, now);
  const today = localParts(now.toISOString(), tz).date;
  const lastDay = days.length ? days[days.length - 1] : null;
  const daysSince = lastDay ? Math.max(0, dayDiff(lastDay, today)) : null;

  const intervals = intervalsBetween(days);
  const { kept, dropped } = filterOutliers(intervals);

  const habitual = kept.length ? round1(median(kept)) : null;
  const known = days.length >= params.minVisits && habitual !== null;
  const dueAfter = habitual !== null ? round1(habitual * (1 + params.marginPercent / 100)) : null;
  const conf = confidenceFor(kept, dropped.length);

  const eligible = known && dueAfter !== null && daysSince !== null && daysSince > dueAfter;
  const reason: BehaviorReason =
    days.length === 0 ? "no_visits"
      : !known ? "insufficient_history"
        : eligible ? "behavior_due" : "within_habitual_range";

  return {
    completedCount: count,
    visits: days.length,
    lastVisitAt: lastAt,
    lastVisitDate: lastDay,
    intervals,
    intervalsUsed: kept,
    outliersDropped: dropped.length,
    meanIntervalDays: kept.length ? round1(mean(kept)) : null,
    medianIntervalDays: kept.length ? round1(median(kept)) : null,
    habitualIntervalDays: habitual,
    daysSinceLastVisit: daysSince,
    dueAfterDays: dueAfter,
    overdueDays: habitual !== null && daysSince !== null ? round1(daysSince - habitual) : null,
    confidence: conf.level,
    confidenceScore: conf.score,
    behaviorKnown: known,
    eligible,
    reason,
  };
}
