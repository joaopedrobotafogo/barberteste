import type { getContext } from "@/lib/auth";
import { getOverview, type Overview } from "./service";
import { ownerReactivationCtx } from "./owner";

type Ctx = Awaited<ReturnType<typeof getContext>>;

export type ReactivationView = { error: true } | { error: false; overview: Overview };

/** Só para o DONO. Reconcilia resultados (agendou/reativou/expirou) e devolve a visão da tela. Nunca derruba o Dashboard. */
export async function loadReactivationView(ctx: Ctx): Promise<ReactivationView> {
  if (ctx.profile.role !== "owner") return { error: true };
  try {
    return { error: false, overview: await getOverview(ownerReactivationCtx(ctx.org.id), { reconcile: true }) };
  } catch (e) {
    console.error("[reativacao] carregar:", e instanceof Error ? e.message : e);
    return { error: true };
  }
}
