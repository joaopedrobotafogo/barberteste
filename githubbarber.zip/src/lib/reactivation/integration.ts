import type { IntegrationCtx } from "@/lib/integration/auth";
import { ApiError } from "@/lib/integration/http";
import { optText } from "@/lib/integration/validate";
import {
  buildEvents, getOverview, getRuntimeSettings, listPending, markFailed, markResponded, markSent,
  recordOptOut, requestReactivation, type AttemptRow, type CandidateItem,
} from "./service";

/**
 * Operações da API de integração para o n8n (Etapa 11). Cada função recebe o contexto autenticado
 * (orgId vindo do TOKEN) e delega ao service compartilhado com a tela do dono.
 * O n8n NÃO recalcula elegibilidade: tudo que ele recebe foi calculado aqui.
 */

const LIST_DEFAULT = 20;
const LIST_MAX = 100;

function parseLimit(raw: unknown, def = LIST_DEFAULT): number {
  if (raw === undefined || raw === null || raw === "") return def;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 1 || n > LIST_MAX) throw new ApiError(400, "INVALID_INPUT", `'limit' deve ser um inteiro entre 1 e ${LIST_MAX}.`);
  return n;
}

/** Body opcional: vazio vale {}. Qualquer coisa que não seja objeto JSON vira 400. */
export async function readOptionalJson(req: Request): Promise<Record<string, unknown>> {
  const text = await req.text();
  if (!text.trim()) return {};
  let body: unknown;
  try { body = JSON.parse(text); } catch { throw new ApiError(400, "INVALID_BODY", "O corpo da requisição deve ser um JSON válido."); }
  if (typeof body !== "object" || body === null || Array.isArray(body)) throw new ApiError(400, "INVALID_BODY", "O corpo da requisição deve ser um objeto JSON.");
  return body as Record<string, unknown>;
}

const attemptOut = (a: AttemptRow) => ({
  id: a.id, status: a.status, origin: a.origin, requested_at: a.requested_at, sent_at: a.sent_at,
  responded_at: a.responded_at, booked_at: a.booked_at, reactivated_at: a.reactivated_at,
});

const candidateOut = (c: CandidateItem) => ({
  client: { id: c.client.id, name: c.client.name, phone: c.client.phone, whatsapp_phone: c.client.whatsappPhone },
  reactivation: {
    reason: "behavior_due" as const,
    days_since_last_visit: c.behavior.daysSinceLastVisit,
    habitual_interval_days: c.behavior.habitualIntervalDays,
    overdue_days: c.behavior.overdueDays,
    due_after_days: c.behavior.dueAfterDays,
    visits: c.behavior.visits,
    confidence: c.behavior.confidence,
    confidence_score: c.behavior.confidenceScore,
    last_visit_date: c.behavior.lastVisitDate,
  },
});

/** GET /reactivation/settings */
export async function apiSettings(ctx: IntegrationCtx) {
  const r = await getRuntimeSettings(ctx);
  const s = r.settings;
  return {
    mode: s.mode,
    margin_percent: s.marginPercent,
    min_visits: s.minVisits,
    send_window: { start: s.windowStart, end: s.windowEnd, timezone: r.timezone, open_now: r.windowOpen },
    daily_limit: s.dailyLimit,
    min_days_between_attempts: s.minDaysBetweenAttempts,
    max_attempts: s.maxAttempts,
    block_if_future_appointment: s.blockFutureAppointment,
    attribution_days: s.attributionDays,
    capacity: r.capacity,
    now: r.now.toISOString(),
  };
}

/** GET /reactivation/candidates?limit= — só quem PODE receber reativação agora (todas as proteções já aplicadas). */
export async function apiCandidates(ctx: IntegrationCtx, q: { limit: unknown }) {
  const limit = parseLimit(q.limit);
  const o = await getOverview(ctx, { reconcile: true });
  const items = o.candidates.slice(0, limit).map(candidateOut);
  return {
    mode: o.settings.mode,
    window_open: o.windowOpen,
    capacity: o.capacity,
    /** true = o modo é automático, a janela está aberta e ainda há limite diário: o n8n pode chamar /trigger. */
    can_trigger_now: o.settings.mode === "automatic" && o.windowOpen && o.capacity.remaining > 0,
    total_eligible: o.candidates.length,
    count: items.length,
    candidates: items,
  };
}

/** GET /reactivation/pending?limit= — pedidos (manuais ou automáticos) aguardando envio, com o evento completo. */
export async function apiPending(ctx: IntegrationCtx, q: { limit: unknown }) {
  return listPending(ctx, parseLimit(q.limit));
}

/** POST /reactivation/:clientId/trigger — pedido AUTOMÁTICO (exige modo automático). Mesmo service do botão "Reativar". */
export async function apiTrigger(ctx: IntegrationCtx, clientId: unknown) {
  const r = await requestReactivation(ctx, clientId, { origin: "automatic" });
  const [event] = await buildEvents(ctx, [r.attempt]);
  if (!event) throw new ApiError(404, "CLIENT_NOT_FOUND", "Cliente não encontrado.");
  return { replay: r.replay, data: { ...event, idempotent_replay: r.replay } };
}

/** POST /reactivation/:clientId/sent */
export async function apiSent(ctx: IntegrationCtx, clientId: unknown) {
  const r = await markSent(ctx, clientId);
  return { client_id: r.attempt.client_id, attempt: attemptOut(r.attempt), idempotent_replay: r.replay };
}

/** POST /reactivation/:clientId/failed — { reason? } */
export async function apiFailed(ctx: IntegrationCtx, clientId: unknown, body: Record<string, unknown>) {
  const r = await markFailed(ctx, clientId, optText(body.reason, "reason", 200));
  return { client_id: r.attempt.client_id, attempt: attemptOut(r.attempt), idempotent_replay: r.replay };
}

/** POST /reactivation/:clientId/responded */
export async function apiResponded(ctx: IntegrationCtx, clientId: unknown) {
  const r = await markResponded(ctx, clientId);
  return { client_id: r.attempt.client_id, attempt: attemptOut(r.attempt), idempotent_replay: r.replay };
}

/** POST /reactivation/:clientId/opt-out — { note? }. Bloqueia reativações futuras (manuais e automáticas). */
export async function apiOptOut(ctx: IntegrationCtx, clientId: unknown, body: Record<string, unknown>) {
  const note = optText(body.note, "note", 300);
  const r = await recordOptOut(ctx, clientId, { source: "whatsapp", note });
  return { client_id: String(clientId).toLowerCase(), opted_out: true, cancelled_pending: r.cancelledPending, idempotent_replay: r.replay };
}
