import type { SupabaseClient } from "@supabase/supabase-js";
import { addDays, localParts, zonedToUtc } from "@/lib/agenda";
import { ApiError, type ErrorCode } from "@/lib/integration/http";
import { parseBrPhone } from "@/lib/integration/phone";
import { reqUuid } from "@/lib/integration/validate";
import { computeBehavior, type Behavior } from "./behavior";
import { loadReactivationSettings, type ReactivationSettings } from "./settings";

/**
 * SERVICE ÚNICO da reativação (Etapa 11). Manual (Server Action do dono) e automático (API do n8n)
 * chamam EXATAMENTE as mesmas funções: mesma elegibilidade, mesmas proteções, mesmo registro.
 *
 * `db` pode ser o service role: toda consulta/escrita aqui filtra por organization_id (`orgId` vem da sessão
 * do dono ou do token de integração, nunca do corpo da requisição).
 *
 * Estados persistidos (reactivation_attempts.status):
 *   requested → sent → responded → booked → reactivated      (fluxo feliz)
 *   failed | cancelled | expired | dismissed                  (encerradas sem resultado / ignoradas)
 * "Candidato" NÃO é gravado: é calculado na hora.
 */

export interface RCtx {
  db: SupabaseClient;
  orgId: string;
  /** Relógio injetável (testes). Padrão: agora. */
  now?: () => Date;
}

export type AttemptStatus =
  | "requested" | "sent" | "responded" | "booked" | "reactivated" | "failed" | "cancelled" | "expired" | "dismissed";
export type AttemptOrigin = "manual" | "automatic";

export interface AttemptRow {
  id: string;
  organization_id: string;
  client_id: string;
  origin: AttemptOrigin;
  status: AttemptStatus;
  reason: string;
  snapshot: Record<string, unknown>;
  requested_by: string | null;
  requested_at: string;
  sent_at: string | null;
  responded_at: string | null;
  booked_at: string | null;
  reactivated_at: string | null;
  closed_at: string | null;
  failed_reason: string | null;
  dismissed_until: string | null;
  resulting_appointment_id: string | null;
}

/** Tentativa "aberta" = campanha em andamento para o cliente (no máximo uma, garantido por índice único). */
export const OPEN_STATUSES: AttemptStatus[] = ["requested", "sent", "responded", "booked"];
/** Contam para limite diário / máximo de tentativas / intervalo mínimo. failed, cancelled e dismissed não contam. */
export const COUNTED_STATUSES: AttemptStatus[] = ["requested", "sent", "responded", "booked", "reactivated", "expired"];
/** Só olhamos o histórico recente: limita o volume lido e evita basear o ritmo em comportamento muito antigo. */
export const HISTORY_LOOKBACK_DAYS = 730;
export const METRICS_PERIOD_DAYS = 30;
/**
 * Regra de "reativado": o agendamento atribuído foi CONCLUÍDO (o cliente de fato voltou).
 * Enquanto está só agendado, o estado é "booked" (agendou ≠ reativado).
 */
export const REACTIVATED_REQUIRES_COMPLETED = true;

const ATTEMPT_COLS =
  "id, organization_id, client_id, origin, status, reason, snapshot, requested_by, requested_at, sent_at, responded_at, booked_at, reactivated_at, closed_at, failed_reason, dismissed_until, resulting_appointment_id";
const PAGE = 1000;
const CHUNK = 100;
const DAY_MS = 86_400_000;

const nowOf = (ctx: RCtx) => (ctx.now ? ctx.now() : new Date());
const internal = (what: string, e: unknown) => {
  console.error(`[reactivation] ${what}:`, (e as { code?: string })?.code, (e as { message?: string })?.message);
  return new ApiError(500, "INTERNAL_ERROR", "Erro interno. Tente novamente.");
};

type QResult = PromiseLike<{ data: unknown; error: { code?: string; message?: string } | null }>;

/** Lê todas as páginas (o Supabase limita a 1000 linhas por consulta). A consulta DEVE ter ordem estável. */
async function fetchAll<T>(what: string, build: (from: number, to: number) => QResult): Promise<T[]> {
  const out: T[] = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await build(from, from + PAGE - 1);
    if (error) throw internal(what, error);
    const rows = (data ?? []) as T[];
    out.push(...rows);
    if (rows.length < PAGE) break;
  }
  return out;
}
const chunks = <T,>(xs: T[], n = CHUNK) => Array.from({ length: Math.ceil(xs.length / n) }, (_, i) => xs.slice(i * n, i * n + n));

// ================================================================= leitura do "mundo" da organização
async function loadTimezone(ctx: RCtx): Promise<string> {
  const { data, error } = await ctx.db.from("business_settings").select("timezone").eq("organization_id", ctx.orgId).maybeSingle();
  if (error) throw internal("timezone", error);
  return (data?.timezone as string | undefined) ?? "America/Sao_Paulo";
}

interface ClientLite { id: string; name: string; phone: string; phone_normalized: string }
interface VisitRow { client_id: string; start_at: string; service_id: string; barber_id: string }

interface World {
  clients: Map<string, ClientLite>;
  visits: Map<string, string[]>; // client_id -> start_at dos atendimentos concluídos
  attempts: Map<string, AttemptRow[]>; // client_id -> tentativas (mais recentes primeiro)
  optedOut: Set<string>;
  hasFuture: Set<string>;
}

async function loadWorld(ctx: RCtx, settings: ReactivationSettings, now: Date, clientIds?: string[]): Promise<World> {
  const { db, orgId } = ctx;
  const nowIso = now.toISOString();
  const since = new Date(now.getTime() - HISTORY_LOOKBACK_DAYS * DAY_MS).toISOString();
  const scoped = clientIds && clientIds.length ? clientIds : undefined;

  const [clientRows, visitRows, attemptRows, optRows, futureRows] = await Promise.all([
    fetchAll<ClientLite>("clients", (f, t) => {
      let q = db.from("clients").select("id, name, phone, phone_normalized").eq("organization_id", orgId).is("deleted_at", null);
      if (scoped) q = q.in("id", scoped);
      return q.order("id").range(f, t);
    }),
    fetchAll<VisitRow>("visits", (f, t) => {
      let q = db.from("appointments").select("client_id, start_at, service_id, barber_id")
        .eq("organization_id", orgId).eq("status", "completed").is("deleted_at", null)
        .gte("start_at", since).lte("start_at", nowIso);
      if (scoped) q = q.in("client_id", scoped);
      return q.order("start_at").order("id").range(f, t);
    }),
    fetchAll<AttemptRow>("attempts", (f, t) => {
      let q = db.from("reactivation_attempts").select(ATTEMPT_COLS).eq("organization_id", orgId);
      if (scoped) q = q.in("client_id", scoped);
      return q.order("requested_at", { ascending: false }).order("id").range(f, t);
    }),
    fetchAll<{ client_id: string }>("opt_outs", (f, t) => {
      let q = db.from("reactivation_opt_outs").select("client_id").eq("organization_id", orgId).is("revoked_at", null);
      if (scoped) q = q.in("client_id", scoped);
      return q.order("id").range(f, t);
    }),
    settings.blockFutureAppointment
      ? fetchAll<{ client_id: string }>("future", (f, t) => {
        let q = db.from("appointments").select("client_id").eq("organization_id", orgId)
          .in("status", ["pending", "confirmed"]).gt("start_at", nowIso).is("deleted_at", null);
        if (scoped) q = q.in("client_id", scoped);
        return q.order("id").range(f, t);
      })
      : Promise.resolve([] as { client_id: string }[]),
  ]);

  const visits = new Map<string, string[]>();
  for (const v of visitRows) (visits.get(v.client_id) ?? visits.set(v.client_id, []).get(v.client_id)!).push(v.start_at);
  const attempts = new Map<string, AttemptRow[]>();
  for (const a of attemptRows) (attempts.get(a.client_id) ?? attempts.set(a.client_id, []).get(a.client_id)!).push(a);

  return {
    clients: new Map(clientRows.map((c) => [c.id, c])),
    visits,
    attempts,
    optedOut: new Set(optRows.map((o) => o.client_id)),
    hasFuture: new Set(futureRows.map((o) => o.client_id)),
  };
}

// ================================================================= proteções (UMA função para lista, manual e automático)
export type BlockCode =
  | "OPTED_OUT" | "ALREADY_IN_PROGRESS" | "NOT_ELIGIBLE" | "DISMISSED"
  | "HAS_FUTURE_APPOINTMENT" | "MAX_ATTEMPTS_REACHED" | "TOO_SOON_SINCE_LAST_ATTEMPT";

export const BLOCK_MESSAGES: Record<BlockCode, string> = {
  OPTED_OUT: "O cliente pediu para não receber mensagens de reativação.",
  ALREADY_IN_PROGRESS: "Já existe uma reativação em andamento para este cliente.",
  NOT_ELIGIBLE: "O cliente não está atrasado em relação ao próprio ritmo de retorno (ou não há histórico suficiente).",
  DISMISSED: "Este cliente foi ignorado recentemente.",
  HAS_FUTURE_APPOINTMENT: "O cliente já tem um agendamento futuro.",
  MAX_ATTEMPTS_REACHED: "O limite de tentativas de reativação para este cliente foi atingido.",
  TOO_SOON_SINCE_LAST_ATTEMPT: "A última tentativa de reativação foi recente demais.",
};

/** Status HTTP de cada bloqueio (todos são conflito de regra de negócio). */
const BLOCK_HTTP = 409;

export function blockReason(a: {
  behavior: Behavior; attempts: AttemptRow[]; optedOut: boolean; hasFuture: boolean; settings: ReactivationSettings; now: Date;
}): BlockCode | null {
  const { behavior, attempts, settings, now } = a;
  if (a.optedOut) return "OPTED_OUT";
  if (attempts.some((t) => OPEN_STATUSES.includes(t.status))) return "ALREADY_IN_PROGRESS";
  if (!behavior.eligible) return "NOT_ELIGIBLE";

  const lastVisitMs = behavior.lastVisitAt ? Date.parse(behavior.lastVisitAt) : 0;
  // Ignorar vale até dismissed_until, desde que o cliente não tenha voltado depois de ignorado.
  if (attempts.some((t) => t.status === "dismissed" && t.dismissed_until
    && Date.parse(t.dismissed_until) > now.getTime() && Date.parse(t.requested_at) > lastVisitMs)) return "DISMISSED";
  if (settings.blockFutureAppointment && a.hasFuture) return "HAS_FUTURE_APPOINTMENT";

  const counted = attempts.filter((t) => COUNTED_STATUSES.includes(t.status));
  // Tentativas "desde a última visita": depois que o cliente volta, o contador recomeça.
  if (counted.filter((t) => Date.parse(t.requested_at) > lastVisitMs).length >= settings.maxAttempts) return "MAX_ATTEMPTS_REACHED";
  const lastTouch = counted.reduce((mx, t) => Math.max(mx, Date.parse(t.sent_at ?? t.requested_at)), 0);
  if (lastTouch && now.getTime() - lastTouch < settings.minDaysBetweenAttempts * DAY_MS) return "TOO_SOON_SINCE_LAST_ATTEMPT";
  return null;
}

export const windowOpen = (s: ReactivationSettings, tz: string, now: Date) => {
  const t = localParts(now.toISOString(), tz).time;
  return t >= s.windowStart && t < s.windowEnd;
};
const startOfLocalDay = (now: Date, tz: string) => zonedToUtc(localParts(now.toISOString(), tz).date, "00:00", tz);

export interface Capacity { limit: number; used: number; remaining: number }
const capacityOf = (limit: number, used: number): Capacity => ({ limit, used, remaining: Math.max(0, limit - used) });

// ================================================================= visão geral (candidatos + em andamento + métricas)
export interface AttemptView {
  id: string; status: AttemptStatus; origin: AttemptOrigin;
  requestedAt: string; sentAt: string | null; respondedAt: string | null; bookedAt: string | null; reactivatedAt: string | null;
}
const attemptView = (a: AttemptRow): AttemptView => ({
  id: a.id, status: a.status, origin: a.origin, requestedAt: a.requested_at, sentAt: a.sent_at,
  respondedAt: a.responded_at, bookedAt: a.booked_at, reactivatedAt: a.reactivated_at,
});

export interface CandidateItem {
  client: { id: string; name: string; phone: string; whatsappPhone: string | null };
  behavior: Behavior;
  attempt: AttemptView | null;
  state: "candidate" | "requested" | "sent" | "responded" | "booked";
}

export interface Metrics {
  eligible: number;
  requestedToday: number;
  sentToday: number;
  /** Eventos dos últimos METRICS_PERIOD_DAYS dias, contados SEPARADAMENTE (enviada ≠ respondeu ≠ agendou ≠ reativado). */
  responded: number;
  booked: number;
  reactivated: number;
  periodDays: number;
}

export interface Overview {
  settings: ReactivationSettings;
  timezone: string;
  now: string;
  windowOpen: boolean;
  capacity: Capacity;
  metrics: Metrics;
  candidates: CandidateItem[];
  inProgress: CandidateItem[];
}

const whatsappOf = (c: ClientLite) => (parseBrPhone(c.phone_normalized) ?? parseBrPhone(c.phone))?.whatsapp ?? null;

function behaviorFor(world: World, clientId: string, s: ReactivationSettings, tz: string, now: Date) {
  return computeBehavior(world.visits.get(clientId) ?? [], now, tz, { marginPercent: s.marginPercent, minVisits: s.minVisits });
}

export async function getOverview(ctx: RCtx, opts: { reconcile?: boolean } = {}): Promise<Overview> {
  if (opts.reconcile) await reconcileOutcomes(ctx);
  const now = nowOf(ctx);
  const [settings, tz] = await Promise.all([loadReactivationSettings(ctx.db, ctx.orgId), loadTimezone(ctx)]);
  const world = await loadWorld(ctx, settings, now);

  const candidates: CandidateItem[] = [];
  const inProgress: CandidateItem[] = [];
  for (const c of world.clients.values()) {
    const attempts = world.attempts.get(c.id) ?? [];
    const open = attempts.find((t) => OPEN_STATUSES.includes(t.status));
    if (!open && !world.visits.has(c.id)) continue; // sem atendimento concluído: nunca é candidato
    const behavior = behaviorFor(world, c.id, settings, tz, now);
    const client = { id: c.id, name: c.name, phone: c.phone, whatsappPhone: whatsappOf(c) };
    if (open) {
      inProgress.push({ client, behavior, attempt: attemptView(open), state: open.status as CandidateItem["state"] });
      continue;
    }
    const block = blockReason({ behavior, attempts, optedOut: world.optedOut.has(c.id), hasFuture: world.hasFuture.has(c.id), settings, now });
    if (block === null) candidates.push({ client, behavior, attempt: null, state: "candidate" });
  }
  candidates.sort((x, y) =>
    (y.behavior.overdueDays ?? 0) - (x.behavior.overdueDays ?? 0) || x.client.name.localeCompare(y.client.name, "pt-BR"));
  inProgress.sort((x, y) => Date.parse(y.attempt!.requestedAt) - Date.parse(x.attempt!.requestedAt));

  // ---- métricas (a partir das tentativas já carregadas)
  const dayStart = startOfLocalDay(now, tz).getTime();
  const sinceMs = zonedToUtc(addDays(localParts(now.toISOString(), tz).date, -(METRICS_PERIOD_DAYS - 1)), "00:00", tz).getTime();
  const all = [...world.attempts.values()].flat();
  const at = (iso: string | null) => (iso ? Date.parse(iso) : NaN);
  const metrics: Metrics = {
    eligible: candidates.length,
    requestedToday: all.filter((t) => t.status !== "dismissed" && at(t.requested_at) >= dayStart).length,
    sentToday: all.filter((t) => at(t.sent_at) >= dayStart).length,
    responded: all.filter((t) => at(t.responded_at) >= sinceMs).length,
    booked: all.filter((t) => at(t.booked_at) >= sinceMs).length,
    reactivated: all.filter((t) => at(t.reactivated_at) >= sinceMs).length,
    periodDays: METRICS_PERIOD_DAYS,
  };
  const used = all.filter((t) => COUNTED_STATUSES.includes(t.status) && at(t.requested_at) >= dayStart).length;

  return {
    settings, timezone: tz, now: now.toISOString(), windowOpen: windowOpen(settings, tz, now),
    capacity: capacityOf(settings.dailyLimit, used), metrics, candidates, inProgress,
  };
}

async function dailyUsage(ctx: RCtx, settings: ReactivationSettings, tz: string, now: Date): Promise<Capacity> {
  const dayStartIso = startOfLocalDay(now, tz).toISOString();
  const rows = await fetchAll<{ id: string; status: AttemptStatus }>("daily_usage", (f, t) =>
    ctx.db.from("reactivation_attempts").select("id, status").eq("organization_id", ctx.orgId)
      .gte("requested_at", dayStartIso).order("id").range(f, t));
  return capacityOf(settings.dailyLimit, rows.filter((r) => COUNTED_STATUSES.includes(r.status)).length);
}

// ================================================================= pedido de reativação (manual E automático)
const snapshotOf = (b: Behavior, s: ReactivationSettings) => ({
  visits: b.visits,
  completed_count: b.completedCount,
  last_visit_at: b.lastVisitAt,
  last_visit_date: b.lastVisitDate,
  days_since_last_visit: b.daysSinceLastVisit,
  habitual_interval_days: b.habitualIntervalDays,
  mean_interval_days: b.meanIntervalDays,
  median_interval_days: b.medianIntervalDays,
  overdue_days: b.overdueDays,
  due_after_days: b.dueAfterDays,
  confidence: b.confidence,
  confidence_score: b.confidenceScore,
  intervals_used: b.intervalsUsed,
  outliers_dropped: b.outliersDropped,
  margin_percent: s.marginPercent,
  min_visits: s.minVisits,
});

export interface RequestResult { attempt: AttemptRow; replay: boolean; client: ClientLite; behavior: Behavior }

/**
 * Registra o pedido de reativação (estado "requested" = mensagem pendente). NÃO envia nada.
 * Valida SEMPRE no backend: opt-out, campanha em andamento, elegibilidade atual, ignorado, agendamento futuro,
 * máximo de tentativas, intervalo mínimo, limite diário e (no automático) modo e janela de envio.
 * Repetir o pedido de uma tentativa ainda "requested" é idempotente (replay).
 */
export async function requestReactivation(
  ctx: RCtx, clientIdRaw: unknown, opts: { origin: AttemptOrigin; requestedBy?: string | null },
): Promise<RequestResult> {
  const clientId = reqUuid(clientIdRaw, "clientId");
  const now = nowOf(ctx);
  const [settings, tz] = await Promise.all([loadReactivationSettings(ctx.db, ctx.orgId), loadTimezone(ctx)]);

  if (opts.origin === "automatic" && settings.mode !== "automatic") {
    throw new ApiError(409, "AUTOMATIC_MODE_DISABLED", "A reativação automática está desativada para esta barbearia (modo manual).");
  }

  const world = await loadWorld(ctx, settings, now, [clientId]);
  const client = world.clients.get(clientId);
  if (!client) throw new ApiError(404, "CLIENT_NOT_FOUND", "Cliente não encontrado.");
  if (!parseBrPhone(client.phone_normalized) && !parseBrPhone(client.phone)) {
    throw new ApiError(422, "CLIENT_PHONE_INVALID", "O telefone deste cliente não é um número de WhatsApp válido.");
  }

  const attempts = world.attempts.get(clientId) ?? [];
  const behavior = behaviorFor(world, clientId, settings, tz, now);

  if (world.optedOut.has(clientId)) throw new ApiError(BLOCK_HTTP, "OPTED_OUT", BLOCK_MESSAGES.OPTED_OUT);
  const open = attempts.find((t) => OPEN_STATUSES.includes(t.status));
  if (open?.status === "requested") return { attempt: open, replay: true, client, behavior }; // idempotência

  const block = blockReason({ behavior, attempts, optedOut: false, hasFuture: world.hasFuture.has(clientId), settings, now });
  if (block) throw new ApiError(BLOCK_HTTP, block, BLOCK_MESSAGES[block]);

  const capacity = await dailyUsage(ctx, settings, tz, now);
  if (capacity.remaining <= 0) {
    throw new ApiError(429, "DAILY_LIMIT_REACHED", `O limite diário de ${capacity.limit} reativações já foi atingido hoje.`);
  }
  if (opts.origin === "automatic" && !windowOpen(settings, tz, now)) {
    throw new ApiError(409, "OUTSIDE_SEND_WINDOW", `Fora da janela de envio (${settings.windowStart}–${settings.windowEnd}).`);
  }

  const { data, error } = await ctx.db.from("reactivation_attempts").insert({
    organization_id: ctx.orgId, client_id: clientId, origin: opts.origin, status: "requested", reason: "behavior_due",
    snapshot: snapshotOf(behavior, settings), requested_by: opts.requestedBy ?? null, requested_at: now.toISOString(),
  }).select(ATTEMPT_COLS);
  if (error) {
    if (error.code === "23505") { // corrida: outra requisição abriu a campanha entre a checagem e o insert
      const again = (await latestOpenAttempt(ctx, clientId));
      if (again?.status === "requested") return { attempt: again, replay: true, client, behavior };
      throw new ApiError(BLOCK_HTTP, "ALREADY_IN_PROGRESS", BLOCK_MESSAGES.ALREADY_IN_PROGRESS);
    }
    throw internal("insert_attempt", error);
  }
  return { attempt: (data as AttemptRow[])[0], replay: false, client, behavior };
}

async function latestOpenAttempt(ctx: RCtx, clientId: string): Promise<AttemptRow | null> {
  const { data, error } = await ctx.db.from("reactivation_attempts").select(ATTEMPT_COLS)
    .eq("organization_id", ctx.orgId).eq("client_id", clientId).in("status", OPEN_STATUSES)
    .order("requested_at", { ascending: false }).limit(1);
  if (error) throw internal("open_attempt", error);
  return ((data ?? [])[0] as AttemptRow | undefined) ?? null;
}

async function latestAttempt(ctx: RCtx, clientId: string): Promise<AttemptRow | null> {
  const { data, error } = await ctx.db.from("reactivation_attempts").select(ATTEMPT_COLS)
    .eq("organization_id", ctx.orgId).eq("client_id", clientId)
    .order("requested_at", { ascending: false }).limit(1);
  if (error) throw internal("latest_attempt", error);
  return ((data ?? [])[0] as AttemptRow | undefined) ?? null;
}

/** Transição condicionada ao status atual (nunca sobrescreve uma tentativa que mudou no meio do caminho). */
async function transition(ctx: RCtx, id: string, from: AttemptStatus[], patch: Record<string, unknown>): Promise<AttemptRow | null> {
  const { data, error } = await ctx.db.from("reactivation_attempts").update(patch)
    .eq("organization_id", ctx.orgId).eq("id", id).in("status", from).select(ATTEMPT_COLS);
  if (error) throw internal("transition", error);
  return ((data ?? [])[0] as AttemptRow | undefined) ?? null;
}

async function clientExists(ctx: RCtx, clientId: string) {
  const { data, error } = await ctx.db.from("clients").select("id").eq("organization_id", ctx.orgId).eq("id", clientId).is("deleted_at", null).maybeSingle();
  if (error) throw internal("client_exists", error);
  if (!data) throw new ApiError(404, "CLIENT_NOT_FOUND", "Cliente não encontrado.");
}

const noActive = () => new ApiError(404, "NO_ACTIVE_REACTIVATION", "Não há reativação em andamento para este cliente.");
const badState = (msg: string) => new ApiError(409, "INVALID_STATE", msg);

// ================================================================= resultado do envio / resposta / opt-out
export interface TransitionResult { attempt: AttemptRow; replay: boolean }

/** n8n confirma que a mensagem foi enviada. requested → sent. Repetição = sucesso (replay). */
export async function markSent(ctx: RCtx, clientIdRaw: unknown): Promise<TransitionResult> {
  const clientId = reqUuid(clientIdRaw, "clientId");
  await clientExists(ctx, clientId);
  const a = await latestAttempt(ctx, clientId);
  if (!a) throw noActive();
  if (a.status === "requested") {
    const up = await transition(ctx, a.id, ["requested"], { status: "sent", sent_at: nowOf(ctx).toISOString() });
    if (up) return { attempt: up, replay: false };
    const cur = await latestAttempt(ctx, clientId); // outra chamada concorrente já avançou
    if (cur && ["sent", "responded", "booked", "reactivated"].includes(cur.status)) return { attempt: cur, replay: true };
    throw badState("A reativação mudou de estado; consulte novamente.");
  }
  if (["sent", "responded", "booked", "reactivated"].includes(a.status)) return { attempt: a, replay: true };
  throw a.status === "failed" || a.status === "cancelled" || a.status === "expired"
    ? badState(`A reativação está ${a.status === "failed" ? "marcada como falha" : a.status === "cancelled" ? "cancelada" : "expirada"} e não pode ser marcada como enviada.`)
    : noActive();
}

/** n8n informa que o envio falhou. requested → failed (não conta no limite e libera o cliente). */
export async function markFailed(ctx: RCtx, clientIdRaw: unknown, reason: string | undefined): Promise<TransitionResult> {
  const clientId = reqUuid(clientIdRaw, "clientId");
  await clientExists(ctx, clientId);
  const a = await latestAttempt(ctx, clientId);
  if (!a) throw noActive();
  if (a.status === "failed") return { attempt: a, replay: true };
  if (a.status !== "requested") throw badState("Só uma reativação ainda não enviada pode ser marcada como falha.");
  const up = await transition(ctx, a.id, ["requested"], {
    status: "failed", closed_at: nowOf(ctx).toISOString(), failed_reason: (reason ?? "send_failed").slice(0, 200),
  });
  if (!up) throw badState("A reativação mudou de estado; consulte novamente.");
  return { attempt: up, replay: false };
}

/** Cliente respondeu a mensagem. sent → responded. NÃO é agendamento nem reativação. */
export async function markResponded(ctx: RCtx, clientIdRaw: unknown): Promise<TransitionResult> {
  const clientId = reqUuid(clientIdRaw, "clientId");
  await clientExists(ctx, clientId);
  const a = await latestAttempt(ctx, clientId);
  if (!a) throw noActive();
  if (["responded", "booked", "reactivated"].includes(a.status)) return { attempt: a, replay: true };
  if (a.status === "requested") throw badState("A mensagem ainda não foi enviada a este cliente.");
  if (a.status !== "sent") throw noActive();
  const up = await transition(ctx, a.id, ["sent"], { status: "responded", responded_at: nowOf(ctx).toISOString() });
  if (up) return { attempt: up, replay: false };
  const cur = await latestAttempt(ctx, clientId);
  if (cur && ["responded", "booked", "reactivated"].includes(cur.status)) return { attempt: cur, replay: true };
  throw badState("A reativação mudou de estado; consulte novamente.");
}

/**
 * Cliente pediu para não receber mais. Bloqueia TODA reativação futura (manual e automática)
 * e cancela um pedido ainda pendente. Idempotente.
 */
export async function recordOptOut(
  ctx: RCtx, clientIdRaw: unknown, opts: { source?: "whatsapp" | "manual" | "api"; note?: string } = {},
): Promise<{ optedOut: true; replay: boolean; cancelledPending: number }> {
  const clientId = reqUuid(clientIdRaw, "clientId");
  await clientExists(ctx, clientId);
  const existing = await ctx.db.from("reactivation_opt_outs").select("id").eq("organization_id", ctx.orgId)
    .eq("client_id", clientId).is("revoked_at", null).limit(1);
  if (existing.error) throw internal("opt_out_lookup", existing.error);
  let replay = (existing.data ?? []).length > 0;
  if (!replay) {
    const { error } = await ctx.db.from("reactivation_opt_outs").insert({
      organization_id: ctx.orgId, client_id: clientId, source: opts.source ?? "whatsapp",
      note: opts.note?.slice(0, 300) ?? null, opted_out_at: nowOf(ctx).toISOString(),
    });
    if (error) {
      if (error.code === "23505") replay = true;
      else throw internal("opt_out_insert", error);
    }
  }
  const { data, error } = await ctx.db.from("reactivation_attempts").update({
    status: "cancelled", closed_at: nowOf(ctx).toISOString(), failed_reason: "opt_out",
  }).eq("organization_id", ctx.orgId).eq("client_id", clientId).in("status", ["requested"]).select("id");
  if (error) throw internal("opt_out_cancel", error);
  return { optedOut: true, replay, cancelledPending: (data ?? []).length };
}

/** Dono desiste de um pedido ainda pendente (requested → cancelled). */
export async function cancelRequest(ctx: RCtx, attemptIdRaw: unknown): Promise<AttemptRow> {
  const id = reqUuid(attemptIdRaw, "attemptId");
  const up = await transition(ctx, id, ["requested"], { status: "cancelled", closed_at: nowOf(ctx).toISOString(), failed_reason: "cancelled_by_owner" });
  if (up) return up;
  const { data, error } = await ctx.db.from("reactivation_attempts").select("id, status").eq("organization_id", ctx.orgId).eq("id", id).maybeSingle();
  if (error) throw internal("cancel_lookup", error);
  if (!data) throw new ApiError(404, "NOT_FOUND", "Reativação não encontrada.");
  throw badState("Esta reativação já foi enviada ou encerrada e não pode ser cancelada.");
}

/** Dono ignora um candidato por `minDaysBetweenAttempts` dias. Só vale para quem é candidato AGORA. */
export async function dismissCandidate(ctx: RCtx, clientIdRaw: unknown, opts: { requestedBy?: string | null } = {}): Promise<AttemptRow> {
  const clientId = reqUuid(clientIdRaw, "clientId");
  const now = nowOf(ctx);
  const [settings, tz] = await Promise.all([loadReactivationSettings(ctx.db, ctx.orgId), loadTimezone(ctx)]);
  const world = await loadWorld(ctx, settings, now, [clientId]);
  const client = world.clients.get(clientId);
  if (!client) throw new ApiError(404, "CLIENT_NOT_FOUND", "Cliente não encontrado.");
  const behavior = behaviorFor(world, clientId, settings, tz, now);
  const block = blockReason({
    behavior, attempts: world.attempts.get(clientId) ?? [], optedOut: world.optedOut.has(clientId),
    hasFuture: world.hasFuture.has(clientId), settings, now,
  });
  if (block) throw new ApiError(BLOCK_HTTP, block, BLOCK_MESSAGES[block]);
  const { data, error } = await ctx.db.from("reactivation_attempts").insert({
    organization_id: ctx.orgId, client_id: clientId, origin: "manual", status: "dismissed", reason: "behavior_due",
    snapshot: snapshotOf(behavior, settings), requested_by: opts.requestedBy ?? null, requested_at: now.toISOString(),
    closed_at: now.toISOString(), dismissed_until: new Date(now.getTime() + settings.minDaysBetweenAttempts * DAY_MS).toISOString(),
  }).select(ATTEMPT_COLS);
  if (error) throw internal("dismiss", error);
  return (data as AttemptRow[])[0];
}

// ================================================================= resultado: agendou / reativado / expirou
interface ApptLite { id: string; client_id: string; status: string; created_at: string; start_at: string }

/**
 * Reconcilia as tentativas abertas com a AGENDA (appointments = fonte de verdade). Idempotente; pode rodar a qualquer hora.
 *  - agendamento válido (pendente/confirmado/concluído) CRIADO depois do envio e até `attribution_days` depois → booked;
 *  - esse agendamento CONCLUÍDO → reactivated (o cliente de fato voltou);
 *  - agendamento cancelado/no-show/removido → a tentativa volta a sent/responded;
 *  - sem agendamento dentro do prazo → expired (libera o cliente; as proteções de intervalo continuam valendo).
 * Mensagem enviada sem novo agendamento NUNCA vira reativado.
 */
export async function reconcileOutcomes(ctx: RCtx): Promise<{ booked: number; reactivated: number; reverted: number; expired: number }> {
  const now = nowOf(ctx);
  const settings = await loadReactivationSettings(ctx.db, ctx.orgId);
  const out = { booked: 0, reactivated: 0, reverted: 0, expired: 0 };

  const open = await fetchAll<AttemptRow>("reconcile_attempts", (f, t) =>
    ctx.db.from("reactivation_attempts").select(ATTEMPT_COLS).eq("organization_id", ctx.orgId)
      .in("status", OPEN_STATUSES).order("id").range(f, t));
  if (!open.length) return out;

  const sentOnes = open.filter((a) => a.status !== "requested" && a.sent_at);
  const apptsByClient = new Map<string, ApptLite[]>();
  if (sentOnes.length) {
    const minSent = new Date(Math.min(...sentOnes.map((a) => Date.parse(a.sent_at!)))).toISOString();
    for (const ids of chunks([...new Set(sentOnes.map((a) => a.client_id))])) {
      const rows = await fetchAll<ApptLite>("reconcile_appts", (f, t) =>
        ctx.db.from("appointments").select("id, client_id, status, created_at, start_at").eq("organization_id", ctx.orgId)
          .in("client_id", ids).in("status", ["pending", "confirmed", "completed"]).is("deleted_at", null)
          .gte("created_at", minSent).order("created_at").order("id").range(f, t));
      for (const r of rows) (apptsByClient.get(r.client_id) ?? apptsByClient.set(r.client_id, []).get(r.client_id)!).push(r);
    }
  }

  const windowMs = settings.attributionDays * DAY_MS;
  for (const a of open) {
    if (a.status === "requested") {
      // pedido que nunca foi enviado dentro do prazo: encerra (não ficou nada pendente para sempre)
      if (now.getTime() - Date.parse(a.requested_at) > windowMs) {
        if (await transition(ctx, a.id, ["requested"], { status: "expired", closed_at: now.toISOString() })) out.expired++;
      }
      continue;
    }
    if (!a.sent_at) continue;
    const sentMs = Date.parse(a.sent_at);
    const mine = (apptsByClient.get(a.client_id) ?? []).filter((p) => {
      const c = Date.parse(p.created_at);
      return c >= sentMs && c <= sentMs + windowMs;
    });
    const done = mine.find((p) => p.status === "completed");
    const pick = REACTIVATED_REQUIRES_COMPLETED ? (done ?? mine[0]) : mine[0];

    if (done && REACTIVATED_REQUIRES_COMPLETED) {
      if (a.status !== "reactivated" && await transition(ctx, a.id, OPEN_STATUSES, {
        status: "reactivated", booked_at: a.booked_at ?? done.created_at, reactivated_at: now.toISOString(),
        closed_at: now.toISOString(), resulting_appointment_id: done.id,
      })) out.reactivated++;
    } else if (pick) {
      if (a.status !== "booked" || a.resulting_appointment_id !== pick.id) {
        if (await transition(ctx, a.id, OPEN_STATUSES, { status: "booked", booked_at: a.booked_at ?? pick.created_at, resulting_appointment_id: pick.id })) out.booked++;
      }
    } else if (a.status === "booked") {
      // o agendamento atribuído deixou de ser válido (cancelado / no-show / removido)
      if (await transition(ctx, a.id, ["booked"], {
        status: a.responded_at ? "responded" : "sent", booked_at: null, resulting_appointment_id: null,
      })) out.reverted++;
    } else if (now.getTime() - sentMs > windowMs) {
      if (await transition(ctx, a.id, ["sent", "responded"], { status: "expired", closed_at: now.toISOString() })) out.expired++;
    }
  }
  return out;
}

// ================================================================= evento para o n8n
export const MESSAGE_GUIDANCE = {
  language: "pt-BR",
  goal: "Convidar o cliente, de forma natural e curta, a marcar o próximo horário porque está chegando ou passou do período em que costuma voltar.",
  tone: [
    "amigável e informal, como o barbeiro de confiança dele",
    "no máximo 2 ou 3 frases e no máximo 1 emoji",
    "chamar o cliente pelo primeiro nome",
    "não parecer mensagem automática nem propaganda",
  ],
  must_not: [
    "inventar preço, serviço, horário ou disponibilidade",
    "prometer desconto, brinde ou promoção",
    "dizer que um sistema ou IA calculou o retorno dele",
    "cobrar, culpar ou insistir se o cliente não quiser",
    "enviar mais de uma mensagem de reativação",
  ],
  must_do: [
    "consultar o BarberFlow (ferramentas get_services, get_available_slots...) antes de citar qualquer serviço, preço ou horário",
    "se o cliente quiser agendar, seguir o fluxo normal de agendamento do atendimento WhatsApp",
    "se o cliente pedir para não receber mais mensagens, registrar o opt-out e agradecer com educação",
  ],
  example: "Fala, João! Tudo certo? ✂️ Já está chegando perto do período em que você costuma fazer seu próximo corte. Quer que eu veja alguns horários pra você?",
} as const;

const firstName = (n: string) => n.trim().split(/\s+/)[0] ?? n;
const snapNum = (s: Record<string, unknown>, k: string) => (typeof s[k] === "number" ? (s[k] as number) : null);

/** Monta o evento que o n8n recebe. Os números vêm do SNAPSHOT gravado no pedido: o n8n não recalcula nada. */
export async function buildEvents(ctx: RCtx, attempts: AttemptRow[]) {
  if (!attempts.length) return [];
  const clientIds = [...new Set(attempts.map((a) => a.client_id))];
  const lastAts = [...new Set(attempts.map((a) => a.snapshot?.last_visit_at).filter((x): x is string => typeof x === "string"))];

  const [org, tz, clients, visits] = await Promise.all([
    ctx.db.from("organizations").select("name").eq("id", ctx.orgId).maybeSingle(),
    loadTimezone(ctx),
    ctx.db.from("clients").select("id, name, phone, phone_normalized").eq("organization_id", ctx.orgId).in("id", clientIds),
    lastAts.length
      ? ctx.db.from("appointments").select("client_id, start_at, service_id, barber_id").eq("organization_id", ctx.orgId)
        .eq("status", "completed").is("deleted_at", null).in("client_id", clientIds).in("start_at", lastAts)
      : Promise.resolve({ data: [] as VisitRow[], error: null }),
  ]);
  if (org.error || clients.error || visits.error) throw internal("events", org.error ?? clients.error ?? visits.error);

  const visitRows = (visits.data ?? []) as VisitRow[];
  const [sv, br] = await Promise.all([
    visitRows.length ? ctx.db.from("services").select("id, name").eq("organization_id", ctx.orgId).in("id", [...new Set(visitRows.map((v) => v.service_id))]) : Promise.resolve({ data: [], error: null }),
    visitRows.length ? ctx.db.from("barbers").select("id, name").eq("organization_id", ctx.orgId).in("id", [...new Set(visitRows.map((v) => v.barber_id))]) : Promise.resolve({ data: [], error: null }),
  ]);
  if (sv.error || br.error) throw internal("events_names", sv.error ?? br.error);
  const nameBy = (rows: unknown) => new Map(((rows ?? []) as { id: string; name: string }[]).map((r) => [r.id, r.name]));
  const svc = nameBy(sv.data), brb = nameBy(br.data);
  const cli = new Map(((clients.data ?? []) as ClientLite[]).map((c) => [c.id, c]));

  return attempts.flatMap((a) => {
    const c = cli.get(a.client_id);
    if (!c) return [];
    const snap = a.snapshot ?? {};
    const v = visitRows.find((r) => r.client_id === a.client_id && r.start_at === snap.last_visit_at);
    return [{
      event: "reactivation.requested" as const,
      attempt: { id: a.id, origin: a.origin, status: a.status, requested_at: a.requested_at },
      client: { id: c.id, name: c.name, first_name: firstName(c.name), phone: c.phone, whatsapp_phone: whatsappOf(c) },
      reactivation: {
        reason: a.reason,
        days_since_last_visit: snapNum(snap, "days_since_last_visit"),
        habitual_interval_days: snapNum(snap, "habitual_interval_days"),
        overdue_days: snapNum(snap, "overdue_days"),
        visits: snapNum(snap, "visits"),
        confidence: (snap.confidence as string | undefined) ?? null,
        last_visit_date: (snap.last_visit_date as string | undefined) ?? null,
        calculated_at: a.requested_at,
      },
      last_visit: v ? { date: localParts(v.start_at, tz).date, service_name: svc.get(v.service_id) ?? null, barber_name: brb.get(v.barber_id) ?? null } : null,
      business: { name: ((org.data as { name?: string } | null)?.name) ?? null, timezone: tz },
      message_context: MESSAGE_GUIDANCE,
    }];
  });
}

/** Pedidos aguardando envio. Só devolve itens dentro da janela de envio (fora dela o n8n espera). */
export async function listPending(ctx: RCtx, limit = 20) {
  await reconcileOutcomes(ctx);
  const now = nowOf(ctx);
  const [settings, tz] = await Promise.all([loadReactivationSettings(ctx.db, ctx.orgId), loadTimezone(ctx)]);
  const open = windowOpen(settings, tz, now);
  const base = { window_open: open, window: { start: settings.windowStart, end: settings.windowEnd, timezone: tz } };
  if (!open) return { ...base, count: 0, items: [] };
  const { data, error } = await ctx.db.from("reactivation_attempts").select(ATTEMPT_COLS)
    .eq("organization_id", ctx.orgId).eq("status", "requested").order("requested_at").limit(limit);
  if (error) throw internal("pending", error);
  const items = await buildEvents(ctx, (data ?? []) as AttemptRow[]);
  return { ...base, count: items.length, items };
}

/** Configuração efetiva + situação de hoje (janela aberta? quanto resta do limite diário?). */
export async function getRuntimeSettings(ctx: RCtx) {
  const now = nowOf(ctx);
  const [settings, tz] = await Promise.all([loadReactivationSettings(ctx.db, ctx.orgId), loadTimezone(ctx)]);
  const capacity = await dailyUsage(ctx, settings, tz, now);
  return { settings, timezone: tz, now, windowOpen: windowOpen(settings, tz, now), capacity };
}
