import type { SupabaseClient } from "@supabase/supabase-js";
import type { Checked } from "@/lib/settings";

/** Configuração de reativação da ORGANIZAÇÃO (tabela reactivation_settings, 1 linha por organização). */
export type ReactivationMode = "manual" | "automatic";

export interface ReactivationSettings {
  mode: ReactivationMode;
  /** 15 = 15% sobre o intervalo habitual do próprio cliente. */
  marginPercent: number;
  /** Mínimo de visitas (dias distintos) para o comportamento ser considerado confiável. */
  minVisits: number;
  /** HH:MM no fuso da organização. Independente de business_settings.opening_hours. */
  windowStart: string;
  windowEnd: string;
  dailyLimit: number;
  minDaysBetweenAttempts: number;
  maxAttempts: number;
  blockFutureAppointment: boolean;
  /** Dias após o envio em que um novo agendamento ainda é atribuído à reativação. */
  attributionDays: number;
}

/** Padrões aprovados na Etapa 11. Usados quando a organização ainda não tem linha na tabela. */
export const DEFAULT_REACTIVATION_SETTINGS: ReactivationSettings = {
  mode: "manual",
  marginPercent: 15,
  minVisits: 3,
  windowStart: "09:00",
  windowEnd: "19:00",
  dailyLimit: 20,
  minDaysBetweenAttempts: 30,
  maxAttempts: 3,
  blockFutureAppointment: true,
  attributionDays: 14,
};

const COLUMNS =
  "mode, margin_percent, min_visits, send_window_start, send_window_end, daily_limit, min_days_between_attempts, max_attempts, block_if_future_appointment, attribution_days";

export function rowToSettings(r: Record<string, unknown> | null | undefined): ReactivationSettings {
  if (!r) return { ...DEFAULT_REACTIVATION_SETTINGS };
  const d = DEFAULT_REACTIVATION_SETTINGS;
  const num = (v: unknown, fb: number) => (typeof v === "number" && Number.isFinite(v) ? v : fb);
  return {
    mode: r.mode === "automatic" ? "automatic" : "manual",
    marginPercent: num(r.margin_percent, d.marginPercent),
    minVisits: num(r.min_visits, d.minVisits),
    windowStart: typeof r.send_window_start === "string" ? r.send_window_start.slice(0, 5) : d.windowStart,
    windowEnd: typeof r.send_window_end === "string" ? r.send_window_end.slice(0, 5) : d.windowEnd,
    dailyLimit: num(r.daily_limit, d.dailyLimit),
    minDaysBetweenAttempts: num(r.min_days_between_attempts, d.minDaysBetweenAttempts),
    maxAttempts: num(r.max_attempts, d.maxAttempts),
    blockFutureAppointment: typeof r.block_if_future_appointment === "boolean" ? r.block_if_future_appointment : d.blockFutureAppointment,
    attributionDays: num(r.attribution_days, d.attributionDays),
  };
}

/** Sem linha = padrões. Erro de banco = exceção (nunca se inventa configuração em caso de falha). */
export async function loadReactivationSettings(db: SupabaseClient, orgId: string): Promise<ReactivationSettings> {
  const { data, error } = await db.from("reactivation_settings").select(COLUMNS).eq("organization_id", orgId).maybeSingle();
  if (error) throw new Error(`reactivation_settings: ${error.code ?? ""} ${error.message}`);
  return rowToSettings(data as Record<string, unknown> | null);
}

export async function saveReactivationSettings(db: SupabaseClient, orgId: string, s: ReactivationSettings): Promise<void> {
  const { error } = await db.from("reactivation_settings").upsert({
    organization_id: orgId,
    mode: s.mode,
    margin_percent: s.marginPercent,
    min_visits: s.minVisits,
    send_window_start: s.windowStart,
    send_window_end: s.windowEnd,
    daily_limit: s.dailyLimit,
    min_days_between_attempts: s.minDaysBetweenAttempts,
    max_attempts: s.maxAttempts,
    block_if_future_appointment: s.blockFutureAppointment,
    attribution_days: s.attributionDays,
  }, { onConflict: "organization_id" });
  if (error) throw new Error(`reactivation_settings: ${error.code ?? ""} ${error.message}`);
}

// ---------------------------------------------------------------- validação (servidor)
const isRecord = (x: unknown): x is Record<string, unknown> => typeof x === "object" && x !== null && !Array.isArray(x);
const fail = (error: string): { ok: false; error: string } => ({ ok: false, error });
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

function whole(x: unknown, min: number, max: number): number | null {
  const n = typeof x === "number" ? x : typeof x === "string" && x.trim() !== "" ? Number(x) : NaN;
  return Number.isInteger(n) && n >= min && n <= max ? n : null;
}

export function validateReactivationSettings(input: unknown): Checked<ReactivationSettings> {
  if (!isRecord(input)) return fail("Dados inválidos.");
  if (input.mode !== "manual" && input.mode !== "automatic") return fail("Escolha o modo de reativação.");
  const marginPercent = whole(input.marginPercent, 0, 100);
  if (marginPercent === null) return fail("A margem de atraso deve ficar entre 0% e 100%.");
  const minVisits = whole(input.minVisits, 2, 50);
  if (minVisits === null) return fail("O mínimo de atendimentos deve ficar entre 2 e 50. Um único atendimento não basta para entender o comportamento.");
  const windowStart = typeof input.windowStart === "string" && TIME_RE.test(input.windowStart) ? input.windowStart : null;
  const windowEnd = typeof input.windowEnd === "string" && TIME_RE.test(input.windowEnd) ? input.windowEnd : null;
  if (!windowStart || !windowEnd) return fail("Informe horários válidos para o envio de mensagens.");
  if (windowEnd <= windowStart) return fail("O fim da janela de envio deve ser depois do início.");
  const dailyLimit = whole(input.dailyLimit, 1, 500);
  if (dailyLimit === null) return fail("O limite diário deve ficar entre 1 e 500 mensagens.");
  const minDaysBetweenAttempts = whole(input.minDaysBetweenAttempts, 1, 365);
  if (minDaysBetweenAttempts === null) return fail("O intervalo mínimo entre tentativas deve ficar entre 1 e 365 dias.");
  const maxAttempts = whole(input.maxAttempts, 1, 20);
  if (maxAttempts === null) return fail("O máximo de tentativas deve ficar entre 1 e 20.");
  const attributionDays = whole(input.attributionDays, 1, 90);
  if (attributionDays === null) return fail("O prazo para considerar o agendamento deve ficar entre 1 e 90 dias.");
  if (typeof input.blockFutureAppointment !== "boolean") return fail("Dados inválidos.");
  return {
    ok: true,
    value: {
      mode: input.mode, marginPercent, minVisits, windowStart, windowEnd, dailyLimit,
      minDaysBetweenAttempts, maxAttempts, blockFutureAppointment: input.blockFutureAppointment, attributionDays,
    },
  };
}
