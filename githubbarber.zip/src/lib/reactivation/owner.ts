import { AdminConfigError, createAdminClient } from "@/lib/supabase/admin";
import type { RCtx } from "./service";

/**
 * Contexto de reativação para telas do DONO. Chamar SOMENTE depois de `requireOwner()`/papel owner validado:
 * usa service role, e a organização vem da SESSÃO (ctx.org.id), nunca de parâmetro do cliente.
 * Lança AdminConfigError se SUPABASE_SERVICE_ROLE_KEY não estiver configurada (a tela mostra estado de erro).
 */
export function ownerReactivationCtx(orgId: string): RCtx {
  return { db: createAdminClient(), orgId };
}
export { AdminConfigError };
