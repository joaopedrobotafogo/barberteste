import type { SupabaseClient } from "@supabase/supabase-js";
import {
  ACTIVE_STATUSES, addDays, computeSlots, isValidYmd, weekdayKey, zonedToUtc,
  type OpeningHours,
} from "@/lib/agenda";
import { UUID_RE } from "@/lib/clients";

/**
 * NÚCLEO COMPARTILHADO DA AGENDA (Etapa 9).
 *
 * É a ÚNICA implementação de "quais horários estão livres" e de "como traduzir erros do banco".
 * Usado por:
 *   - a tela de Agenda (server actions, cliente Supabase com sessão + RLS);
 *   - a API de integração do n8n (cliente service role, sem RLS).
 *
 * Por isso TODAS as consultas aqui filtram explicitamente por organization_id:
 * com RLS o filtro é redundante; sem RLS (API) ele é a barreira de multi-tenancy.
 * Este arquivo não importa nada de sessão/cookies (getContext) de propósito.
 */

export type Db = SupabaseClient;
export type DbError = { code?: string; message: string };

export interface AgendaSettings {
  timezone: string;
  openingHours: OpeningHours;
  interval: number;
  minNotice: number;
  allowOverbooking: boolean;
}

export async function loadAgendaSettings(db: Db, orgId: string): Promise<AgendaSettings> {
  const { data } = await db
    .from("business_settings")
    .select("timezone, opening_hours, slot_interval_minutes, min_notice_minutes, allow_overbooking")
    .eq("organization_id", orgId)
    .maybeSingle();
  return {
    timezone: (data?.timezone as string | undefined) ?? "America/Sao_Paulo",
    openingHours: (data?.opening_hours as OpeningHours | undefined) ?? {},
    interval: (data?.slot_interval_minutes as number | undefined) ?? 15,
    minNotice: (data?.min_notice_minutes as number | undefined) ?? 0,
    allowOverbooking: (data?.allow_overbooking as boolean | undefined) ?? false,
  };
}

/** Traduz erros do banco (constraint de conflito, triggers) em mensagens claras. */
export function dbErrorMessage(error: DbError, context: string): string {
  if (error.code === "23P01") return context === "block"
    ? "Já existe um bloqueio neste período para este barbeiro."
    : "Este horário já está ocupado para o barbeiro escolhido.";
  if (error.code === "P0001") return error.message; // mensagens escritas nos triggers do schema
  if (error.code === "23503") return "Cliente, serviço ou barbeiro inválido.";
  console.error(`[agenda:${context}]`, error);
  return "Não foi possível salvar. Tente novamente.";
}

/** Intervalos ocupados do barbeiro no dia (agendamentos ativos, sem encaixe, + bloqueios). */
export async function loadBusyRanges(
  db: Db, orgId: string,
  o: { barberId: string; date: string; timezone: string; excludeId?: string },
): Promise<{ busy: { start: number; end: number }[]; error: boolean }> {
  const dayStart = zonedToUtc(o.date, "00:00", o.timezone).toISOString();
  const dayEnd = zonedToUtc(addDays(o.date, 1), "00:00", o.timezone).toISOString();

  let aq = db.from("appointments").select("start_at, end_at")
    .eq("organization_id", orgId).eq("barber_id", o.barberId)
    .in("status", [...ACTIVE_STATUSES]).eq("is_overbook", false).is("deleted_at", null)
    .lt("start_at", dayEnd).gt("end_at", dayStart);
  if (o.excludeId && UUID_RE.test(o.excludeId)) aq = aq.neq("id", o.excludeId);
  const bq = db.from("time_blocks").select("start_at, end_at")
    .eq("organization_id", orgId).eq("barber_id", o.barberId).is("deleted_at", null)
    .lt("start_at", dayEnd).gt("end_at", dayStart);

  const [a, b] = await Promise.all([aq, bq]);
  if (a.error || b.error) {
    console.error("[agenda:getSlots]", a.error ?? b.error);
    return { busy: [], error: true };
  }
  const busy = [...(a.data ?? []), ...(b.data ?? [])].map((r: { start_at: string; end_at: string }) => ({
    start: Date.parse(r.start_at), end: Date.parse(r.end_at),
  }));
  return { busy, error: false };
}

export interface SlotsResult { slots: string[]; closed: boolean; error?: string }

/**
 * Horários livres de UM barbeiro num dia, dado o serviço (duração) já conhecido e as configurações já carregadas.
 * Considera expediente, dia fechado, intervalo, antecedência mínima, agendamentos e bloqueios.
 */
export async function computeBarberSlots(
  db: Db, orgId: string,
  o: { settings: AgendaSettings; durationMin: number; barberId: string; date: string; excludeId?: string; now?: number },
): Promise<SlotsResult> {
  const hours = o.settings.openingHours[weekdayKey(o.date)] ?? null;
  if (!hours) return { slots: [], closed: true };
  const { busy, error } = await loadBusyRanges(db, orgId, {
    barberId: o.barberId, date: o.date, timezone: o.settings.timezone, excludeId: o.excludeId,
  });
  if (error) return { slots: [], closed: false, error: "Não foi possível carregar os horários." };
  return {
    slots: computeSlots({
      date: o.date, tz: o.settings.timezone, hours, durationMin: o.durationMin,
      intervalMin: o.settings.interval, minNoticeMin: o.settings.minNotice, busy, now: o.now,
    }),
    closed: false,
  };
}

/**
 * Horários livres de um barbeiro num dia para um serviço. Base do getSlots() da tela de Agenda
 * e do endpoint de disponibilidade da API.
 */
export async function getAvailableSlots(
  db: Db, orgId: string,
  input: { barberId: string; serviceId: string; date: string; excludeId?: string },
): Promise<SlotsResult> {
  const { barberId, serviceId, date, excludeId } = input;
  if (!UUID_RE.test(barberId) || !UUID_RE.test(serviceId) || !isValidYmd(date)) {
    return { slots: [], closed: false, error: "Dados inválidos." };
  }
  const settings = await loadAgendaSettings(db, orgId);
  const { data: svc } = await db.from("services").select("duration_minutes")
    .eq("organization_id", orgId).eq("id", serviceId).maybeSingle();
  if (!svc) return { slots: [], closed: false, error: "Serviço não encontrado." };
  return computeBarberSlots(db, orgId, {
    settings, durationMin: svc.duration_minutes as number, barberId, date, excludeId,
  });
}

