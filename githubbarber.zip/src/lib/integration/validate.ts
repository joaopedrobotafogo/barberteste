import { isValidYmd, todayIn, addDays } from "@/lib/agenda";
import { UUID_RE } from "@/lib/clients";
import { ApiError } from "./http";

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
/** Teto de antecedência da consulta/criação: evita varreduras e datas absurdas. */
export const MAX_DAYS_AHEAD = 365;

const bad = (message: string) => new ApiError(400, "INVALID_INPUT", message);

export function reqUuid(v: unknown, field: string): string {
  if (typeof v !== "string" || !UUID_RE.test(v)) throw bad(`'${field}' deve ser um UUID válido.`);
  return v.toLowerCase();
}
export function optUuid(v: unknown, field: string): string | undefined {
  return v === undefined || v === null || v === "" ? undefined : reqUuid(v, field);
}

export function reqDate(v: unknown, field = "date"): string {
  if (typeof v !== "string" || !isValidYmd(v)) throw bad(`'${field}' deve estar no formato YYYY-MM-DD.`);
  return v;
}
/** Data válida e dentro da janela [hoje-1, hoje+365] no fuso da barbearia. */
export function assertDateWindow(date: string, tz: string) {
  const today = todayIn(tz);
  if (date < addDays(today, -1)) return; // passado: não gera horários (computeSlots barra); sem erro
  if (date > addDays(today, MAX_DAYS_AHEAD)) throw bad(`'date' não pode ser mais de ${MAX_DAYS_AHEAD} dias à frente.`);
}

export function reqTime(v: unknown, field = "time"): string {
  if (typeof v !== "string" || !TIME_RE.test(v)) throw bad(`'${field}' deve estar no formato HH:MM (24h).`);
  return v;
}

export function reqText(v: unknown, field: string, max: number): string {
  if (typeof v !== "string" || !v.trim()) throw bad(`'${field}' é obrigatório.`);
  const t = v.trim();
  if (t.length > max) throw bad(`'${field}' pode ter no máximo ${max} caracteres.`);
  return t;
}
export function optText(v: unknown, field: string, max: number): string | undefined {
  if (v === undefined || v === null || v === "") return undefined;
  if (typeof v !== "string") throw bad(`'${field}' deve ser texto.`);
  const t = v.trim();
  if (t.length > max) throw bad(`'${field}' pode ter no máximo ${max} caracteres.`);
  return t || undefined;
}

export const SOURCES = ["whatsapp", "ai"] as const;
export type IntegrationSource = (typeof SOURCES)[number];
export function optSource(v: unknown): IntegrationSource {
  if (v === undefined || v === null || v === "") return "whatsapp";
  if (typeof v === "string" && (SOURCES as readonly string[]).includes(v)) return v as IntegrationSource;
  throw bad(`'source' deve ser um de: ${SOURCES.join(", ")}.`);
}
