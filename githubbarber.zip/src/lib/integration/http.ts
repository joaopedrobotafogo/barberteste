import { NextResponse } from "next/server";

/** Códigos de erro estáveis da API (o n8n deve decidir pelo campo `error`, não pela mensagem). */
export type ErrorCode =
  | "INVALID_INPUT" | "INVALID_BODY"
  | "UNAUTHORIZED" | "FORBIDDEN"
  | "NOT_FOUND" | "CLIENT_NOT_FOUND" | "SERVICE_NOT_FOUND" | "BARBER_NOT_FOUND" | "APPOINTMENT_NOT_FOUND"
  | "TIME_UNAVAILABLE" | "BUSINESS_CLOSED" | "OUTSIDE_BUSINESS_HOURS" | "TOO_SOON"
  | "INVALID_STATUS" | "APPOINTMENT_IN_PAST"
  // Etapa 11 (reativação)
  | "NOT_ELIGIBLE" | "OPTED_OUT" | "ALREADY_IN_PROGRESS" | "HAS_FUTURE_APPOINTMENT" | "MAX_ATTEMPTS_REACHED"
  | "TOO_SOON_SINCE_LAST_ATTEMPT" | "DAILY_LIMIT_REACHED" | "OUTSIDE_SEND_WINDOW" | "DISMISSED"
  | "AUTOMATIC_MODE_DISABLED" | "NO_ACTIVE_REACTIVATION" | "INVALID_STATE" | "CLIENT_PHONE_INVALID"
  | "INTERNAL_ERROR" | "SERVER_MISCONFIGURED";

export class ApiError extends Error {
  constructor(public status: number, public code: ErrorCode, message: string) {
    super(message);
  }
}

const NO_STORE = { "Cache-Control": "no-store" };

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status, headers: NO_STORE });
}

export function failure(status: number, code: ErrorCode, message: string) {
  return NextResponse.json({ success: false, error: code, message }, { status, headers: NO_STORE });
}

/** Lê o body JSON (objeto). Qualquer outra coisa vira 400. */
export async function readJson(req: Request): Promise<Record<string, unknown>> {
  let body: unknown;
  try { body = await req.json(); } catch { throw new ApiError(400, "INVALID_BODY", "O corpo da requisição deve ser um JSON válido."); }
  if (typeof body !== "object" || body === null || Array.isArray(body)) {
    throw new ApiError(400, "INVALID_BODY", "O corpo da requisição deve ser um objeto JSON.");
  }
  return body as Record<string, unknown>;
}
