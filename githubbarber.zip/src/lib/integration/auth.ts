import { createHash } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import { AdminConfigError, createAdminClient } from "@/lib/supabase/admin";
import { ApiError } from "./http";

/** Contexto de uma chamada autenticada. orgId vem SEMPRE do token, nunca do cliente. */
export interface IntegrationCtx {
  /** Service role (ignora RLS): toda query DEVE filtrar por orgId. */
  db: SupabaseClient;
  orgId: string;
  tokenId: string;
}

const TOKEN_RE = /^bf_live_[0-9a-f]{64}$/;
const TOUCH_EVERY_MS = 5 * 60_000;

export const hashToken = (token: string) => createHash("sha256").update(token).digest("hex");

/** Extrai o token do header "Authorization: Bearer ..." (nunca de URL/query). */
export function bearerToken(header: string | null): string | null {
  if (!header) return null;
  const m = /^Bearer\s+(\S+)$/i.exec(header.trim());
  return m && TOKEN_RE.test(m[1]) ? m[1] : null;
}

const UNAUTH = () => new ApiError(401, "UNAUTHORIZED", "Token de integração ausente, inválido ou revogado.");

export async function authenticate(req: Request): Promise<IntegrationCtx> {
  const token = bearerToken(req.headers.get("authorization"));
  if (!token) throw UNAUTH();

  let db: SupabaseClient;
  try {
    db = createAdminClient();
  } catch (e) {
    if (e instanceof AdminConfigError) console.error("[integration] configuração do servidor:", e.message);
    throw new ApiError(500, "SERVER_MISCONFIGURED", "A API de integração não está configurada no servidor.");
  }

  const { data, error } = await db
    .from("integration_tokens")
    .select("id, organization_id, revoked_at, last_used_at")
    .eq("token_hash", hashToken(token))
    .maybeSingle();
  if (error) {
    console.error("[integration] erro ao validar token:", error.code, error.message);
    throw new ApiError(500, "INTERNAL_ERROR", "Erro interno ao validar o token.");
  }
  if (!data || data.revoked_at) throw UNAUTH();

  const orgId = data.organization_id as string;
  const { data: org } = await db.from("organizations").select("id").eq("id", orgId).is("deleted_at", null).maybeSingle();
  if (!org) throw new ApiError(403, "FORBIDDEN", "A organização deste token não está ativa.");

  // last_used_at: melhor esforço, no máximo a cada 5 min (não gera escrita a cada chamada)
  const last = data.last_used_at ? Date.parse(data.last_used_at as string) : 0;
  if (Date.now() - last > TOUCH_EVERY_MS) {
    void db.from("integration_tokens").update({ last_used_at: new Date().toISOString() }).eq("id", data.id as string).then(() => {}, () => {});
  }
  return { db, orgId, tokenId: data.id as string };
}
