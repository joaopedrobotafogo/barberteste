import { NextResponse } from "next/server";
import { authenticate, type IntegrationCtx } from "./auth";
import { ApiError, failure } from "./http";

type Handler<P> = (ctx: IntegrationCtx, req: Request, params: P) => Promise<NextResponse>;

/**
 * Envolve todo endpoint: autentica, converte ApiError em resposta padronizada,
 * esconde erros internos e registra log útil (sem token, sem dados pessoais).
 */
export function integrationRoute<P = Record<string, never>>(operation: string, handler: Handler<P>) {
  return async (req: Request, routeCtx: { params: Promise<P> }): Promise<NextResponse> => {
    let orgId = "-";
    try {
      const ctx = await authenticate(req);
      orgId = ctx.orgId;
      const params = await routeCtx.params;
      return await handler(ctx, req, params);
    } catch (e) {
      if (e instanceof ApiError) {
        console.warn(`[integration] organization=${orgId} operation=${operation} success=false reason=${e.code}`);
        return failure(e.status, e.code, e.message);
      }
      console.error(`[integration] organization=${orgId} operation=${operation} success=false reason=INTERNAL_ERROR`, e instanceof Error ? e.message : "erro desconhecido");
      return failure(500, "INTERNAL_ERROR", "Erro interno. Tente novamente.");
    }
  };
}
