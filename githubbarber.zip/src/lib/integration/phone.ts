/**
 * Telefones do WhatsApp (Brasil).
 *
 * O banco já tem clients.phone_normalized = só dígitos do campo `phone` (coluna gerada).
 * Esta lib NÃO cria outra normalização: apenas gera as VARIANTES de dígitos sob as quais um mesmo
 * número pode estar salvo (com/sem 55, com/sem o 9º dígito) para a busca em phone_normalized.
 *
 * Armazenamento (decisão da Etapa 9): clientes criados pela API são salvos no formato nacional
 * "(21) 99999-9999", igual ao da tela de Clientes; o 55 vive só na busca e na resposta `whatsapp_phone`.
 */
export interface BrPhone {
  /** DDD + número (10 ou 11 dígitos), sem 55. */
  national: string;
  /** 55 + national: formato do WhatsApp. */
  whatsapp: string;
  /** Como o app exibe/salva: (21) 99999-9999. */
  display: string;
  /** Todos os valores de phone_normalized sob os quais este número pode existir. */
  variants: string[];
}

export function parseBrPhone(raw: unknown): BrPhone | null {
  if (typeof raw !== "string" || raw.length > 40) return null;
  let d = raw.replace(/\D/g, "");
  if ((d.length === 12 || d.length === 13) && d.startsWith("55")) d = d.slice(2);
  if (d.length !== 10 && d.length !== 11) return null;
  // DDD: dois dígitos, nenhum começando com 0
  if (d[0] === "0" || d[1] === "0") return null;
  // celular com 11 dígitos precisa começar com 9 depois do DDD
  if (d.length === 11 && d[2] !== "9") return null;

  const ddd = d.slice(0, 2);
  const rest = d.slice(2);
  const display = d.length === 11
    ? `(${ddd}) ${rest.slice(0, 5)}-${rest.slice(5)}`
    : `(${ddd}) ${rest.slice(0, 4)}-${rest.slice(4)}`;

  const nationals = new Set([d]);
  // Números antigos de WhatsApp podem estar sem o 9º dígito (e vice-versa)
  if (d.length === 11) nationals.add(ddd + rest.slice(1));
  else if (/[6-9]/.test(rest[0])) nationals.add(ddd + "9" + rest);

  const variants: string[] = [];
  for (const n of nationals) variants.push(n, "55" + n);
  return { national: d, whatsapp: "55" + d, display, variants };
}
