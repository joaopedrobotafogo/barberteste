import { computeSlots, localParts, weekdayKey, zonedToUtc } from "@/lib/agenda";
import {
  computeBarberSlots, loadAgendaSettings, type AgendaSettings,
} from "@/lib/agenda-core";
import { normalizeHours } from "@/lib/settings";
import type { IntegrationCtx } from "./auth";
import { ApiError } from "./http";
import { parseBrPhone, type BrPhone } from "./phone";
import {
  assertDateWindow, optSource, optText, optUuid, reqDate, reqText, reqTime, reqUuid, type IntegrationSource,
} from "./validate";

/**
 * Operações da API de integração. Cada função recebe o contexto autenticado (orgId vindo do token)
 * e filtra TODA consulta por organization_id, pois o cliente Supabase usado aqui ignora a RLS.
 * Disponibilidade e conflito usam o MESMO núcleo da tela de Agenda (lib/agenda-core.ts + computeSlots),
 * e o banco (appointments_no_overlap + triggers) continua sendo a barreira final contra conflito.
 */

const CHANGEABLE = ["pending", "confirmed"] as const; // únicos status que cancelar/remarcar aceitam
const INITIAL_STATUS = "confirmed"; // mesmo padrão da tela de Agenda (appointment-form) e do banco

const STATUS_PT: Record<string, string> = {
  pending: "aguardando", confirmed: "confirmado", completed: "concluído", cancelled: "cancelado", no_show: "no-show",
};

const notFound = (code: ConstructorParameters<typeof ApiError>[1], message: string) => new ApiError(404, code, message);
const internal = (what: string, e: unknown) => {
  console.error(`[integration] ${what}:`, (e as { code?: string; message?: string })?.code, (e as { message?: string })?.message);
  return new ApiError(500, "INTERNAL_ERROR", "Erro interno. Tente novamente.");
};

// ================================================================= organização / catálogo
export async function getBusiness(ctx: IntegrationCtx) {
  const [org, st] = await Promise.all([
    ctx.db.from("organizations").select("name, phone, address").eq("id", ctx.orgId).is("deleted_at", null).maybeSingle(),
    ctx.db.from("business_settings")
      .select("timezone, opening_hours, slot_interval_minutes, min_notice_minutes")
      .eq("organization_id", ctx.orgId).maybeSingle(),
  ]);
  if (org.error || st.error) throw internal("business", org.error ?? st.error);
  if (!org.data) throw new ApiError(403, "FORBIDDEN", "A organização deste token não está ativa.");
  const tz = (st.data?.timezone as string | undefined) ?? "America/Sao_Paulo";
  const now = localParts(new Date().toISOString(), tz);
  return {
    name: org.data.name as string,
    phone: (org.data.phone as string | null) ?? null,
    address: (org.data.address as string | null) ?? null,
    timezone: tz,
    /** Agora, no fuso da barbearia: use para resolver "hoje", "amanhã", "sexta"... */
    now: { date: now.date, time: now.time, weekday: weekdayKey(now.date) },
    /** Chaves mon..sun. Dia fechado = null; aberto = { open, close } em HH:MM. */
    opening_hours: normalizeHours(st.data?.opening_hours),
    slot_interval_minutes: (st.data?.slot_interval_minutes as number | undefined) ?? 15,
    min_notice_minutes: (st.data?.min_notice_minutes as number | undefined) ?? 0,
  };
}

export async function listServices(ctx: IntegrationCtx) {
  const { data, error } = await ctx.db.from("services")
    .select("id, name, description, price, duration_minutes")
    .eq("organization_id", ctx.orgId).eq("is_active", true).is("deleted_at", null).order("name");
  if (error) throw internal("services", error);
  return (data ?? []).map((s) => ({
    id: s.id as string, name: s.name as string, description: (s.description as string | null) ?? null,
    price: Number(s.price), duration_minutes: s.duration_minutes as number,
  }));
}

export async function listBarbers(ctx: IntegrationCtx) {
  const { data, error } = await ctx.db.from("barbers")
    .select("id, name")
    .eq("organization_id", ctx.orgId).eq("is_active", true).is("deleted_at", null).order("name");
  if (error) throw internal("barbers", error);
  return (data ?? []).map((b) => ({ id: b.id as string, name: b.name as string }));
}

async function loadService(ctx: IntegrationCtx, id: string, opts: { requireActive: boolean }) {
  const { data, error } = await ctx.db.from("services")
    .select("id, name, price, duration_minutes, is_active")
    .eq("organization_id", ctx.orgId).eq("id", id).is("deleted_at", null).maybeSingle();
  if (error) throw internal("service", error);
  if (!data || (opts.requireActive && !data.is_active)) throw notFound("SERVICE_NOT_FOUND", "Serviço não encontrado ou inativo.");
  return { id: data.id as string, name: data.name as string, price: Number(data.price), duration_minutes: data.duration_minutes as number };
}

async function loadBarber(ctx: IntegrationCtx, id: string) {
  const { data, error } = await ctx.db.from("barbers")
    .select("id, name, is_active")
    .eq("organization_id", ctx.orgId).eq("id", id).is("deleted_at", null).maybeSingle();
  if (error) throw internal("barber", error);
  if (!data || !data.is_active) throw notFound("BARBER_NOT_FOUND", "Barbeiro não encontrado ou inativo.");
  return { id: data.id as string, name: data.name as string };
}

// ================================================================= clientes
interface ClientRow { id: string; name: string; phone: string; phone_normalized: string; status?: string }

const clientOut = (c: ClientRow) => {
  const p = parseBrPhone(c.phone_normalized) ?? parseBrPhone(c.phone);
  return {
    id: c.id, name: c.name, phone: c.phone,
    whatsapp_phone: p?.whatsapp ?? c.phone_normalized,
    status: c.status ?? "new", // new | active | at_risk | lost (regra centralizada no banco)
  };
};

/** Busca tolerante: com/sem 55, com/sem o 9º dígito. Se houver duplicatas antigas, devolve a mais antiga. */
async function findClientByPhone(ctx: IntegrationCtx, phone: BrPhone): Promise<ClientRow | null> {
  const { data, error } = await ctx.db.from("client_overview")
    .select("id, name, phone, phone_normalized, status, created_at")
    .eq("organization_id", ctx.orgId).in("phone_normalized", phone.variants)
    .order("created_at", { ascending: true }).limit(1);
  if (error) throw internal("find_client", error);
  return (data?.[0] as ClientRow | undefined) ?? null;
}

function parsePhoneOrThrow(raw: unknown): BrPhone {
  const p = parseBrPhone(raw);
  if (!p) throw new ApiError(400, "INVALID_INPUT", "Telefone inválido. Informe DDD + número (ex.: 21999999999 ou 5521999999999).");
  return p;
}

export async function getClientByPhone(ctx: IntegrationCtx, rawPhone: unknown) {
  const phone = parsePhoneOrThrow(rawPhone);
  const c = await findClientByPhone(ctx, phone);
  if (!c) throw notFound("CLIENT_NOT_FOUND", "Cliente não encontrado para este telefone.");
  return clientOut(c);
}

export async function createClientIdempotent(ctx: IntegrationCtx, body: Record<string, unknown>) {
  const name = reqText(body.name, "name", 100);
  const phone = parsePhoneOrThrow(body.phone);

  const existing = await findClientByPhone(ctx, phone);
  if (existing) return { client: clientOut(existing), created: false };

  const { data, error } = await ctx.db.from("clients")
    .insert({ organization_id: ctx.orgId, name, phone: phone.display })
    .select("id, name, phone, phone_normalized");
  if (error) {
    if (error.code === "23505") { // corrida: outra requisição criou o mesmo telefone um instante antes
      const again = await findClientByPhone(ctx, phone);
      if (again) return { client: clientOut(again), created: false };
    }
    throw internal("create_client", error);
  }
  return { client: clientOut({ ...(data![0] as ClientRow), status: "new" }), created: true };
}

async function resolveClient(ctx: IntegrationCtx, body: Record<string, unknown>) {
  const id = optUuid(body.client_id, "client_id");
  if (id) {
    const { data, error } = await ctx.db.from("clients").select("id, name, phone, phone_normalized")
      .eq("organization_id", ctx.orgId).eq("id", id).is("deleted_at", null).maybeSingle();
    if (error) throw internal("client", error);
    if (!data) throw notFound("CLIENT_NOT_FOUND", "Cliente não encontrado.");
    return data as ClientRow;
  }
  if (body.phone === undefined || body.phone === null || body.phone === "") {
    throw new ApiError(400, "INVALID_INPUT", "Informe 'client_id' ou 'phone'.");
  }
  const c = await findClientByPhone(ctx, parsePhoneOrThrow(body.phone));
  if (!c) throw notFound("CLIENT_NOT_FOUND", "Cliente não encontrado para este telefone. Crie o cliente primeiro (POST /clients).");
  return c;
}

// ================================================================= disponibilidade
export async function getAvailability(ctx: IntegrationCtx, q: { serviceId: unknown; barberId: unknown; date: unknown }) {
  const serviceId = reqUuid(q.serviceId, "service_id");
  const barberId = optUuid(q.barberId, "barber_id");
  const date = reqDate(q.date);

  const settings = await loadAgendaSettings(ctx.db, ctx.orgId);
  assertDateWindow(date, settings.timezone);
  const service = await loadService(ctx, serviceId, { requireActive: true });
  const barbers = barberId ? [await loadBarber(ctx, barberId)] : await listBarbers(ctx);

  const results = await Promise.all(barbers.map(async (b) => {
    const r = await computeBarberSlots(ctx.db, ctx.orgId, {
      settings, durationMin: service.duration_minutes, barberId: b.id, date,
    });
    if (r.error) throw new ApiError(500, "INTERNAL_ERROR", r.error);
    return { id: b.id, name: b.name, slots: r.slots, closed: r.closed };
  }));

  const closed = !settings.openingHours[weekdayKey(date)];
  return {
    date, timezone: settings.timezone, closed,
    service: { id: service.id, name: service.name, duration_minutes: service.duration_minutes, price: service.price },
    barbers: results.map(({ id, name, slots }) => ({ id, name, slots })),
  };
}

/**
 * Revalida um horário no servidor com a MESMA regra da Agenda e devolve o motivo exato da recusa.
 * Nunca confia no resultado de uma consulta anterior de disponibilidade.
 */
async function assertBookable(
  ctx: IntegrationCtx, settings: AgendaSettings,
  o: { durationMin: number; barberId: string; date: string; time: string; excludeId?: string },
) {
  const hours = settings.openingHours[weekdayKey(o.date)] ?? null;
  if (!hours) throw new ApiError(409, "BUSINESS_CLOSED", "A barbearia está fechada neste dia.");

  const base = { date: o.date, tz: settings.timezone, hours, durationMin: o.durationMin, intervalMin: settings.interval, busy: [] };
  // 1) expediente + grade de horários, ignorando agenda e antecedência
  if (!computeSlots({ ...base, minNoticeMin: 0, now: 0 }).includes(o.time)) {
    throw new ApiError(409, "OUTSIDE_BUSINESS_HOURS",
      "Horário fora do funcionamento (ou o atendimento ultrapassaria o fechamento) ou fora dos intervalos da agenda. Use um horário retornado em /availability.");
  }
  // 2) slots reais (agendamentos + bloqueios + antecedência) pelo núcleo compartilhado da Agenda
  const r = await computeBarberSlots(ctx.db, ctx.orgId, {
    settings, durationMin: o.durationMin, barberId: o.barberId, date: o.date, excludeId: o.excludeId,
  });
  if (r.error) throw new ApiError(500, "INTERNAL_ERROR", r.error);
  if (r.slots.includes(o.time)) return;

  // diagnóstico: passado/antecedência mínima ou ocupado?
  if (!computeSlots({ ...base, minNoticeMin: settings.minNotice }).includes(o.time)) {
    throw new ApiError(409, "TOO_SOON", "Esse horário já passou ou está dentro da antecedência mínima da barbearia.");
  }
  throw new ApiError(409, "TIME_UNAVAILABLE", "Esse horário não está mais disponível.");
}

// ================================================================= agendamentos
const APPT_COLS = "id, client_id, barber_id, service_id, start_at, end_at, status, price, notes, source";
interface ApptRow {
  id: string; client_id: string; barber_id: string; service_id: string;
  start_at: string; end_at: string; status: string; price: number | string; notes: string | null; source: string;
}

type NameRef = { id: string; name: string };
interface ViewParts {
  client: { id: string; name: string; phone: string } | null;
  service: { id: string; name: string; duration_minutes: number } | null;
  barber: NameRef | null;
}

/** Formato único de um agendamento na API (usado por get/create/cancel/reschedule e pela listagem). */
function shapeAppointment(row: ApptRow, tz: string, parts: ViewParts) {
  const start = localParts(row.start_at, tz);
  const end = localParts(row.end_at, tz);
  return {
    id: row.id,
    status: row.status,
    source: row.source,
    date: start.date, time: start.time, end_time: end.time,
    start_at: row.start_at, end_at: row.end_at,
    price: Number(row.price),
    notes: row.notes,
    client: parts.client,
    service: parts.service,
    barber: parts.barber,
  };
}

async function appointmentView(ctx: IntegrationCtx, row: ApptRow, tz: string) {
  const [c, s, b] = await Promise.all([
    ctx.db.from("clients").select("id, name, phone").eq("organization_id", ctx.orgId).eq("id", row.client_id).maybeSingle(),
    ctx.db.from("services").select("id, name, duration_minutes").eq("organization_id", ctx.orgId).eq("id", row.service_id).maybeSingle(),
    ctx.db.from("barbers").select("id, name").eq("organization_id", ctx.orgId).eq("id", row.barber_id).maybeSingle(),
  ]);
  if (c.error || s.error || b.error) throw internal("appointment_view", c.error ?? s.error ?? b.error);
  return shapeAppointment(row, tz, {
    client: c.data ? { id: c.data.id as string, name: c.data.name as string, phone: c.data.phone as string } : null,
    service: s.data ? { id: s.data.id as string, name: s.data.name as string, duration_minutes: s.data.duration_minutes as number } : null,
    barber: b.data ? { id: b.data.id as string, name: b.data.name as string } : null,
  });
}

async function loadAppointment(ctx: IntegrationCtx, id: string): Promise<ApptRow> {
  const { data, error } = await ctx.db.from("appointments").select(APPT_COLS)
    .eq("organization_id", ctx.orgId).eq("id", id).is("deleted_at", null).maybeSingle();
  if (error) throw internal("appointment", error);
  if (!data) throw notFound("APPOINTMENT_NOT_FOUND", "Agendamento não encontrado.");
  return data as ApptRow;
}

/**
 * Confere que o agendamento pertence ao cliente informado (client_id OU phone).
 * Divergência responde 404 igual a "não existe": não revela agendamentos de outros clientes.
 */
async function assertOwnership(ctx: IntegrationCtx, row: ApptRow, input: Record<string, unknown>) {
  const clientId = optUuid(input.client_id, "client_id");
  const hasPhone = input.phone !== undefined && input.phone !== null && input.phone !== "";
  if (!clientId && !hasPhone) {
    throw new ApiError(400, "INVALID_INPUT", "Informe 'client_id' ou 'phone' do cliente para confirmar que o agendamento é dele.");
  }
  const denied = () => notFound("APPOINTMENT_NOT_FOUND", "Agendamento não encontrado.");
  if (clientId) { if (clientId !== row.client_id) throw denied(); return; }
  const phone = parsePhoneOrThrow(input.phone);
  const { data, error } = await ctx.db.from("clients").select("phone_normalized")
    .eq("organization_id", ctx.orgId).eq("id", row.client_id).maybeSingle();
  if (error) throw internal("ownership", error);
  if (!data || !phone.variants.includes(data.phone_normalized as string)) throw denied();
}

export async function getAppointment(ctx: IntegrationCtx, idRaw: unknown, filter: Record<string, unknown>) {
  const id = reqUuid(idRaw, "id");
  const row = await loadAppointment(ctx, id);
  const hasFilter = (filter.client_id ?? "") !== "" || (filter.phone ?? "") !== "";
  if (hasFilter) await assertOwnership(ctx, row, filter); // opcional na consulta
  const st = await loadAgendaSettings(ctx.db, ctx.orgId);
  return appointmentView(ctx, row, st.timezone);
}

const LIST_DEFAULT = 10;
const LIST_MAX = 20;

/**
 * Próximos agendamentos ATIVOS (pending/confirmed, ainda não iniciados) de UM cliente, do mais próximo para o mais distante.
 * É o que o atendimento por WhatsApp precisa para "qual é meu horário?", "cancela meu horário" e "quero remarcar".
 *
 * - Cliente por `phone` (qualquer formato; com/sem 55 e 9º dígito) ou `client_id` (vale este se vierem os dois).
 * - Somente leitura. Mesmas regras de "pode cancelar/remarcar" da API: status ativo e início no futuro.
 * - Se o mesmo número existir cadastrado em mais de um formato (duplicata antiga), lista os agendamentos de todos eles.
 * - Toda consulta filtra por organization_id do token; nada de outra barbearia aparece.
 */
export async function listAppointments(ctx: IntegrationCtx, q: { phone: unknown; clientId: unknown; limit: unknown }) {
  const clientId = optUuid(q.clientId, "client_id");
  const hasPhone = q.phone !== undefined && q.phone !== null && q.phone !== "";
  if (!clientId && !hasPhone) throw new ApiError(400, "INVALID_INPUT", "Informe 'phone' ou 'client_id' do cliente.");

  let limit = LIST_DEFAULT;
  if (q.limit !== undefined && q.limit !== null && q.limit !== "") {
    const n = Number(q.limit);
    if (!Number.isInteger(n) || n < 1 || n > LIST_MAX) throw new ApiError(400, "INVALID_INPUT", `'limit' deve ser um inteiro entre 1 e ${LIST_MAX}.`);
    limit = n;
  }

  // 1) quais cadastros de cliente correspondem (sempre dentro da organização do token)
  let clients: { id: string; name: string; phone: string }[];
  if (clientId) {
    const c = await resolveClient(ctx, { client_id: clientId });
    clients = [{ id: c.id, name: c.name, phone: c.phone }];
  } else {
    const phone = parsePhoneOrThrow(q.phone);
    const { data, error } = await ctx.db.from("clients").select("id, name, phone")
      .eq("organization_id", ctx.orgId).in("phone_normalized", phone.variants).is("deleted_at", null);
    if (error) throw internal("list_clients", error);
    if (!data?.length) throw notFound("CLIENT_NOT_FOUND", "Cliente não encontrado para este telefone.");
    clients = data.map((c) => ({ id: c.id as string, name: c.name as string, phone: c.phone as string }));
  }

  // 2) próximos agendamentos ativos
  const { data, error } = await ctx.db.from("appointments").select(APPT_COLS)
    .eq("organization_id", ctx.orgId).in("client_id", clients.map((c) => c.id))
    .in("status", [...CHANGEABLE]).gt("start_at", new Date().toISOString()).is("deleted_at", null)
    .order("start_at", { ascending: true }).limit(limit);
  if (error) throw internal("list_appointments", error);
  const rows = (data ?? []) as ApptRow[];
  if (!rows.length) return { count: 0, appointments: [] };

  // 3) nomes de serviço e barbeiro em lote (2 consultas, não 2 por agendamento)
  const settings = await loadAgendaSettings(ctx.db, ctx.orgId);
  const [sv, br] = await Promise.all([
    ctx.db.from("services").select("id, name, duration_minutes").eq("organization_id", ctx.orgId)
      .in("id", [...new Set(rows.map((r) => r.service_id))]),
    ctx.db.from("barbers").select("id, name").eq("organization_id", ctx.orgId)
      .in("id", [...new Set(rows.map((r) => r.barber_id))]),
  ]);
  if (sv.error || br.error) throw internal("list_appointments_names", sv.error ?? br.error);
  // campos mapeados um a um: a resposta nunca carrega colunas além das documentadas
  const svcById = new Map<string, NonNullable<ViewParts["service"]>>((sv.data ?? []).map((x) => [x.id as string, { id: x.id as string, name: x.name as string, duration_minutes: x.duration_minutes as number }]));
  const brById = new Map<string, NameRef>((br.data ?? []).map((x) => [x.id as string, { id: x.id as string, name: x.name as string }]));
  const cliById = new Map<string, NonNullable<ViewParts["client"]>>(clients.map((c) => [c.id, c]));

  const appointments = rows.map((r) => shapeAppointment(r, settings.timezone, {
    client: cliById.get(r.client_id) ?? null,
    service: svcById.get(r.service_id) ?? null,
    barber: brById.get(r.barber_id) ?? null,
  }));
  return { count: appointments.length, appointments };
}

/** Replay seguro: mesma criação já feita (mesmo cliente, serviço, barbeiro e início, ainda ativa). */
async function findSameAppointment(
  ctx: IntegrationCtx, k: { clientId: string; barberId: string; serviceId: string; startIso: string },
): Promise<ApptRow | null> {
  const { data, error } = await ctx.db.from("appointments").select(APPT_COLS)
    .eq("organization_id", ctx.orgId).eq("client_id", k.clientId).eq("barber_id", k.barberId)
    .eq("service_id", k.serviceId).eq("start_at", k.startIso)
    .in("status", [...CHANGEABLE]).eq("is_overbook", false).is("deleted_at", null)
    .order("created_at", { ascending: true }).limit(1);
  if (error) throw internal("replay_lookup", error);
  return (data?.[0] as ApptRow | undefined) ?? null;
}

export async function createAppointment(ctx: IntegrationCtx, body: Record<string, unknown>) {
  const serviceId = reqUuid(body.service_id, "service_id");
  const barberId = reqUuid(body.barber_id, "barber_id");
  const date = reqDate(body.date);
  const time = reqTime(body.time);
  const notes = optText(body.notes, "notes", 500);
  const source: IntegrationSource = optSource(body.source);

  const settings = await loadAgendaSettings(ctx.db, ctx.orgId);
  assertDateWindow(date, settings.timezone);
  const client = await resolveClient(ctx, body);
  const service = await loadService(ctx, serviceId, { requireActive: true });
  const barber = await loadBarber(ctx, barberId);

  const start = zonedToUtc(date, time, settings.timezone);
  const end = new Date(start.getTime() + service.duration_minutes * 60_000);
  const key = { clientId: client.id, barberId: barber.id, serviceId: service.id, startIso: start.toISOString() };

  // IDEMPOTÊNCIA (sem migration): se o n8n repetir a mesma criação, devolve o agendamento já criado.
  // Precisa vir ANTES de validar o horário, pois o horário já está ocupado... por ele mesmo.
  const dup = await findSameAppointment(ctx, key);
  if (dup) return { appointment: await appointmentView(ctx, dup, settings.timezone), replay: true };

  await assertBookable(ctx, settings, { durationMin: service.duration_minutes, barberId: barber.id, date, time });

  const { data, error } = await ctx.db.from("appointments").insert({
    organization_id: ctx.orgId, client_id: client.id, barber_id: barber.id, service_id: service.id,
    start_at: key.startIso, end_at: end.toISOString(),
    status: INITIAL_STATUS, price: service.price, is_overbook: false, source, notes: notes ?? null,
    created_by: null,
  }).select(APPT_COLS);

  if (error) {
    if (error.code === "23P01" || error.code === "P0001") {
      // Corrida: alguém ocupou o horário entre a validação e o insert (ou bloqueio criado agora).
      if (error.code === "23P01") {
        const again = await findSameAppointment(ctx, key); // ou foi a MESMA requisição repetida em paralelo
        if (again) return { appointment: await appointmentView(ctx, again, settings.timezone), replay: true };
      }
      throw new ApiError(409, "TIME_UNAVAILABLE", "Esse horário não está mais disponível.");
    }
    throw internal("create_appointment", error);
  }
  return { appointment: await appointmentView(ctx, data![0] as ApptRow, settings.timezone), replay: false };
}

function assertChangeable(row: ApptRow) {
  if (!(CHANGEABLE as readonly string[]).includes(row.status)) {
    throw new ApiError(409, "INVALID_STATUS",
      `Agendamento ${STATUS_PT[row.status] ?? row.status} não pode ser alterado por esta API (só aguardando ou confirmado).`);
  }
  if (Date.parse(row.start_at) <= Date.now()) {
    throw new ApiError(409, "APPOINTMENT_IN_PAST", "Este agendamento já começou ou já passou e não pode ser alterado.");
  }
}

export async function cancelAppointment(ctx: IntegrationCtx, idRaw: unknown, body: Record<string, unknown>) {
  const id = reqUuid(idRaw, "id");
  const row = await loadAppointment(ctx, id);
  await assertOwnership(ctx, row, body);
  const settings = await loadAgendaSettings(ctx.db, ctx.orgId);

  // Repetição do cancelamento = sucesso (idempotente)
  if (row.status === "cancelled") return { appointment: await appointmentView(ctx, row, settings.timezone), already: true };
  assertChangeable(row);

  // Mesma operação da Agenda: status -> cancelled (o trigger do banco carimba cancelled_at e libera o horário).
  const { data, error } = await ctx.db.from("appointments").update({ status: "cancelled" })
    .eq("organization_id", ctx.orgId).eq("id", id).in("status", [...CHANGEABLE]).is("deleted_at", null)
    .select(APPT_COLS);
  if (error) throw internal("cancel_appointment", error);
  if (!data?.length) { // mudou de status entre a leitura e o update
    const now = await loadAppointment(ctx, id);
    if (now.status === "cancelled") return { appointment: await appointmentView(ctx, now, settings.timezone), already: true };
    throw new ApiError(409, "INVALID_STATUS", "O agendamento mudou de status e não pode mais ser cancelado.");
  }
  return { appointment: await appointmentView(ctx, data[0] as ApptRow, settings.timezone), already: false };
}

export async function rescheduleAppointment(ctx: IntegrationCtx, idRaw: unknown, body: Record<string, unknown>) {
  const id = reqUuid(idRaw, "id");
  const date = reqDate(body.date);
  const time = reqTime(body.time);
  const newBarberId = optUuid(body.barber_id, "barber_id");

  const row = await loadAppointment(ctx, id);
  await assertOwnership(ctx, row, body);
  const settings = await loadAgendaSettings(ctx.db, ctx.orgId);
  assertDateWindow(date, settings.timezone);
  assertChangeable(row);

  const barber = await loadBarber(ctx, newBarberId ?? row.barber_id);
  const service = await loadService(ctx, row.service_id, { requireActive: false }); // duração do serviço do agendamento

  const start = zonedToUtc(date, time, settings.timezone);
  const end = new Date(start.getTime() + service.duration_minutes * 60_000);

  // Repetição da mesma remarcação = sucesso, sem alterar nada
  if (barber.id === row.barber_id && Date.parse(row.start_at) === start.getTime()) {
    return { appointment: await appointmentView(ctx, row, settings.timezone), unchanged: true };
  }

  // excludeId: o próprio agendamento não conta como ocupação (pode remarcar para dentro do mesmo intervalo)
  await assertBookable(ctx, settings, { durationMin: service.duration_minutes, barberId: barber.id, date, time, excludeId: id });

  const { data, error } = await ctx.db.from("appointments")
    .update({ start_at: start.toISOString(), end_at: end.toISOString(), barber_id: barber.id })
    .eq("organization_id", ctx.orgId).eq("id", id).in("status", [...CHANGEABLE]).is("deleted_at", null)
    .select(APPT_COLS);
  if (error) {
    if (error.code === "23P01" || error.code === "P0001") throw new ApiError(409, "TIME_UNAVAILABLE", "Esse horário não está mais disponível.");
    throw internal("reschedule_appointment", error);
  }
  if (!data?.length) throw new ApiError(409, "INVALID_STATUS", "O agendamento mudou de status e não pode mais ser remarcado.");
  return { appointment: await appointmentView(ctx, data[0] as ApptRow, settings.timezone), unchanged: false };
}
