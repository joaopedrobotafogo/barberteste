import type { getContext } from "@/lib/auth";
import { addDays, localParts, todayIn, zonedToUtc } from "@/lib/agenda";
import { getTimezone } from "@/lib/clients";

type Ctx = Awaited<ReturnType<typeof getContext>>;

export const PERIODS = [
  { key: "hoje", label: "Hoje" },
  { key: "7d", label: "Últimos 7 dias" },
  { key: "30d", label: "Últimos 30 dias" },
  { key: "mes", label: "Este mês" },
] as const;
export type PeriodKey = (typeof PERIODS)[number]["key"];
export const DEFAULT_PERIOD: PeriodKey = "mes";
export const isPeriod = (v?: string): v is PeriodKey => PERIODS.some((p) => p.key === v);

export const TX_PAGE_SIZE = 20;
const DB_PAGE = 1000; // limite padrão de linhas por requisição do PostgREST
const MAX_DB_PAGES = 10; // teto de segurança: 10.000 pagamentos por período

export interface DayPoint { date: string; revenue: number; count: number }
export interface GroupStat { id: string; name: string; revenue: number; count: number }
export interface TxItem {
  id: string; date: string; time: string;
  clientName: string; serviceName: string; barberName: string; amount: number;
}

export interface FinanceData {
  tz: string;
  period: PeriodKey;
  startDay: string;
  today: string;
  error: boolean;
  /** true se o período passou do teto de linhas e os totais podem estar incompletos */
  truncated: boolean;
  total: number;
  count: number;
  avgTicket: number;
  uniqueClients: number;
  days: DayPoint[];
  byService: GroupStat[];
  byBarber: GroupStat[];
  tx: { items: TxItem[]; total: number; page: number; lastPage: number; namesError: boolean };
}

export interface PaymentRow {
  id: string; amount: number | string; paid_at: string;
  client_id: string; service_id: string; barber_id: string;
}

export const cents = (v: number | string) => Math.round(Number(v) * 100);
export const fromCents = (c: number) => c / 100;

/** Dias do período no fuso da barbearia. "7 dias" e "30 dias" incluem hoje; "mês" vai do dia 1 até hoje. */
export function periodRange(period: PeriodKey, tz: string) {
  const today = todayIn(tz);
  const startDay =
    period === "hoje" ? today
      : period === "7d" ? addDays(today, -6)
        : period === "30d" ? addDays(today, -29)
          : `${today.slice(0, 7)}-01`;
  return {
    today,
    startDay,
    from: zonedToUtc(startDay, "00:00", tz).toISOString(),
    to: zonedToUtc(addDays(today, 1), "00:00", tz).toISOString(),
  };
}

export function daysBetween(startDay: string, endDay: string): string[] {
  const out: string[] = [];
  for (let d = startDay; d <= endDay && out.length < 400; d = addDays(d, 1)) out.push(d);
  return out;
}

/**
 * Pagamentos ativos do período (soft delete excluído), da organização atual.
 * Fonte única: tabela payments, que o banco alimenta ao concluir o atendimento
 * (trigger appointments_sync_payment). Cancelado/no-show/reaberto = pagamento anulado pelo trigger.
 */
async function fetchPayments(ctx: Ctx, from: string, to: string): Promise<{ rows: PaymentRow[]; error: boolean; truncated: boolean }> {
  const rows: PaymentRow[] = [];
  let truncated = false;
  for (let page = 0; page < MAX_DB_PAGES; page++) {
    const { data, error } = await ctx.supabase.from("payments")
      .select("id, amount, paid_at, client_id, service_id, barber_id")
      .eq("organization_id", ctx.org.id).is("deleted_at", null)
      .gte("paid_at", from).lt("paid_at", to)
      .order("paid_at", { ascending: false }).order("id")
      .range(page * DB_PAGE, page * DB_PAGE + DB_PAGE - 1);
    if (error) { console.error("[financeiro] pagamentos:", error); return { rows: [], error: true, truncated: false }; }
    const batch = (data ?? []) as PaymentRow[];
    rows.push(...batch);
    if (batch.length < DB_PAGE) break;
    if (page === MAX_DB_PAGES - 1) truncated = true;
  }
  return { rows, error: false, truncated };
}

function group(rows: PaymentRow[], key: "service_id" | "barber_id", names: Map<string, string>, fallback: string): GroupStat[] {
  const acc = new Map<string, { cents: number; count: number }>();
  for (const r of rows) {
    const cur = acc.get(r[key]) ?? { cents: 0, count: 0 };
    cur.cents += cents(r.amount); cur.count += 1;
    acc.set(r[key], cur);
  }
  return [...acc.entries()]
    .map(([id, v]) => ({ id, name: names.get(id) ?? fallback, revenue: fromCents(v.cents), count: v.count }))
    .sort((a, b) => b.revenue - a.revenue || b.count - a.count || a.name.localeCompare(b.name, "pt-BR"));
}

/** Base de receita compartilhada por Financeiro e Relatórios: mesma consulta, mesmas regras, mesmos números. */
export interface RevenueBase {
  tz: string; period: PeriodKey; startDay: string; today: string;
  error: boolean; truncated: boolean;
  rows: PaymentRow[]; // mais recente primeiro
  total: number; count: number; avgTicket: number;
  clientIds: string[]; // clientes únicos atendidos (com pagamento) no período
  days: DayPoint[]; byService: GroupStat[]; byBarber: GroupStat[];
  svcNames: Map<string, string>; barNames: Map<string, string>;
}

export const toNameMap = (d: unknown) => new Map(((d ?? []) as { id: string; name: string }[]).map((x) => [x.id, x.name]));

export async function loadRevenueBase(ctx: Ctx, period: PeriodKey, knownTz?: string): Promise<RevenueBase> {
  const { supabase, org } = ctx;
  const tz = knownTz ?? (await getTimezone(supabase));
  const { today, startDay, from, to } = periodRange(period, tz);

  // Pagamentos + nomes de serviços/barbeiros (listas pequenas, inclui inativos/removidos para o histórico) em paralelo.
  const [pay, svcRes, barRes] = await Promise.all([
    fetchPayments(ctx, from, to),
    supabase.from("services").select("id, name").eq("organization_id", org.id),
    supabase.from("barbers").select("id, name").eq("organization_id", org.id),
  ]);
  if (svcRes.error) console.error("[financeiro] serviços:", svcRes.error);
  if (barRes.error) console.error("[financeiro] barbeiros:", barRes.error);

  const svcNames = toNameMap(svcRes.data);
  const barNames = toNameMap(barRes.data);

  const rows = pay.rows;
  const totalCents = rows.reduce((s, r) => s + cents(r.amount), 0);
  const count = rows.length;

  // faturamento por dia (dias sem pagamento aparecem com 0: é o valor real)
  const perDay = new Map<string, { cents: number; count: number }>();
  for (const r of rows) {
    const day = localParts(r.paid_at, tz).date;
    const cur = perDay.get(day) ?? { cents: 0, count: 0 };
    cur.cents += cents(r.amount); cur.count += 1;
    perDay.set(day, cur);
  }
  const days: DayPoint[] = daysBetween(startDay, today).map((date) => ({
    date, revenue: fromCents(perDay.get(date)?.cents ?? 0), count: perDay.get(date)?.count ?? 0,
  }));

  return {
    tz, period, startDay, today,
    error: pay.error, truncated: pay.truncated,
    rows, total: fromCents(totalCents), count,
    avgTicket: count > 0 ? Math.round(totalCents / count) / 100 : 0,
    clientIds: Array.from(new Set<string>(rows.map((r) => r.client_id))),
    days,
    byService: group(rows, "service_id", svcNames, "Serviço removido"),
    byBarber: group(rows, "barber_id", barNames, "Barbeiro removido"),
    svcNames, barNames,
  };
}

export async function loadFinance(ctx: Ctx, period: PeriodKey, requestedPage: number): Promise<FinanceData> {
  const { supabase, org } = ctx;
  const b = await loadRevenueBase(ctx, period);
  const rows = b.rows;

  // lista paginada (já vem ordenada do mais recente para o mais antigo)
  const lastPage = Math.max(1, Math.ceil(b.count / TX_PAGE_SIZE));
  const page = Math.min(Math.max(1, requestedPage), lastPage);
  const slice = rows.slice((page - 1) * TX_PAGE_SIZE, page * TX_PAGE_SIZE);

  let clientNames = new Map<string, string>();
  let namesError = false;
  if (slice.length) {
    const { data, error } = await supabase.from("clients").select("id, name")
      .eq("organization_id", org.id).in("id", [...new Set(slice.map((r) => r.client_id))]);
    if (error) { console.error("[financeiro] clientes:", error); namesError = true; }
    clientNames = toNameMap(data);
  }

  const items: TxItem[] = slice.map((r) => {
    const p = localParts(r.paid_at, b.tz);
    return {
      id: r.id, date: p.date, time: p.time, amount: Number(r.amount),
      clientName: clientNames.get(r.client_id) ?? "Cliente",
      serviceName: b.svcNames.get(r.service_id) ?? "Serviço removido",
      barberName: b.barNames.get(r.barber_id) ?? "—",
    };
  });

  return {
    tz: b.tz, period, startDay: b.startDay, today: b.today,
    error: b.error, truncated: b.truncated,
    total: b.total, count: b.count, avgTicket: b.avgTicket,
    uniqueClients: b.clientIds.length,
    days: b.days, byService: b.byService, byBarber: b.byBarber,
    tx: { items, total: b.count, page, lastPage, namesError },
  };
}
