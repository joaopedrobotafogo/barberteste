import { createClient } from "@supabase/supabase-js";

export class AdminConfigError extends Error {}

function jwtRole(key: string): string | null {
  try {
    const part = key.split(".")[1];
    if (!part) return null;
    const json = Buffer.from(part.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
    return (JSON.parse(json) as { role?: string }).role ?? null;
  } catch {
    return null;
  }
}

/**
 * Cliente com service role: ignora RLS. Usar SOMENTE no servidor e sempre filtrando por organization_id:
 *  - Server Actions do OWNER (depois de validar que o usuário é OWNER);
 *  - API de integração (src/lib/integration), onde a organização vem do token Bearer.
 * Lança AdminConfigError com mensagem clara se a configuração estiver errada.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  if (!url) throw new AdminConfigError("NEXT_PUBLIC_SUPABASE_URL não está configurada no servidor.");
  if (!key) {
    throw new AdminConfigError(
      "SUPABASE_SERVICE_ROLE_KEY não está configurada no servidor. Adicione em .env.local e reinicie o `npm run dev`."
    );
  }
  if (key.startsWith("sb_publishable_") || jwtRole(key) === "anon") {
    throw new AdminConfigError(
      "SUPABASE_SERVICE_ROLE_KEY contém a chave anon/publishable. Use a chave service_role (secret) em Project Settings > API."
    );
  }
  return createClient(url, key, { auth: { autoRefreshToken: false, persistSession: false } });
}
