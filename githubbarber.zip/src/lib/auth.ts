import { cache } from "react";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { createClient } from "@/lib/supabase/server";
import type { Organization, Profile } from "@/lib/types";

/**
 * Contexto do usuário logado (usado por layouts, páginas e actions).
 * - Se o usuário acabou de se cadastrar e ainda não tem profile, cria a barbearia
 *   chamando a função do banco create_organization_with_owner (dados vêm do user_metadata).
 * - Barbeiro desativado perde acesso ao app.
 */
export const getContext = cache(async () => {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const loadProfile = async () =>
    (await supabase
      .from("profiles")
      .select("id, organization_id, full_name, phone, role")
      .eq("id", user.id)
      .is("deleted_at", null)
      .maybeSingle()).data as Profile | null;

  let profile = await loadProfile();

  if (!profile) {
    const m = (user.user_metadata ?? {}) as Record<string, string | undefined>;
    if (m.org_name && m.owner_name) {
      const { error } = await supabase.rpc("create_organization_with_owner", {
        p_org_name: m.org_name,
        p_owner_name: m.owner_name,
        p_phone: m.phone ?? null,
      });
      if (!error) profile = await loadProfile();
    }
  }
  if (!profile) redirect("/sem-barbearia");

  if (profile.role === "barber") {
    const { data: barber } = await supabase
      .from("barbers")
      .select("is_active")
      .eq("profile_id", profile.id)
      .is("deleted_at", null)
      .maybeSingle();
    if (barber && barber.is_active === false) redirect("/sem-barbearia?motivo=inativo");
  }

  const { data: org } = await supabase
    .from("organizations")
    .select("id, name")
    .eq("id", profile.organization_id)
    .single();

  return { supabase, user, profile, org: org as Organization };
});

/** Para páginas/actions exclusivas do dono. A segurança real continua na RLS. */
export async function requireOwner() {
  const ctx = await getContext();
  if (ctx.profile.role !== "owner") redirect("/");
  return ctx;
}

export async function siteUrl() {
  const env = process.env.NEXT_PUBLIC_SITE_URL;
  if (env) return env.replace(/\/$/, "");
  const h = await headers();
  return `${h.get("x-forwarded-proto") ?? "http"}://${h.get("host")}`;
}
