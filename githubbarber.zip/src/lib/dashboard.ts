import type { getContext } from "@/lib/auth";
import { addDays, localParts, todayIn, zonedToUtc } from "@/lib/agenda";
import { getTimezone } from "@/lib/clients";
import type { AppointmentStatus, ClientStatus } from "@/lib/types";

type Ctx = Awaited<ReturnType<typeof getContext>>;

export const NEW_CLIENT_DAYS = 7;
const UPCOMING_LIMIT = 6;
const REACTIVATE_LIMIT = 5;
// Barbeiro sem registro em `barbers`: nenhum agendamento pode casar (mesma ideia da Agenda, que bloqueia as actions).
const NO_BARBER = "00000000-0000-0000-0000-000000000000";

export interface UpcomingItem {
  id: string;
  time: string;
  clientName: string;
  serviceName: string;
  barberName: string;
  status: AppointmentStatus;
}

export interface ReactivateItem {
  id: string;
  name: string;
  phone: string;
  status: ClientStatus;
  isVip: boolean;
  visits: number;
  lastVisitAt: string | null;
}

export interface DashboardData {
  tz: string;
  today: string;
  isOwner: boolean;
  /** Agendamentos do dia (pendente, confirmado ou concluído; cancelados e no-show ficam de fora). */
  day: { error: boolean; scheduled: number; completed: number };
  /** null para BARBER: pagamentos só são legíveis pelo dono (RLS payments_select_owner). */
  revenue: { error: boolean; total: number; paidCount: number; avgTicket: number } | null;
  newClients: { error: boolean; count: number };
  upcoming: { error: boolean; items: UpcomingItem[]; more: number };
  reactivate: { error: boolean; items: ReactivateItem[]; total: number };
  /** Primeiros passos (só dono). */
  steps: { done: boolean; label: string; href: string }[];
}

interface ApptRow {
  id: string; client_id: string; barber_id: string; service_id: string;
  start_at: string; status: AppointmentStatus;
}
interface OverviewRow {
  id: string; name: string; phone: string; status: ClientStatus;
  is_vip: boolean; visits: number; last_visit_at: string | null;
}

const round2 = (n: number) => Math.round(n * 100) / 100;
const uniq = (xs: string[]) => [...new Set(xs)];

async function ownBarberId(ctx: Ctx): Promise<string | null> {
  const { data } = await ctx.supabase.from("barbers").select("id")
    .eq("organization_id", ctx.org.id).eq("profile_id", ctx.profile.id).is("deleted_at", null).maybeSingle();
  return (data?.id as string | undefined) ?? null;
}

/**
 * Todas as consultas filtram por organization_id (além da RLS). Nenhum cliente service_role é usado.
 * Status de cliente vem da view client_overview (client_status() no banco): nada é recalculado aqui.
 */
export async function loadDashboard(ctx: Ctx): Promise<DashboardData> {
  const { supabase, org, profile } = ctx;
  const isOwner = profile.role === "owner";

  const [tz, ownId] = await Promise.all([
    getTimezone(supabase),
    isOwner ? Promise.resolve<string | null>(null) : ownBarberId(ctx),
  ]);

  const today = todayIn(tz);
  const dayStart = zonedToUtc(today, "00:00", tz).toISOString();
  const dayEnd = zonedToUtc(addDays(today, 1), "00:00", tz).toISOString();
  const newSince = zonedToUtc(addDays(today, -(NEW_CLIENT_DAYS - 1)), "00:00", tz).toISOString();

  let apptQuery = supabase.from("appointments")
    .select("id, client_id, barber_id, service_id, start_at, status")
    .eq("organization_id", org.id).is("deleted_at", null)
    .gte("start_at", dayStart).lt("start_at", dayEnd).order("start_at");
  if (!isOwner) apptQuery = apptQuery.eq("barber_id", ownId ?? NO_BARBER); // BARBER: só a própria agenda, como em /agenda

  const paymentsQuery = isOwner
    ? supabase.from("payments").select("amount")
      .eq("organization_id", org.id).is("deleted_at", null)
      .gte("paid_at", dayStart).lt("paid_at", dayEnd)
    : null;

  const stepsQueries = isOwner
    ? Promise.all([
      supabase.from("services").select("id", { count: "exact", head: true }).eq("organization_id", org.id).is("deleted_at", null),
      supabase.from("barbers").select("id", { count: "exact", head: true }).eq("organization_id", org.id).is("deleted_at", null),
    ])
    : null;

  const [apptRes, payRes, newRes, reactRes, stepRes] = await Promise.all([
    apptQuery,
    paymentsQuery,
    supabase.from("clients").select("id", { count: "exact", head: true })
      .eq("organization_id", org.id).is("deleted_at", null).gte("created_at", newSince),
    supabase.from("client_overview")
      .select("id, name, phone, status, is_vip, visits, last_visit_at", { count: "exact" })
      .eq("organization_id", org.id).in("status", ["at_risk", "lost"])
      .order("status") // 'at_risk' antes de 'lost'
      .order("visits", { ascending: false })
      .order("last_visit_at", { ascending: false, nullsFirst: false })
      .order("id")
      .limit(REACTIVATE_LIMIT),
    stepsQueries,
  ]);

  if (apptRes.error) console.error("[dashboard] agendamentos:", apptRes.error);
  if (payRes?.error) console.error("[dashboard] pagamentos:", payRes.error);
  if (newRes.error) console.error("[dashboard] clientes novos:", newRes.error);
  if (reactRes.error) console.error("[dashboard] reativação:", reactRes.error);

  // ---- agendamentos do dia
  const rows = (apptRes.data ?? []) as ApptRow[];
  const counted = rows.filter((a) => a.status === "pending" || a.status === "confirmed" || a.status === "completed");
  const completed = counted.filter((a) => a.status === "completed").length;

  // ---- próximos horários: hoje, ainda não começaram, só pendente/confirmado (sem cancelado, no-show ou concluído)
  const nowMs = Date.now();
  const upcomingAll = rows.filter((a) => (a.status === "pending" || a.status === "confirmed") && Date.parse(a.start_at) >= nowMs);
  const shown = upcomingAll.slice(0, UPCOMING_LIMIT);

  let upcomingItems: UpcomingItem[] = [];
  if (shown.length) {
    const [c, s, b] = await Promise.all([
      supabase.from("clients").select("id, name").eq("organization_id", org.id).in("id", uniq(shown.map((a) => a.client_id))),
      supabase.from("services").select("id, name").eq("organization_id", org.id).in("id", uniq(shown.map((a) => a.service_id))),
      supabase.from("barbers").select("id, name").eq("organization_id", org.id).in("id", uniq(shown.map((a) => a.barber_id))),
    ]);
    if (c.error || s.error || b.error) console.error("[dashboard] nomes:", c.error ?? s.error ?? b.error);
    const toMap = (d: unknown) => new Map(((d ?? []) as { id: string; name: string }[]).map((x) => [x.id, x.name]));
    const cm = toMap(c.data), sm = toMap(s.data), bm = toMap(b.data);
    upcomingItems = shown.map((a) => ({
      id: a.id,
      time: localParts(a.start_at, tz).time,
      clientName: cm.get(a.client_id) ?? "Cliente",
      serviceName: sm.get(a.service_id) ?? "Serviço",
      barberName: bm.get(a.barber_id) ?? "—",
      status: a.status,
    }));
  }

  // ---- faturamento (só dono): pagamentos gerados pelo banco ao concluir o atendimento
  let revenue: DashboardData["revenue"] = null;
  if (isOwner) {
    const pays = (payRes?.data ?? []) as { amount: number | string }[];
    const total = round2(pays.reduce((sum, p) => sum + Number(p.amount), 0));
    revenue = {
      error: !!payRes?.error,
      total,
      paidCount: pays.length,
      avgTicket: pays.length > 0 ? round2(total / pays.length) : 0,
    };
  }

  const steps = stepRes
    ? [
      { done: (stepRes[0].count ?? 0) > 0, label: "Cadastre seus serviços e preços", href: "/servicos" },
      { done: (stepRes[1].count ?? 0) > 1, label: "Convide os barbeiros da equipe", href: "/equipe" },
    ]
    : [];

  return {
    tz, today, isOwner,
    day: { error: !!apptRes.error, scheduled: counted.length, completed },
    revenue,
    newClients: { error: !!newRes.error, count: newRes.count ?? 0 },
    upcoming: { error: !!apptRes.error, items: upcomingItems, more: Math.max(0, upcomingAll.length - shown.length) },
    reactivate: {
      error: !!reactRes.error,
      total: reactRes.count ?? 0,
      items: ((reactRes.data ?? []) as OverviewRow[]).map((r) => ({
        id: r.id, name: r.name, phone: r.phone, status: r.status, isVip: r.is_vip,
        visits: Number(r.visits), lastVisitAt: r.last_visit_at,
      })),
    },
    steps,
  };
}
