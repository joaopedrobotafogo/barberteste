// Tipos escritos à mão a partir de supabase/migrations/0001_core_schema.sql
export type Role = "owner" | "barber";

export interface Profile {
  id: string;
  organization_id: string;
  full_name: string;
  phone: string | null;
  role: Role;
}

export interface Organization {
  id: string;
  name: string;
}

export interface Service {
  id: string;
  name: string;
  description: string | null;
  price: number;
  duration_minutes: number;
  is_active: boolean;
}

export interface Barber {
  id: string;
  profile_id: string | null;
  name: string;
  phone: string | null;
  email: string | null;
  photo_url: string | null;
  is_active: boolean;
  commission_percent: number | null;
}

export type AccessStatus = "none" | "pending" | "active";

export interface FormState {
  ok?: boolean;
  id?: string;
  error?: string;
  message?: string;
}

/** Linha da view client_overview (métricas calculadas no banco). */
export type ClientStatus = "new" | "active" | "at_risk" | "lost";

export interface ClientOverview {
  id: string;
  name: string;
  phone: string;
  email: string | null;
  birth_date: string | null;
  notes: string | null;
  preferences: string | null;
  created_at: string;
  first_visit_at: string | null;
  last_visit_at: string | null;
  visits: number;
  total_spent: number;
  avg_ticket: number;
  status: ClientStatus;
  is_vip: boolean;
}

export type AppointmentStatus = "pending" | "confirmed" | "completed" | "cancelled" | "no_show";
