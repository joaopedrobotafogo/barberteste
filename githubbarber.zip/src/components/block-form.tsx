"use client";

import { useActionState, useEffect, useState } from "react";
import { saveBlock } from "@/app/(app)/agenda/actions";
import type { BarberOpt } from "@/lib/agenda";
import type { FormState } from "@/lib/types";
import { Button, ErrorNote, Input, Select } from "@/components/ui";

export function BlockForm({ defaultDate, defaultBarberId, lockedBarberId, barbers, onDone }: {
  defaultDate: string; defaultBarberId: string | null; lockedBarberId: string | null;
  barbers: BarberOpt[]; onDone: (message: string) => void;
}) {
  const [state, action, pending] = useActionState(saveBlock, {} as FormState);
  const [barberId] = useState(lockedBarberId ?? defaultBarberId ?? barbers[0]?.id ?? "");
  useEffect(() => { if (state.ok) onDone(state.message ?? "Salvo"); }, [state]); // eslint-disable-line react-hooks/exhaustive-deps
  return (
    <form action={action} className="space-y-4">
      <Select label="Barbeiro" name="barber_id" defaultValue={barberId} disabled={!!lockedBarberId}>
        {barbers.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
      </Select>
      {lockedBarberId && <input type="hidden" name="barber_id" value={lockedBarberId} />}
      <Input label="Data" name="date" type="date" defaultValue={defaultDate} required />
      <div className="grid grid-cols-2 gap-3">
        <Input label="Das" name="start" type="time" defaultValue="12:00" required />
        <Input label="Até" name="end" type="time" defaultValue="13:00" required />
      </div>
      <Input label="Motivo (opcional)" name="reason" placeholder="Almoço, consulta, folga…" />
      {state.error && <ErrorNote>{state.error}</ErrorNote>}
      <Button type="submit" loading={pending} className="w-full">Bloquear horário</Button>
    </form>
  );
}
