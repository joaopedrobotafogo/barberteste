/**
 * Estilos compartilhados SEM "use client": podem ser usados por Server Components e Client Components.
 * (Constantes/funções exportadas de um arquivo "use client" não podem ser usadas no servidor.)
 */
export type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";

export const BUTTON_VARIANTS: Record<ButtonVariant, string> = {
  primary: "bg-primary text-primary-foreground shadow-sm hover:bg-primary-hover active:scale-[0.99] disabled:bg-primary/40 disabled:shadow-none",
  secondary: "border border-border bg-card text-foreground shadow-sm hover:bg-muted-bg disabled:text-muted",
  ghost: "text-foreground hover:bg-foreground/5 disabled:text-muted",
  danger: "bg-danger text-white shadow-sm hover:bg-danger/90 disabled:opacity-50",
};

export const FOCUS_RING = "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 focus-visible:ring-offset-2 focus-visible:ring-offset-background";

/** Superfície padrão (cards brancos, cantos arredondados, sombra suave). */
export const CARD = "rounded-2xl border border-border bg-card shadow-card";

/** Classe de botão para <Link> (mesma aparência do Button). */
export const linkButton = (variant: ButtonVariant = "primary", extra = "") =>
  `inline-flex h-11 items-center justify-center gap-2 rounded-xl px-5 text-sm font-medium transition-all duration-150 ${FOCUS_RING} ${BUTTON_VARIANTS[variant]} ${extra}`;
