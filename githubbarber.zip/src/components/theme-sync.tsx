"use client";

import { useEffect } from "react";
import { THEME_COOKIE, THEME_COOKIE_MAX_AGE, type ThemeId } from "@/lib/theme";

/**
 * Garante que a paleta do USUÁRIO LOGADO (user_metadata) esteja aplicada neste navegador,
 * inclusive em um aparelho novo (onde ainda não há cookie). Não renderiza nada.
 */
export function ThemeSync({ theme }: { theme: ThemeId }) {
  useEffect(() => {
    const root = document.documentElement;
    if (root.dataset.theme !== theme) root.dataset.theme = theme;
    document.cookie = `${THEME_COOKIE}=${theme}; path=/; max-age=${THEME_COOKIE_MAX_AGE}; samesite=lax`;
  }, [theme]);
  return null;
}
