import { Suspense } from "react";
import Link from "next/link";
import type { getContext } from "@/lib/auth";
import { dayLong } from "@/lib/agenda";
import { APPT_LABEL, APPT_STYLE, lastVisitLabel } from "@/lib/clients";
import { NEW_CLIENT_DAYS, loadDashboard, type DashboardData } from "@/lib/dashboard";
import { brl, greeting } from "@/lib/format";
import { Avatar, EmptyState, ErrorNote, Icon, PageHeader, SectionHeader, StatCard } from "@/components/ui";
import { CARD, linkButton } from "@/components/ui-styles";
import { StatusBadge, VipBadge } from "@/components/client-badges";
import { ReactivationSection } from "@/components/reactivation";
import { RevenueChartSection, RevenueChartSkeleton } from "@/components/revenue-chart-section";
import { loadReactivationView } from "@/lib/reactivation/view";

type Ctx = Awaited<ReturnType<typeof getContext>>;

const card = CARD;
const pulse = "animate-pulse rounded bg-foreground/[0.06]";

function Upcoming({ d }: { d: DashboardData }) {
  const { upcoming } = d;
  return (
    <section aria-labelledby="proximos" className={`${card} min-w-0 p-5`}>
      <SectionHeader id="proximos" title="Próximos horários" icon="clock" />
      {upcoming.error ? (
        <ErrorNote>Não foi possível carregar os próximos horários. Atualize a página.</ErrorNote>
      ) : upcoming.items.length === 0 ? (
        <EmptyState icon="calendar" title="Nenhum atendimento próximo hoje."
          action={<Link href="/agenda" className={linkButton("primary", "rounded-full px-6")}>Abrir agenda</Link>} />
      ) : (
        <>
          <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border">
            {upcoming.items.map((a) => (
              <li key={a.id} className="flex min-h-[68px] items-center gap-3 px-3 py-3 transition-colors hover:bg-muted-bg/60 sm:px-4">
                <span className="flex h-10 w-14 shrink-0 items-center justify-center rounded-lg bg-primary-light text-[15px] font-semibold tabular-nums text-primary">{a.time}</span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[15px] font-medium">{a.clientName}</span>
                  <span className="block truncate text-sm text-muted">
                    {a.serviceName}{d.isOwner ? ` · ${a.barberName}` : ""}
                  </span>
                </span>
                <span className={`shrink-0 text-xs font-medium ${APPT_STYLE[a.status]}`}>{APPT_LABEL[a.status]}</span>
              </li>
            ))}
          </ul>
          <Link href="/agenda" className="mt-2 flex h-11 items-center justify-between rounded-xl px-1 text-sm font-medium text-primary transition-colors hover:text-primary-hover">
            <span>{upcoming.more > 0 ? `+${upcoming.more} ${upcoming.more === 1 ? "horário" : "horários"} hoje` : "Ver agenda completa"}</span>
            <Icon name="chevron" className="h-4 w-4" />
          </Link>
        </>
      )}
    </section>
  );
}

function Reactivate({ d }: { d: DashboardData }) {
  const { reactivate } = d;
  return (
    <section aria-labelledby="reativar" className={`${card} min-w-0 p-5`}>
      <SectionHeader id="reativar" title="Clientes para reativar" icon="users"
        aside={!reactivate.error && reactivate.total > 0 ? <span className="shrink-0 text-sm text-muted">{reactivate.total} no total</span> : undefined} />
      {reactivate.error ? (
        <ErrorNote>Não foi possível carregar os clientes. Atualize a página.</ErrorNote>
      ) : reactivate.items.length === 0 ? (
        <EmptyState icon="userPlus" title="Você está em dia!" text="Nenhum cliente precisa de reativação agora." />
      ) : (
        <>
          <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border">
            {reactivate.items.map((c) => (
              <li key={c.id} className="flex min-h-[76px] items-center gap-3 px-3 py-3 sm:px-4">
                <Avatar name={c.name} className="h-10 w-10 text-xs" />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="truncate text-[15px] font-medium">{c.name}</span>
                    {c.isVip && <VipBadge />}
                  </span>
                  <span className="block truncate text-sm text-muted">{c.phone}</span>
                  <span className="mt-1 flex items-center gap-2 text-xs text-muted">
                    <StatusBadge status={c.status} />
                    <span className="truncate">{lastVisitLabel(c.lastVisitAt, d.tz)} · {c.visits} {c.visits === 1 ? "atendimento" : "atendimentos"}</span>
                  </span>
                </span>
                <Link href={`/clientes/${c.id}`} aria-label={`Ver cliente ${c.name}`}
                  className="flex h-11 shrink-0 items-center rounded-xl border border-border bg-card px-3.5 text-sm font-medium transition-colors hover:bg-muted-bg">
                  Ver cliente
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-2 flex gap-4 px-1 text-sm font-medium text-primary">
            <Link href="/clientes?filtro=risco" className="flex h-11 items-center hover:text-primary-hover">Ver em risco</Link>
            <Link href="/clientes?filtro=perdidos" className="flex h-11 items-center hover:text-primary-hover">Ver perdidos</Link>
          </div>
        </>
      )}
    </section>
  );
}

export async function Dashboard({ ctx }: { ctx: Ctx }) {
  // Dono: inteligência de reativação (Etapa 11). Barbeiro continua com a lista simples por status do CRM.
  const [d, r] = await Promise.all([loadDashboard(ctx), ctx.profile.role === "owner" ? loadReactivationView(ctx) : Promise.resolve(null)]);
  const first = ctx.profile.full_name.split(" ")[0];
  const pending = d.steps.filter((s) => !s.done);

  const daySummary = d.day.error
    ? "Veja como está sua barbearia hoje."
    : d.day.scheduled === 0
      ? "Nenhum atendimento agendado para hoje."
      : `${d.day.scheduled} ${d.day.scheduled === 1 ? "agendamento" : "agendamentos"} hoje, ${d.day.completed} ${d.day.completed === 1 ? "concluído" : "concluídos"}.`;

  const cardsError = d.day.error || d.newClients.error || !!d.revenue?.error;
  const dash = "—";

  return (
    <>
      <PageHeader eyebrow={ctx.org.name} title={`${greeting(d.tz)}, ${first}`}
        subtitle={`${dayLong(d.today)}. ${daySummary}`} />

      <section aria-label="Indicadores de hoje" className={`grid gap-3 md:gap-4 ${d.isOwner ? "grid-cols-1 min-[480px]:grid-cols-2 xl:grid-cols-4" : "grid-cols-1 min-[480px]:grid-cols-2"}`}>
        {d.revenue && (
          <StatCard icon="wallet" tone="primary" label="Faturamento hoje" value={d.revenue.error ? dash : brl(d.revenue.total)}
            hint={d.revenue.error ? undefined : `${d.revenue.paidCount} ${d.revenue.paidCount === 1 ? "pagamento" : "pagamentos"}`} />
        )}
        <StatCard icon="calendar" tone="success" label="Atendimentos hoje" value={d.day.error ? dash : String(d.day.scheduled)}
          hint={d.day.error ? undefined : `agendados · ${d.day.completed} concluídos`} />
        {d.revenue && (
          <StatCard icon="ticket" tone="accent" label="Ticket médio" value={d.revenue.error ? dash : brl(d.revenue.avgTicket)} hint="por atendimento concluído" />
        )}
        <StatCard icon="userPlus" tone="warning" label="Clientes novos" value={d.newClients.error ? dash : String(d.newClients.count)} hint={`últimos ${NEW_CLIENT_DAYS} dias`} />
      </section>
      {cardsError && <div className="mt-3"><ErrorNote>Alguns indicadores não puderam ser carregados. Atualize a página.</ErrorNote></div>}

      {pending.length > 0 && (
        <section aria-label="Primeiros passos" className="mt-8">
          <h2 className="mb-2 text-sm font-semibold text-muted">Para começar</h2>
          <ul className={`${card} divide-y divide-line overflow-hidden`}>
            {pending.map((s) => (
              <li key={s.href}>
                <Link href={s.href} className="flex min-h-14 items-center justify-between px-4 text-[15px] transition-colors hover:bg-muted-bg/60">
                  {s.label} <Icon name="chevron" className="h-4 w-4 text-muted" />
                </Link>
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* Dono: o gráfico ocupa o espaço sob "Próximos horários" (Reativação ocupa as 2 linhas da direita). */}
      <div className={`mt-6 grid gap-4 lg:grid-cols-2 lg:gap-6 ${d.revenue ? "lg:grid-rows-[auto_1fr]" : ""}`}>
        <Upcoming d={d} />
        {d.revenue ? (
          <div className="min-w-0 lg:row-span-2 [&>section]:h-full">
            {r ? <ReactivationSection view={r} limit={6} showAllLink /> : <Reactivate d={d} />}
          </div>
        ) : (
          r ? <ReactivationSection view={r} limit={6} showAllLink /> : <Reactivate d={d} />
        )}
        {d.revenue && (
          <Suspense fallback={<RevenueChartSkeleton />}>
            <RevenueChartSection ctx={ctx} tz={d.tz} />
          </Suspense>
        )}
      </div>
    </>
  );
}

export function DashboardSkeleton() {
  return (
    <div aria-busy="true" aria-label="Carregando painel">
      <div className="mb-6 space-y-2">
        <div className={`${pulse} h-9 w-56 rounded-lg`} />
        <div className={`${pulse} h-4 w-40`} />
        <div className={`${pulse} h-4 w-52`} />
      </div>
      <div className="grid grid-cols-1 gap-3 min-[480px]:grid-cols-2 md:gap-4 xl:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`${card} p-5`}>
            <div className={`${pulse} h-3 w-20`} />
            <div className={`${pulse} mt-3 h-6 w-24`} />
            <div className={`${pulse} mt-3 h-3 w-28`} />
          </div>
        ))}
      </div>
      <div className="mt-6 grid gap-4 lg:grid-cols-2 lg:gap-6">
        {[0, 1].map((s) => (
          <div key={s} className={`${card} p-5`}>
            <div className={`${pulse} mb-3 h-6 w-44`} />
            <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border">
              {[0, 1, 2].map((i) => (
                <li key={i} className="flex h-[68px] items-center gap-3 px-4">
                  <div className={`${pulse} h-5 w-12`} />
                  <div className="flex-1 space-y-2"><div className={`${pulse} h-4 w-1/2`} /><div className={`${pulse} h-3 w-1/3`} /></div>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
