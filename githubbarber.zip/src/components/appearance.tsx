"use client";

import { useState, useTransition } from "react";
import { saveTheme } from "@/app/(app)/configuracoes/actions";
import { ErrorNote, Icon } from "@/components/ui";
import { THEMES, themeOrDefault, type ThemeId, type ThemeOption } from "@/lib/theme";

/** Mini-preview do layout (sidebar + cards) com as cores da paleta. */
function Preview({ t }: { t: ThemeOption }) {
  return (
    <div className="flex h-20 overflow-hidden rounded-xl border border-border" style={{ background: "#F6F8FB" }} aria-hidden="true">
      <div className="w-1/4 p-1.5" style={{ background: t.swatch.sidebar }}>
        <div className="h-2 w-full rounded-full" style={{ background: t.swatch.primary === "#18181B" ? "#3F3F46" : t.swatch.primary }} />
        <div className="mt-1.5 h-1.5 w-3/4 rounded-full bg-white/25" />
        <div className="mt-1 h-1.5 w-2/3 rounded-full bg-white/25" />
      </div>
      <div className="flex flex-1 flex-col gap-1.5 p-2">
        <div className="h-2 w-1/2 rounded-full" style={{ background: t.swatch.sidebar, opacity: 0.8 }} />
        <div className="flex gap-1.5">
          <div className="h-7 flex-1 rounded-md bg-white shadow-sm" />
          <div className="h-7 flex-1 rounded-md" style={{ background: t.swatch.light }} />
        </div>
        <div className="h-3 w-1/3 rounded-full" style={{ background: t.swatch.primary }} />
      </div>
    </div>
  );
}

export function AppearanceSection({ current, onSaved }: { current: string | undefined; onSaved: (message: string) => void }) {
  const [selected, setSelected] = useState<ThemeId>(themeOrDefault(current));
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const apply = (id: ThemeId) => {
    const root = document.documentElement;
    root.classList.add("theme-anim");
    root.dataset.theme = id;
    window.setTimeout(() => root.classList.remove("theme-anim"), 450);
  };

  const choose = (id: ThemeId) => {
    if (id === selected || pending) return;
    const previous = selected;
    setError(null);
    setSelected(id);
    apply(id); // preview imediato; reverte se salvar falhar
    start(async () => {
      try {
        const res = await saveTheme(id);
        if (res.error) { setError(res.error); setSelected(previous); apply(previous); }
        else onSaved(res.message ?? "Aparência atualizada");
      } catch {
        setError("Não foi possível salvar. Tente novamente.");
        setSelected(previous); apply(previous);
      }
    });
  };

  return (
    <section id="aparencia" className="scroll-mt-24 rounded-2xl border border-border bg-card p-5 shadow-card sm:p-6">
      <h2 className="text-lg font-semibold tracking-tight">Aparência</h2>
      <p className="mt-1 text-sm text-muted">Escolha a aparência da sua barbearia. Muda só as cores; o resto do sistema continua igual.</p>
      <div role="radiogroup" aria-label="Paleta de cores" className="mt-5 grid grid-cols-2 gap-3 md:grid-cols-3">
        {THEMES.map((t) => {
          const on = t.id === selected;
          return (
            <button key={t.id} type="button" role="radio" aria-checked={on} onClick={() => choose(t.id)} disabled={pending && !on}
              className={`relative rounded-2xl border bg-card p-2.5 text-left transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 disabled:opacity-60 ${on ? "border-primary ring-2 ring-primary/25" : "border-border hover:border-input hover:shadow-card"}`}>
              <Preview t={t} />
              <div className="mt-2.5 flex items-center justify-between gap-2 px-0.5">
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{t.name}</p>
                  <p className="truncate text-xs text-muted">{t.description}</p>
                </div>
                <span className="flex shrink-0 gap-1" aria-hidden="true">
                  <span className="h-4 w-4 rounded-full border border-black/10" style={{ background: t.swatch.sidebar }} />
                  <span className="h-4 w-4 rounded-full border border-black/10" style={{ background: t.swatch.primary }} />
                </span>
              </div>
              {on && (
                <span className="absolute right-3.5 top-3.5 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground shadow" aria-label="Selecionada">
                  <Icon name="check" className="h-3.5 w-3.5" strokeWidth={2.6} />
                </span>
              )}
            </button>
          );
        })}
      </div>
      {error && <div className="mt-4"><ErrorNote>{error}</ErrorNote></div>}
    </section>
  );
}
