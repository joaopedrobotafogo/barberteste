"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Button, ErrorNote, Input } from "@/components/ui";
import { requestPasswordReset, signIn, signUp, updatePassword } from "@/app/(auth)/actions";
import type { FormState } from "@/lib/types";

const initial: FormState = {};

function Feedback({ state }: { state: FormState }) {
  if (state.error) return <ErrorNote>{state.error}</ErrorNote>;
  if (state.ok && state.message) return <p role="status" className="rounded-xl bg-ok/10 px-4 py-3 text-sm text-ok">{state.message}</p>;
  return null;
}

export function LoginForm({ linkError }: { linkError?: boolean }) {
  const [state, action, pending] = useActionState(signIn, initial);
  return (
    <form action={action} className="space-y-4">
      {linkError && <ErrorNote>Link inválido ou expirado. Peça um novo.</ErrorNote>}
      <Input label="E-mail" name="email" type="email" autoComplete="email" inputMode="email" required />
      <Input label="Senha" name="password" type="password" autoComplete="current-password" required />
      <Feedback state={state} />
      <Button type="submit" loading={pending} className="w-full">Entrar</Button>
      <div className="flex justify-between pt-2 text-sm">
        <Link href="/esqueci-senha" className="py-2 text-muted underline-offset-4 hover:underline">Esqueci a senha</Link>
        <Link href="/cadastro" className="py-2 font-medium underline-offset-4 hover:underline">Criar conta</Link>
      </div>
    </form>
  );
}

export function SignUpForm() {
  const [state, action, pending] = useActionState(signUp, initial);
  return (
    <form action={action} className="space-y-4">
      <Input label="Nome da barbearia" name="org_name" placeholder="Barbearia Favoni" autoComplete="organization" required />
      <Input label="Seu nome" name="owner_name" placeholder="João" autoComplete="name" required />
      <Input label="Telefone" name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="(21) 99999-9999" />
      <Input label="E-mail" name="email" type="email" autoComplete="email" inputMode="email" required />
      <Input label="Senha" name="password" type="password" autoComplete="new-password" minLength={8} hint="Mínimo de 8 caracteres." required />
      <Feedback state={state} />
      <Button type="submit" loading={pending} className="w-full">Criar minha barbearia</Button>
      <p className="pt-2 text-center text-sm text-muted">
        Já tem conta? <Link href="/login" className="font-medium text-ink underline-offset-4 hover:underline">Entrar</Link>
      </p>
    </form>
  );
}

export function ForgotForm() {
  const [state, action, pending] = useActionState(requestPasswordReset, initial);
  return (
    <form action={action} className="space-y-4">
      <Input label="E-mail" name="email" type="email" autoComplete="email" inputMode="email" required />
      <Feedback state={state} />
      <Button type="submit" loading={pending} className="w-full">Enviar link</Button>
      <p className="pt-2 text-center text-sm"><Link href="/login" className="text-muted underline-offset-4 hover:underline">Voltar ao login</Link></p>
    </form>
  );
}

export function NewPasswordForm() {
  const [state, action, pending] = useActionState(updatePassword, initial);
  return (
    <form action={action} className="space-y-4">
      <Input label="Nova senha" name="password" type="password" autoComplete="new-password" minLength={8} required />
      <Input label="Confirmar senha" name="confirm" type="password" autoComplete="new-password" minLength={8} required />
      <Feedback state={state} />
      <Button type="submit" loading={pending} className="w-full">Salvar senha e entrar</Button>
    </form>
  );
}
