"use client";

import { useActionState, useCallback, useEffect, useState, useTransition } from "react";
import { inviteBarber, saveBarber, toggleBarber } from "@/app/(app)/equipe/actions";
import { Avatar, Button, EmptyState, ErrorNote, Icon, Input, PageHeader, Sheet, Switch, Toast, Toggle, useToast } from "@/components/ui";
import type { AccessStatus, Barber, FormState, Role } from "@/lib/types";

export type TeamMember = Barber & { role: Role | null; access: AccessStatus };

function BarberForm({ member, onDone }: { member: TeamMember | null; onDone: (m: string) => void }) {
  const [state, action, pending] = useActionState(saveBarber, {} as FormState);
  useEffect(() => { if (state.ok) onDone(state.message ?? "Salvo"); }, [state, onDone]);
  const locked = !!member?.profile_id;
  return (
    <form action={action} className="space-y-4">
      {member && <input type="hidden" name="id" value={member.id} />}
      <Input label="Nome" name="name" defaultValue={member?.name} required />
      <Input label="Telefone" name="phone" type="tel" inputMode="tel" defaultValue={member?.phone ?? ""} />
      <Input label="E-mail" name="email" type="email" inputMode="email" defaultValue={member?.email ?? ""} disabled={locked}
        hint={locked ? "Vinculado ao login deste barbeiro." : "Necessário para enviar o convite de acesso."} />
      <Input label="Comissão (%)" name="commission_percent" inputMode="decimal" defaultValue={member?.commission_percent ?? ""} placeholder="40" />
      <Toggle name="is_active" label="Barbeiro ativo" defaultChecked={member?.is_active ?? true} />
      {state.error && <ErrorNote>{state.error}</ErrorNote>}
      <Button type="submit" loading={pending} className="w-full">{member ? "Salvar alterações" : "Adicionar barbeiro"}</Button>
    </form>
  );
}

const ACCESS_LABEL: Record<AccessStatus, string> = { none: "Sem acesso", pending: "Convite pendente", active: "Com acesso" };

export function TeamManager({ members }: { members: TeamMember[] }) {
  const [editing, setEditing] = useState<TeamMember | null>(null);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState<string | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [pending, start] = useTransition();
  const { message, show } = useToast();

  const close = useCallback(() => setOpen(false), []);
  const done = useCallback((m: string) => { setOpen(false); show(m); }, [show]);
  const openNew = () => { setEditing(null); setOpen(true); };

  const run = (id: string, fn: () => Promise<FormState>) => {
    setBusy(id);
    setErrors((e) => ({ ...e, [id]: "" }));
    start(async () => {
      try {
        const r = await fn();
        if (r.error) setErrors((e) => ({ ...e, [id]: r.error ?? "" }));
        else show(r.message ?? "Atualizado");
      } catch (err) {
        console.error("Falha na ação da equipe:", err);
        setErrors((e) => ({ ...e, [id]: "Erro inesperado. Veja o terminal do servidor para detalhes." }));
      } finally {
        setBusy(null);
      }
    });
  };

  return (
    <>
      <PageHeader title="Equipe" subtitle="Barbeiros, comissões e acessos ao sistema."
        action={<Button onClick={openNew} className="h-11 shrink-0 px-4"><Icon name="plus" className="h-4 w-4" /> Adicionar</Button>} />
      {members.length === 0 ? (
        <EmptyState title="Você ainda não possui barbeiros."
          action={<Button onClick={openNew}><Icon name="plus" className="h-4 w-4" /> Adicionar primeiro barbeiro</Button>} />
      ) : (
        <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">
          {members.map((m) => {
            const isOwner = m.role === "owner";
            const canInvite = !isOwner && m.access !== "active";
            return (
              <li key={m.id} className="px-4 py-3.5">
                <div className="flex items-center gap-3">
                  <button onClick={() => { setEditing(m); setOpen(true); }} className="flex min-w-0 flex-1 items-center gap-3 text-left">
                    <Avatar name={m.name} src={m.photo_url} />
                    <span className="min-w-0">
                      <span className={`block truncate text-[15px] font-medium ${m.is_active ? "" : "text-muted"}`}>
                        {m.name}{isOwner && <span className="ml-2 rounded-full bg-warning/10 px-2 py-0.5 text-xs font-medium text-warning">Dono</span>}
                      </span>
                      <span className="block truncate text-sm text-muted">{m.email ?? "Sem e-mail"}</span>
                      <span className="block text-sm text-muted">
                        {m.commission_percent !== null ? `Comissão ${m.commission_percent}%` : "Sem comissão"}
                        {!isOwner && ` · ${ACCESS_LABEL[m.access]}`}{!m.is_active && " · Inativo"}
                      </span>
                    </span>
                  </button>
                  <Switch checked={m.is_active} disabled={pending} label={`${m.name}: ${m.is_active ? "desativar" : "ativar"}`}
                    onChange={(v) => run(m.id, () => toggleBarber(m.id, v))} />
                </div>
                {errors[m.id] && <div className="mt-3 sm:pl-14"><ErrorNote>{errors[m.id]}</ErrorNote></div>}
                {canInvite && (
                  <div className="mt-3 pl-14">
                    {m.email ? (
                      <Button variant="secondary" className="h-11 px-4 text-sm" loading={busy === m.id} onClick={() => run(m.id, () => inviteBarber(m.id))}>
                        <Icon name="mail" className="h-4 w-4" /> {m.access === "pending" ? "Reenviar convite" : "Enviar convite"}
                      </Button>
                    ) : (
                      <p className="text-sm text-muted">Adicione um e-mail para convidar.</p>
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      <Sheet open={open} onClose={close} title={editing ? "Editar barbeiro" : "Novo barbeiro"}>
        <BarberForm key={editing?.id ?? "new"} member={editing} onDone={done} />
      </Sheet>
      <Toast message={message} />
    </>
  );
}
