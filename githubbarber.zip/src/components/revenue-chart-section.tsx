import type { getContext } from "@/lib/auth";
import { loadRevenueBase } from "@/lib/finance";
import { RevenueChart } from "@/components/revenue-chart";
import { CARD } from "@/components/ui-styles";

type Ctx = Awaited<ReturnType<typeof getContext>>;

/**
 * Busca os últimos 30 dias de faturamento com a MESMA função do Financeiro/Relatórios (loadRevenueBase):
 * uma consulta paginada à tabela payments, sem deletados, agrupada por dia no fuso da barbearia.
 * Roda dentro de <Suspense>, então o resto do Início aparece sem esperar o gráfico.
 */
export async function RevenueChartSection({ ctx, tz }: { ctx: Ctx; tz: string }) {
  const base = await loadRevenueBase(ctx, "30d", tz);
  return <RevenueChart days={base.days} error={base.error} truncated={base.truncated} />;
}

export function RevenueChartSkeleton() {
  const pulse = "animate-pulse rounded bg-foreground/[0.06]";
  return (
    <div aria-busy="true" aria-label="Carregando faturamento" className={`${CARD} min-w-0 p-5`}>
      <div className="flex items-start justify-between gap-4">
        <div className="space-y-2.5">
          <div className={`${pulse} h-6 w-52`} />
          <div className={`${pulse} h-8 w-36`} />
          <div className={`${pulse} h-3 w-40`} />
        </div>
        <div className={`${pulse} h-12 w-40 rounded-xl`} />
      </div>
      <div className={`${pulse} mt-4 h-[220px] w-full rounded-xl`} />
    </div>
  );
}
