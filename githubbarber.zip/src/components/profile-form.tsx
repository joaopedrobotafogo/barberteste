"use client";

import { useActionState, useEffect } from "react";
import { saveProfile } from "@/app/(app)/perfil/actions";
import { Button, ErrorNote, Input, Toast, useToast } from "@/components/ui";
import type { FormState } from "@/lib/types";

export function ProfileForm({ name, phone, email }: { name: string; phone: string; email: string }) {
  const [state, action, pending] = useActionState(saveProfile, {} as FormState);
  const { message, show } = useToast();
  useEffect(() => { if (state.ok && state.message) show(state.message); }, [state, show]);
  return (
    <form action={action} className="space-y-4">
      <Input label="Nome" name="full_name" defaultValue={name} required />
      <Input label="Telefone" name="phone" type="tel" inputMode="tel" defaultValue={phone} />
      <Input label="E-mail" value={email} disabled readOnly />
      {state.error && <ErrorNote>{state.error}</ErrorNote>}
      <Button type="submit" loading={pending} className="w-full md:w-auto">Salvar</Button>
      <Toast message={message} />
    </form>
  );
}
