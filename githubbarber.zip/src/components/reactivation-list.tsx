"use client";

import { useState, useTransition } from "react";
import { cancelReactivation, dismissClient, reactivateClient } from "@/app/(app)/reativacao/actions";
import { Avatar, Toast, useToast } from "@/components/ui";

export interface ReactivationRow {
  clientId: string;
  name: string;
  phone: string;
  state: "candidate" | "requested" | "sent" | "responded" | "booked";
  attemptId: string | null;
  daysSince: number | null;
  habitualDays: number | null;
  overdueDays: number | null;
  confidence: "none" | "low" | "medium" | "high";
  visits: number;
}

const STATE_LABEL: Record<Exclude<ReactivationRow["state"], "candidate">, { label: string; style: string }> = {
  requested: { label: "Mensagem pendente", style: "bg-warning/10 text-warning" },
  sent: { label: "Mensagem enviada", style: "bg-foreground/5 text-foreground/70" },
  responded: { label: "Respondeu", style: "bg-primary-light text-primary" },
  booked: { label: "Agendou", style: "bg-success/10 text-success" },
};
const CONF_LABEL = { none: "Sem histórico", low: "Confiança baixa", medium: "Confiança média", high: "Confiança alta" } as const;

const fmt = (n: number | null) => (n === null ? "—" : Number.isInteger(n) ? String(n) : n.toFixed(1).replace(".", ","));
const days = (n: number | null) => (n === null ? "—" : `${fmt(n)} ${n === 1 ? "dia" : "dias"}`);

const btn = "flex h-11 items-center justify-center rounded-xl px-4 text-sm font-medium transition-all duration-150 disabled:cursor-not-allowed disabled:opacity-50";

/** Lista de reativação (dono). Sem lógica de elegibilidade: tudo vem calculado do servidor; o backend revalida a cada ação. */
export function ReactivationList({ rows }: { rows: ReactivationRow[] }) {
  const [pending, start] = useTransition();
  const [busy, setBusy] = useState<string | null>(null);
  const [failure, setFailure] = useState<string | null>(null);
  const { message, show } = useToast();

  const act = (key: string, fn: () => Promise<{ error?: string; message?: string }>) => {
    setFailure(null);
    setBusy(key);
    start(async () => {
      try {
        const res = await fn();
        if (res.error) setFailure(res.error);
        else show(res.message ?? "Pronto");
      } catch {
        setFailure("Não foi possível concluir. Tente novamente.");
      } finally {
        setBusy(null);
      }
    });
  };

  return (
    <>
      {failure && <p role="alert" className="mb-2 rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">{failure}</p>}
      <ul className="divide-y divide-border overflow-hidden rounded-xl border border-border bg-card">
        {rows.map((r) => {
          const st = r.state === "candidate" ? null : STATE_LABEL[r.state];
          const mine = busy !== null && busy.endsWith(r.clientId);
          return (
            <li key={r.clientId} className="px-4 py-4 transition-colors hover:bg-muted-bg/40">
              <div className="flex items-start gap-3">
                <Avatar name={r.name} className="h-11 w-11 shrink-0 text-sm" />
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className="truncate text-[15px] font-medium">{r.name}</span>
                    {st && <span className={`inline-flex h-6 items-center rounded-full px-2.5 text-xs font-medium ${st.style}`}>{st.label}</span>}
                  </div>
                  <p className="truncate text-sm text-muted">{r.phone}</p>
                  <dl className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-muted-bg/70 p-2.5 text-xs">
                    <div className="min-w-0"><dt className="text-muted">Última visita</dt><dd className="mt-0.5 truncate text-[13px] font-medium tabular-nums">{r.daysSince === null ? "—" : `há ${days(r.daysSince)}`}</dd></div>
                    <div className="min-w-0"><dt className="text-muted">Costuma voltar</dt><dd className="mt-0.5 truncate text-[13px] font-medium tabular-nums">{r.habitualDays === null ? "—" : `a cada ~${days(Math.round(r.habitualDays))}`}</dd></div>
                    <div className="min-w-0"><dt className="text-muted">Atraso</dt><dd className="mt-0.5 truncate text-[13px] font-medium tabular-nums">{r.overdueDays === null ? "—" : r.overdueDays > 0 ? days(Math.round(r.overdueDays)) : "no ritmo"}</dd></div>
                  </dl>
                  <p className="mt-1.5 text-xs text-muted">{CONF_LABEL[r.confidence]} · {r.visits} {r.visits === 1 ? "visita" : "visitas"}</p>
                </div>
              </div>

              {r.state === "candidate" && (
                <div className="mt-3 grid grid-cols-2 gap-2 sm:flex sm:justify-end">
                  <button type="button" disabled={pending} onClick={() => act(`dismiss:${r.clientId}`, () => dismissClient(r.clientId))}
                    className={`${btn} border border-border bg-card hover:bg-muted-bg`} aria-label={`Ignorar ${r.name}`}>
                    {mine && busy?.startsWith("dismiss") ? "Ignorando…" : "Ignorar"}
                  </button>
                  <button type="button" disabled={pending} onClick={() => act(`react:${r.clientId}`, () => reactivateClient(r.clientId))}
                    className={`${btn} bg-primary text-primary-foreground shadow-sm hover:bg-primary-hover sm:min-w-32`} aria-label={`Reativar ${r.name}`}>
                    {mine && busy?.startsWith("react") ? "Registrando…" : "Reativar"}
                  </button>
                </div>
              )}
              {r.state === "requested" && r.attemptId && (
                <div className="mt-3 flex sm:justify-end">
                  <button type="button" disabled={pending} onClick={() => act(`cancel:${r.clientId}`, () => cancelReactivation(r.attemptId!))}
                    className={`${btn} w-full border border-border bg-card hover:bg-muted-bg sm:w-auto`} aria-label={`Cancelar pedido de ${r.name}`}>
                    {mine ? "Cancelando…" : "Cancelar pedido"}
                  </button>
                </div>
              )}
            </li>
          );
        })}
      </ul>
      <Toast message={message} />
    </>
  );
}
