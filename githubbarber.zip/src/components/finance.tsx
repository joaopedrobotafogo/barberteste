import Link from "next/link";
import type { getContext } from "@/lib/auth";
import { dayMonth, weekdayShort } from "@/lib/agenda";
import { brl } from "@/lib/format";
import {
  PERIODS, loadFinance, type DayPoint, type FinanceData, type GroupStat, type PeriodKey,
} from "@/lib/finance";
import { EmptyState, ErrorNote } from "@/components/ui";

type Ctx = Awaited<ReturnType<typeof getContext>>;

const card = "rounded-2xl border border-line bg-surface shadow-card";
const pulse = "animate-pulse rounded bg-ink/[0.06]";
const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;

export function periodHref(period: PeriodKey, page?: number) {
  const sp = new URLSearchParams({ periodo: period });
  if (page && page > 1) sp.set("pag", String(page));
  return `/financeiro?${sp.toString()}`;
}

/** Filtro de período: grade 2x2 no mobile (sem rolagem horizontal), 4 colunas no desktop. */
export function PeriodFilter({ active, basePath = "/financeiro" }: { active: PeriodKey; basePath?: string }) {
  return (
    <nav aria-label="Período" className="mb-6 grid grid-cols-2 gap-2 sm:grid-cols-4">
      {PERIODS.map((p) => (
        <Link key={p.key} href={`${basePath}?periodo=${p.key}`} aria-current={active === p.key ? "true" : undefined}
          className={`flex h-11 items-center justify-center rounded-xl border px-3 text-sm font-medium transition-colors ${active === p.key ? "border-primary bg-primary text-primary-foreground" : "border-line bg-surface text-ink/70 hover:text-ink"}`}>
          {p.label}
        </Link>
      ))}
    </nav>
  );
}

export function StatCard({ label, value, hint, className = "" }: { label: string; value: string; hint?: string; className?: string }) {
  return (
    <div className={`${card} min-w-0 p-4 ${className}`}>
      <p className="truncate text-xs font-medium text-muted">{label}</p>
      <p className="mt-1.5 truncate text-[22px] font-bold leading-none tracking-tight tabular-nums sm:text-[26px]">{value}</p>
      {hint && <p className="mt-1.5 truncate text-xs text-muted">{hint}</p>}
    </div>
  );
}

export function SectionTitle({ id, children, aside }: { id: string; children: React.ReactNode; aside?: React.ReactNode }) {
  return (
    <div className="mb-3 flex items-baseline justify-between gap-3">
      <h2 id={id} className="text-lg font-semibold tracking-tight">{children}</h2>
      {aside}
    </div>
  );
}

// ---------------------------------------------------------------- faturamento por dia
function DailyRows({ days, max }: { days: DayPoint[]; max: number }) {
  return (
    <ul className={`${card} divide-y divide-line overflow-hidden`}>
      {days.map((d) => (
        <li key={d.date} className="flex min-h-[52px] items-center gap-3 px-4 py-2">
          <span className="w-14 shrink-0">
            <span className="block text-sm font-medium">{weekdayShort(d.date)}</span>
            <span className="block text-xs text-muted">{dayMonth(d.date)}</span>
          </span>
          <span className="h-2 min-w-0 flex-1 overflow-hidden rounded-full bg-ink/[0.06]" aria-hidden="true">
            <span className="block h-full rounded-full bg-primary/80" style={{ width: max > 0 ? `${(d.revenue / max) * 100}%` : "0%" }} />
          </span>
          <span className={`w-24 shrink-0 text-right text-[15px] font-medium tabular-nums ${d.revenue === 0 ? "text-muted" : ""}`}>{brl(d.revenue)}</span>
        </li>
      ))}
    </ul>
  );
}

function DailyBars({ days, max }: { days: DayPoint[]; max: number }) {
  const best = days.reduce((a, b) => (b.revenue > a.revenue ? b : a), days[0]);
  return (
    <div className={`${card} p-4`}>
      <div className="flex h-36 items-end gap-[3px]" role="img"
        aria-label={`Faturamento por dia, de ${dayMonth(days[0].date)} a ${dayMonth(days[days.length - 1].date)}`}>
        {days.map((d) => (
          <div key={d.date} title={`${dayMonth(d.date)} · ${brl(d.revenue)}`}
            className={`min-w-0 flex-1 rounded-t-[3px] ${d.revenue > 0 ? "bg-primary/80" : "bg-line"}`}
            style={{ height: d.revenue > 0 && max > 0 ? `${Math.max(3, (d.revenue / max) * 100)}%` : "2px" }} />
        ))}
      </div>
      <div className="mt-2 flex justify-between text-xs text-muted">
        <span>{dayMonth(days[0].date)}</span>
        <span>{dayMonth(days[days.length - 1].date)}</span>
      </div>
      {best.revenue > 0 && (
        <p className="mt-3 border-t border-line pt-3 text-sm text-muted">
          Melhor dia: <span className="font-medium text-ink">{weekdayShort(best.date)}, {dayMonth(best.date)}</span> · <span className="font-medium tabular-nums text-ink">{brl(best.revenue)}</span>
        </p>
      )}
    </div>
  );
}

export function DailySection({ days, title = "Faturamento por dia" }: { days: DayPoint[]; title?: string }) {
  if (days.length <= 1) return null; // "Hoje" (ou 1º dia do mês): um gráfico de um ponto não informa nada
  const max = Math.max(0, ...days.map((x) => x.revenue));
  return (
    <section aria-labelledby="por-dia" className="mt-8">
      <SectionTitle id="por-dia">{title}</SectionTitle>
      {days.length <= 7 ? <DailyRows days={days} max={max} /> : <DailyBars days={days} max={max} />}
    </section>
  );
}

// ---------------------------------------------------------------- por serviço / por barbeiro
function GroupList({ id, title, items, total }: { id: string; title: string; items: GroupStat[]; total: number }) {
  const max = Math.max(0, ...items.map((i) => i.revenue));
  return (
    <section aria-labelledby={id} className="min-w-0">
      <SectionTitle id={id}>{title}</SectionTitle>
      <ul className={`${card} divide-y divide-line overflow-hidden`}>
        {items.map((i) => (
          <li key={i.id} className="px-4 py-3">
            <div className="flex items-baseline justify-between gap-3">
              <span className="min-w-0 truncate text-[15px] font-medium">{i.name}</span>
              <span className="shrink-0 text-[15px] font-semibold tabular-nums">{brl(i.revenue)}</span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink/[0.06]" aria-hidden="true">
              <div className="h-full rounded-full bg-primary/70" style={{ width: max > 0 ? `${(i.revenue / max) * 100}%` : "0%" }} />
            </div>
            <p className="mt-1.5 text-xs text-muted">
              {plural(i.count, "atendimento", "atendimentos")}{total > 0 ? ` · ${Math.round((i.revenue / total) * 100)}% do total` : ""}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}

// ---------------------------------------------------------------- transações
function Transactions({ d }: { d: FinanceData }) {
  const { tx } = d;
  const short = (ymd: string) => dayMonth(ymd);
  return (
    <section aria-labelledby="transacoes" className="mt-8">
      <SectionTitle id="transacoes" aside={<span className="shrink-0 text-sm text-muted">{plural(tx.total, "pagamento", "pagamentos")}</span>}>
        Transações
      </SectionTitle>
      {tx.namesError && <div className="mb-3"><ErrorNote>Alguns nomes de clientes não puderam ser carregados.</ErrorNote></div>}
      <ul className={`${card} divide-y divide-line overflow-hidden`}>
        {tx.items.map((t) => (
          <li key={t.id} className="flex min-h-[68px] items-center gap-3 px-4 py-3">
            <span className="w-12 shrink-0 text-sm tabular-nums text-muted">
              <span className="block">{short(t.date)}</span>
              <span className="block text-xs">{t.time}</span>
            </span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-[15px] font-medium">{t.clientName}</span>
              <span className="block truncate text-sm text-muted">{t.serviceName} · {t.barberName}</span>
            </span>
            <span className="shrink-0 text-right">
              <span className="block text-[15px] font-semibold tabular-nums">{brl(t.amount)}</span>
              <span className="block text-xs font-medium text-ok">Pago</span>
            </span>
          </li>
        ))}
      </ul>
      {tx.lastPage > 1 && (
        <nav aria-label="Paginação" className="mt-4 flex items-center justify-between text-sm">
          {tx.page > 1 ? (
            <Link href={periodHref(d.period, tx.page - 1)} className="flex h-11 items-center rounded-xl border border-line bg-surface px-4 font-medium">Anterior</Link>
          ) : <span className="h-11 w-24" />}
          <span className="text-muted">Página {tx.page} de {tx.lastPage}</span>
          {tx.page < tx.lastPage ? (
            <Link href={periodHref(d.period, tx.page + 1)} className="flex h-11 items-center rounded-xl border border-line bg-surface px-4 font-medium">Próxima</Link>
          ) : <span className="h-11 w-24" />}
        </nav>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- conteúdo
export async function FinanceContent({ ctx, period, page }: { ctx: Ctx; period: PeriodKey; page: number }) {
  const d = await loadFinance(ctx, period, page);
  const range = period === "hoje" ? "Hoje" : `${dayMonth(d.startDay)} – ${dayMonth(d.today)}`;

  if (d.error) {
    return (
      <>
        <p className="mb-4 -mt-3 text-[15px] text-muted">{range}</p>
        <ErrorNote>Não foi possível carregar o financeiro. Atualize a página ou tente novamente em instantes.</ErrorNote>
      </>
    );
  }

  return (
    <>
      <p className="mb-4 -mt-3 text-[15px] text-muted">{range}</p>

      <section aria-label="Indicadores do período" className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <StatCard label="Faturamento" value={brl(d.total)} hint="recebido no período" />
        <StatCard label="Atendimentos" value={String(d.count)} hint={d.count === 1 ? "concluído e pago" : "concluídos e pagos"} />
        <StatCard label="Ticket médio" value={brl(d.avgTicket)} hint="por atendimento" />
        <StatCard label="Clientes atendidos" value={String(d.uniqueClients)} hint="clientes únicos" />
      </section>

      {d.truncated && (
        <div className="mt-3"><ErrorNote>O período tem muitos pagamentos e os totais podem estar incompletos. Escolha um período menor.</ErrorNote></div>
      )}

      {d.count === 0 ? (
        <div className="mt-8">
          <EmptyState title="Nenhum atendimento financeiro encontrado neste período."
            text="O faturamento aparece aqui quando um atendimento é marcado como concluído na Agenda."
            action={<Link href="/agenda" className="flex h-12 items-center rounded-xl border border-line bg-surface px-5 text-[15px] font-medium">Abrir agenda</Link>} />
        </div>
      ) : (
        <>
          <DailySection days={d.days} />
          <div className="mt-8 grid gap-8 lg:grid-cols-2 lg:gap-6">
            <GroupList id="por-servico" title="Por serviço" items={d.byService} total={d.total} />
            <GroupList id="por-barbeiro" title="Por barbeiro" items={d.byBarber} total={d.total} />
          </div>
          <Transactions d={d} />
        </>
      )}
    </>
  );
}

export function FinanceSkeleton() {
  return (
    <div aria-busy="true" aria-label="Carregando financeiro">
      <div className={`${pulse} mb-4 -mt-3 h-4 w-32`} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`${card} p-4`}>
            <div className={`${pulse} h-3 w-20`} />
            <div className={`${pulse} mt-3 h-6 w-24`} />
            <div className={`${pulse} mt-3 h-3 w-28`} />
          </div>
        ))}
      </div>
      <div className="mt-8">
        <div className={`${pulse} mb-3 h-6 w-44`} />
        <div className={`${card} h-48`} />
      </div>
      <div className="mt-8 grid gap-8 lg:grid-cols-2 lg:gap-6">
        {[0, 1].map((s) => (
          <div key={s}>
            <div className={`${pulse} mb-3 h-6 w-36`} />
            <ul className={`${card} divide-y divide-line overflow-hidden`}>
              {[0, 1, 2].map((i) => (
                <li key={i} className="space-y-2 px-4 py-3">
                  <div className={`${pulse} h-4 w-1/2`} /><div className={`${pulse} h-2 w-full`} /><div className={`${pulse} h-3 w-1/3`} />
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
