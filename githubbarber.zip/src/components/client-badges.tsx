import { STATUS_LABEL, STATUS_STYLE } from "@/lib/clients";
import type { ClientStatus } from "@/lib/types";

export function StatusBadge({ status }: { status: ClientStatus }) {
  return <span className={`inline-flex h-6 items-center rounded-full px-2.5 text-xs font-medium ${STATUS_STYLE[status]}`}>{STATUS_LABEL[status]}</span>;
}

export function VipBadge() {
  return <span className="inline-flex h-6 items-center rounded-full bg-primary px-2.5 text-xs font-medium text-primary-foreground">VIP</span>;
}
