"use client";

import { useActionState, useCallback, useEffect, useState } from "react";
import { saveClient } from "@/app/(app)/clientes/actions";
import { SORTS } from "@/lib/clients";
import { Button, ErrorNote, Icon, Input, Sheet, Textarea, Toast, useToast } from "@/components/ui";
import type { FormState } from "@/lib/types";

export interface ClientFormValues {
  id: string; name: string; phone: string; email: string | null;
  birth_date: string | null; preferences: string | null; notes: string | null;
}

function ClientForm({ client, onDone }: { client: ClientFormValues | null; onDone: (msg: string) => void }) {
  const [state, action, pending] = useActionState(saveClient, {} as FormState);
  useEffect(() => { if (state.ok) onDone(state.message ?? "Salvo"); }, [state, onDone]);
  return (
    <form action={action} className="space-y-4">
      {client && <input type="hidden" name="id" value={client.id} />}
      <Input label="Nome" name="name" defaultValue={client?.name} autoComplete="off" required />
      <Input label="Telefone" name="phone" type="tel" inputMode="tel" defaultValue={client?.phone} placeholder="(21) 99999-9999" autoComplete="off" required />
      <Input label="E-mail (opcional)" name="email" type="email" inputMode="email" defaultValue={client?.email ?? ""} autoComplete="off" />
      <Input label="Data de nascimento (opcional)" name="birth_date" type="date" defaultValue={client?.birth_date ?? ""} />
      <Textarea label="Preferências" name="preferences" defaultValue={client?.preferences ?? ""} placeholder="Degradê baixo, máquina 2, barba curta" />
      <Textarea label="Observações" name="notes" defaultValue={client?.notes ?? ""} />
      {state.error && <ErrorNote>{state.error}</ErrorNote>}
      <Button type="submit" loading={pending} className="w-full">{client ? "Salvar alterações" : "Adicionar cliente"}</Button>
    </form>
  );
}

export function NewClientButton({ compact }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  const { message, show } = useToast();
  const close = useCallback(() => setOpen(false), []);
  const done = useCallback((m: string) => { setOpen(false); show(m); }, [show]);
  return (
    <>
      <Button onClick={() => setOpen(true)} className={compact ? "h-11 shrink-0 px-4" : ""}>
        <Icon name="plus" className="h-4 w-4" /> {compact ? "Novo" : "Adicionar primeiro cliente"}
      </Button>
      <Sheet open={open} onClose={close} title="Novo cliente"><ClientForm client={null} onDone={done} /></Sheet>
      <Toast message={message} />
    </>
  );
}

export function EditClientButton({ client }: { client: ClientFormValues }) {
  const [open, setOpen] = useState(false);
  const { message, show } = useToast();
  const close = useCallback(() => setOpen(false), []);
  const done = useCallback((m: string) => { setOpen(false); show(m); }, [show]);
  return (
    <>
      <Button variant="secondary" onClick={() => setOpen(true)} className="flex-1 md:flex-none">Editar</Button>
      <Sheet open={open} onClose={close} title="Editar cliente"><ClientForm client={client} onDone={done} /></Sheet>
      <Toast message={message} />
    </>
  );
}

export function SortSelect({ defaultValue }: { defaultValue: string }) {
  return (
    <select name="ordem" defaultValue={defaultValue} aria-label="Ordenar por"
      onChange={(e) => e.currentTarget.form?.requestSubmit()}
      className="h-12 shrink-0 rounded-xl border border-line bg-surface px-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/15">
      {SORTS.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
    </select>
  );
}
