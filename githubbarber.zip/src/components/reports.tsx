import Link from "next/link";
import type { getContext } from "@/lib/auth";
import { dayMonth } from "@/lib/agenda";
import { lastVisitLabel } from "@/lib/clients";
import { brl } from "@/lib/format";
import { loadReports, type ReportsData } from "@/lib/reports";
import type { GroupStat, PeriodKey } from "@/lib/finance";
import { Avatar, EmptyState, ErrorNote } from "@/components/ui";
import { StatusBadge, VipBadge } from "@/components/client-badges";
import { DailySection, SectionTitle, StatCard } from "@/components/finance";

type Ctx = Awaited<ReturnType<typeof getContext>>;

const card = "rounded-2xl border border-line bg-surface shadow-card";
const pulse = "animate-pulse rounded bg-ink/[0.06]";
const plural = (n: number, one: string, many: string) => `${n} ${n === 1 ? one : many}`;
const avg = (g: GroupStat) => Math.round((g.revenue * 100) / g.count) / 100;

// ---------------------------------------------------------------- serviços e equipe
function RankList({ id, title, items, mode }: { id: string; title: string; items: GroupStat[]; mode: "service" | "barber" }) {
  const max = Math.max(0, ...items.map((i) => i.count));
  return (
    <section aria-labelledby={id} className="min-w-0">
      <SectionTitle id={id}>{title}</SectionTitle>
      <ul className={`${card} divide-y divide-line overflow-hidden`}>
        {items.map((i) => (
          <li key={i.id} className="px-4 py-3">
            <div className="flex items-baseline justify-between gap-3">
              <span className="min-w-0 truncate text-[15px] font-medium">{i.name}</span>
              <span className="shrink-0 text-[15px] font-semibold tabular-nums">{brl(i.revenue)}</span>
            </div>
            <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-ink/[0.06]" aria-hidden="true">
              <div className="h-full rounded-full bg-primary/70" style={{ width: max > 0 ? `${(i.count / max) * 100}%` : "0%" }} />
            </div>
            <p className="mt-1.5 text-xs text-muted">
              {plural(i.count, "atendimento", "atendimentos")}{mode === "barber" ? ` · ticket médio ${brl(avg(i))}` : ""}
            </p>
          </li>
        ))}
      </ul>
    </section>
  );
}

// ---------------------------------------------------------------- clientes novos
function NewClients({ r }: { r: ReportsData }) {
  const n = r.newClients;
  const perDay = n.perDay;
  const max = perDay ? Math.max(0, ...perDay.map((p) => p.count)) : 0;
  return (
    <section aria-labelledby="novos" className="mt-8 min-w-0">
      <SectionTitle id="novos">Clientes novos</SectionTitle>
      {n.error ? (
        <ErrorNote>Não foi possível carregar os clientes novos. Atualize a página.</ErrorNote>
      ) : (
        <div className={`${card} p-4`}>
          <p className="flex items-baseline gap-2">
            <span className="text-[28px] font-semibold leading-none tabular-nums tracking-tight">{n.count}</span>
            <span className="text-sm text-muted">{n.count === 1 ? "cliente cadastrado no período" : "clientes cadastrados no período"}</span>
          </p>
          {perDay && perDay.length > 1 && n.count > 0 && (
            <>
              <div className="mt-4 flex h-16 items-end gap-[3px]" role="img"
                aria-label={`Clientes novos por dia, de ${dayMonth(perDay[0].date)} a ${dayMonth(perDay[perDay.length - 1].date)}`}>
                {perDay.map((p) => (
                  <div key={p.date} title={`${dayMonth(p.date)} · ${plural(p.count, "novo", "novos")}`}
                    className={`min-w-0 flex-1 rounded-t-[3px] ${p.count > 0 ? "bg-primary/80" : "bg-line"}`}
                    style={{ height: p.count > 0 && max > 0 ? `${Math.max(8, (p.count / max) * 100)}%` : "2px" }} />
                ))}
              </div>
              <div className="mt-2 flex justify-between text-xs text-muted">
                <span>{dayMonth(perDay[0].date)}</span><span>{dayMonth(perDay[perDay.length - 1].date)}</span>
              </div>
            </>
          )}
          {n.count === 0 && <p className="mt-2 text-sm text-muted">Nenhum cliente novo foi cadastrado neste período.</p>}
        </div>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- clientes que não retornaram
function NotReturned({ r }: { r: ReportsData }) {
  const nr = r.notReturned;
  const total = nr.atRisk + nr.lost;
  return (
    <section aria-labelledby="nao-retornaram" className="mt-8">
      <SectionTitle id="nao-retornaram"
        aside={!nr.error && total > 0 ? <span className="shrink-0 text-sm text-muted">{nr.atRisk} em risco · {nr.lost} perdidos</span> : undefined}>
        Clientes que não retornaram
      </SectionTitle>
      {nr.error ? (
        <ErrorNote>Não foi possível carregar estes clientes. Atualize a página.</ErrorNote>
      ) : nr.items.length === 0 ? (
        <EmptyState title="Você está em dia!" text="Nenhum cliente em risco ou perdido agora." />
      ) : (
        <>
          <ul className={`${card} divide-y divide-line overflow-hidden`}>
            {nr.items.map((c) => (
              <li key={c.id} className="flex min-h-[76px] items-center gap-3 px-4 py-3">
                <Avatar name={c.name} className="h-10 w-10 text-xs" />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center gap-2">
                    <span className="truncate text-[15px] font-medium">{c.name}</span>
                    {c.isVip && <VipBadge />}
                  </span>
                  <span className="mt-1 flex items-center gap-2 text-xs text-muted">
                    <StatusBadge status={c.status} />
                    <span className="truncate">{lastVisitLabel(c.lastVisitAt, r.tz)} · {plural(c.visits, "atendimento", "atendimentos")}</span>
                  </span>
                </span>
                <Link href={`/clientes/${c.id}`} aria-label={`Ver cliente ${c.name}`}
                  className="flex h-11 shrink-0 items-center rounded-xl border border-line bg-surface px-3.5 text-sm font-medium hover:bg-muted-bg">
                  Ver cliente
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-2 flex flex-wrap items-center gap-x-4 px-1 text-sm font-medium text-ink/70">
            <Link href="/clientes?filtro=risco" className="flex h-11 items-center hover:text-ink">Ver em risco</Link>
            <Link href="/clientes?filtro=perdidos" className="flex h-11 items-center hover:text-ink">Ver perdidos</Link>
          </div>
          <p className="px-1 text-xs text-muted">
            {total > nr.items.length ? `Mostrando ${nr.items.length} de ${total}, começando pelos mais frequentes. ` : ""}Situação atual, não depende do período.
          </p>
        </>
      )}
    </section>
  );
}

// ---------------------------------------------------------------- conteúdo
export async function ReportsContent({ ctx, period }: { ctx: Ctx; period: PeriodKey }) {
  const r = await loadReports(ctx, period);
  const rev = r.revenue;
  const range = period === "hoje" ? "Hoje" : `${dayMonth(r.startDay)} – ${dayMonth(r.today)}`;
  const dash = "—";

  return (
    <>
      <p className="mb-4 -mt-3 text-[15px] text-muted">{range}</p>

      <section aria-label="Resumo do período" className="grid grid-cols-2 gap-3 md:grid-cols-3">
        <StatCard className="col-span-2 md:col-span-1" label="Faturamento" value={rev.error ? dash : brl(rev.total)} hint="recebido no período" />
        <StatCard label="Atendimentos" value={rev.error ? dash : String(rev.count)} hint={rev.count === 1 ? "concluído e pago" : "concluídos e pagos"} />
        <StatCard label="Ticket médio" value={rev.error ? dash : brl(rev.avgTicket)} hint="por atendimento" />
        <StatCard label="Clientes novos" value={r.newClients.error ? dash : String(r.newClients.count)} hint="cadastrados no período" />
        <StatCard label="Clientes recorrentes" value={r.recurring.error ? dash : String(r.recurring.count)}
          hint={rev.error ? undefined : `de ${rev.servedClients} ${rev.servedClients === 1 ? "atendido" : "atendidos"}`} />
      </section>
      {(rev.error || r.recurring.error || r.newClients.error) && (
        <div className="mt-3"><ErrorNote>Alguns indicadores não puderam ser carregados. Atualize a página.</ErrorNote></div>
      )}
      {rev.truncated && (
        <div className="mt-3"><ErrorNote>O período tem muitos pagamentos e os totais podem estar incompletos. Escolha um período menor.</ErrorNote></div>
      )}

      {!rev.error && (rev.count === 0 ? (
        <div className="mt-8">
          <EmptyState title="Nenhum dado encontrado para este período."
            text="Faturamento, serviços e desempenho da equipe aparecem quando há atendimentos concluídos."
            action={<Link href="/agenda" className="flex h-12 items-center rounded-xl border border-line bg-surface px-5 text-[15px] font-medium">Abrir agenda</Link>} />
        </div>
      ) : (
        <>
          {rev.days.length > 1 ? (
            <DailySection days={rev.days} title="Evolução do faturamento" />
          ) : (
            <section aria-labelledby="evolucao" className="mt-8">
              <SectionTitle id="evolucao">Evolução do faturamento</SectionTitle>
              <div className="rounded-2xl border border-dashed border-line px-6 py-8 text-center text-sm text-muted">
                Este período tem só um dia. Escolha um período maior para ver a evolução.
              </div>
            </section>
          )}
          <div className="mt-8 grid gap-8 lg:grid-cols-2 lg:gap-6">
            <RankList id="servicos" title="Serviços mais realizados" items={rev.byService} mode="service" />
            <RankList id="equipe" title="Desempenho da equipe" items={rev.byBarber} mode="barber" />
          </div>
        </>
      ))}

      <NewClients r={r} />
      <NotReturned r={r} />
    </>
  );
}

export function ReportsSkeleton() {
  return (
    <div aria-busy="true" aria-label="Carregando relatórios">
      <div className={`${pulse} mb-4 -mt-3 h-4 w-32`} />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3">
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} className={`${card} p-4 ${i === 0 ? "col-span-2 md:col-span-1" : ""}`}>
            <div className={`${pulse} h-3 w-20`} />
            <div className={`${pulse} mt-3 h-6 w-24`} />
            <div className={`${pulse} mt-3 h-3 w-28`} />
          </div>
        ))}
      </div>
      <div className="mt-8">
        <div className={`${pulse} mb-3 h-6 w-48`} />
        <div className={`${card} h-48`} />
      </div>
      <div className="mt-8 grid gap-8 lg:grid-cols-2 lg:gap-6">
        {[0, 1].map((s) => (
          <div key={s}>
            <div className={`${pulse} mb-3 h-6 w-40`} />
            <ul className={`${card} divide-y divide-line overflow-hidden`}>
              {[0, 1, 2].map((i) => (
                <li key={i} className="space-y-2 px-4 py-3">
                  <div className={`${pulse} h-4 w-1/2`} /><div className={`${pulse} h-2 w-full`} /><div className={`${pulse} h-3 w-1/3`} />
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
