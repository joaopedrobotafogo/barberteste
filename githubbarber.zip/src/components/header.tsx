import Link from "next/link";
import { Avatar, Icon } from "@/components/ui";
import { Logo } from "@/components/brand/logo";

export function Header({ orgName, userName, role }: { orgName: string; userName: string; role: "owner" | "barber" }) {
  return (
    <header className="sticky top-0 z-30 px-3 pt-3 md:px-6 md:pt-3" style={{ paddingTop: "max(0.75rem, env(safe-area-inset-top))" }}>
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 rounded-2xl border border-border bg-card/95 px-4 shadow-card backdrop-blur md:h-16 md:px-6">
        <div className="flex min-w-0 items-center gap-3">
          <span className="md:hidden"><Logo variant="mark" height={26} /></span>
          <p className="truncate text-[17px] font-semibold tracking-tight">{orgName}</p>
        </div>
        <div className="flex items-center gap-1">
          {/* Notificações: ainda sem fonte de dados (etapas futuras) */}
          <button disabled aria-label="Notificações (em breve)" className="flex h-11 w-11 items-center justify-center rounded-full text-muted/60">
            <Icon name="bell" />
          </button>
          <details className="group relative">
            <summary className="flex h-11 w-11 cursor-pointer items-center justify-center rounded-full transition-colors hover:bg-foreground/5" aria-label="Menu do perfil">
              <Avatar name={userName} className="h-9 w-9 text-xs" />
            </summary>
            <div className="animate-fade-up absolute right-0 top-12 z-40 w-60 rounded-2xl border border-border bg-card p-1.5 shadow-pop">
              <div className="px-3 py-2.5">
                <p className="truncate text-sm font-semibold">{userName}</p>
                <p className="text-xs text-muted">{role === "owner" ? "Proprietário" : "Barbeiro"}</p>
              </div>
              <Link href="/perfil" className="flex h-11 items-center gap-2 rounded-xl px-3 text-sm transition-colors hover:bg-foreground/5">
                <Icon name="user" className="h-4 w-4" /> Meu perfil
              </Link>
              <form action="/auth/signout" method="post">
                <button className="flex h-11 w-full items-center gap-2 rounded-xl px-3 text-sm transition-colors hover:bg-foreground/5">
                  <Icon name="logout" className="h-4 w-4" /> Sair
                </button>
              </form>
            </div>
          </details>
        </div>
      </div>
    </header>
  );
}
