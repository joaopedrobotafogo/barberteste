"use client";

import { useActionState, useCallback, useEffect, useState, useTransition } from "react";
import { saveService, toggleService } from "@/app/(app)/servicos/actions";
import { Button, EmptyState, ErrorNote, Icon, Input, PageHeader, Sheet, Switch, Textarea, Toast, Toggle, useToast } from "@/components/ui";
import { brl } from "@/lib/format";
import type { FormState, Service } from "@/lib/types";

function ServiceForm({ service, onDone }: { service: Service | null; onDone: (msg: string) => void }) {
  const [state, action, pending] = useActionState(saveService, {} as FormState);
  useEffect(() => { if (state.ok) onDone(state.message ?? "Salvo"); }, [state, onDone]);
  return (
    <form action={action} className="space-y-4">
      {service && <input type="hidden" name="id" value={service.id} />}
      <Input label="Nome" name="name" defaultValue={service?.name} placeholder="Corte" required />
      <Textarea label="Descrição (opcional)" name="description" defaultValue={service?.description ?? ""} />
      <div className="grid grid-cols-2 gap-3">
        <Input label="Preço (R$)" name="price" inputMode="decimal" defaultValue={service ? service.price.toFixed(2).replace(".", ",") : ""} placeholder="35,00" required />
        <Input label="Duração (min)" name="duration_minutes" type="number" inputMode="numeric" min={5} max={480} step={5} defaultValue={service?.duration_minutes ?? 30} required />
      </div>
      <Toggle name="is_active" label="Serviço ativo" defaultChecked={service?.is_active ?? true} />
      {state.error && <ErrorNote>{state.error}</ErrorNote>}
      <Button type="submit" loading={pending} className="w-full">{service ? "Salvar alterações" : "Criar serviço"}</Button>
    </form>
  );
}

export function ServiceManager({ services }: { services: Service[] }) {
  const [editing, setEditing] = useState<Service | null>(null);
  const [open, setOpen] = useState(false);
  const [pending, start] = useTransition();
  const { message, show } = useToast();

  const openNew = () => { setEditing(null); setOpen(true); };
  const close = useCallback(() => setOpen(false), []);
  const done = useCallback((m: string) => { setOpen(false); show(m); }, [show]);

  const toggle = (s: Service, v: boolean) =>
    start(async () => {
      const r = await toggleService(s.id, v);
      show(r.error ?? r.message ?? "Atualizado");
    });

  const addButton = (
    <Button onClick={openNew} className="h-11 shrink-0 px-4"><Icon name="plus" className="h-4 w-4" /> Novo</Button>
  );

  return (
    <>
      <PageHeader title="Serviços" subtitle="O que sua barbearia oferece, com preço e duração." action={addButton} />
      {services.length === 0 ? (
        <EmptyState title="Você ainda não possui serviços."
          text="Cadastre corte, barba e o que mais você faz. A duração define o tamanho do horário na agenda."
          action={<Button onClick={openNew}><Icon name="plus" className="h-4 w-4" /> Adicionar primeiro serviço</Button>} />
      ) : (
        <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">
          {services.map((s) => (
            <li key={s.id} className="flex items-center gap-1 pr-2">
              <button onClick={() => { setEditing(s); setOpen(true); }} className="min-w-0 flex-1 px-4 py-3.5 text-left">
                <span className={`block truncate text-[15px] font-medium ${s.is_active ? "" : "text-muted"}`}>{s.name}</span>
                <span className="mt-0.5 block text-sm text-muted">{s.duration_minutes} min · {brl(s.price)}{!s.is_active && " · Inativo"}</span>
                {s.description && <span className="mt-1 line-clamp-1 block text-sm text-muted/80">{s.description}</span>}
              </button>
              <Switch checked={s.is_active} disabled={pending} label={`${s.name}: ${s.is_active ? "desativar" : "ativar"}`} onChange={(v) => toggle(s, v)} />
            </li>
          ))}
        </ul>
      )}
      <Sheet open={open} onClose={close} title={editing ? "Editar serviço" : "Novo serviço"}>
        <ServiceForm key={editing?.id ?? "new"} service={editing} onDone={done} />
      </Sheet>
      <Toast message={message} />
    </>
  );
}
