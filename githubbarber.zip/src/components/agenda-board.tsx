"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useState, useTransition } from "react";
import { deleteBlock, setAppointmentStatus } from "@/app/(app)/agenda/actions";
import {
  dayLong, dayNum, isActiveStatus, weekdayShort,
  type AgendaAppt, type AgendaBlock, type BarberOpt, type ClientPick, type ServiceOpt,
} from "@/lib/agenda";
import { APPT_LABEL, APPT_STYLE } from "@/lib/clients";
import { brl } from "@/lib/format";
import type { AppointmentStatus, FormState } from "@/lib/types";
import { AppointmentForm } from "@/components/appointment-form";
import { BlockForm } from "@/components/block-form";
import { Button, EmptyState, ErrorNote, Icon, Sheet, Toast, useToast } from "@/components/ui";

export interface AgendaBoardProps {
  view: "dia" | "semana";
  date: string;
  today: string;
  days: string[];
  appts: AgendaAppt[];
  blocks: AgendaBlock[];
  barbers: BarberOpt[];
  services: ServiceOpt[];
  isOwner: boolean;
  lockedBarberId: string | null;
  filterBarberId: string | null;
  allowOverbooking: boolean;
  prefillClient: ClientPick | null;
  cleanHref: string;
}

const ACCENT: Record<AppointmentStatus, string> = {
  pending: "bg-warning", confirmed: "bg-primary", completed: "bg-ok", cancelled: "bg-line", no_show: "bg-danger",
};

type Entry = { kind: "appt"; at: string; a: AgendaAppt } | { kind: "block"; at: string; b: AgendaBlock };

export function AgendaBoard(p: AgendaBoardProps) {
  const router = useRouter();
  const { message, show } = useToast();
  const [form, setForm] = useState<{ appt: AgendaAppt | null; prefill: ClientPick | null } | null>(
    p.prefillClient ? { appt: null, prefill: p.prefillClient } : null
  );
  const [blockOpen, setBlockOpen] = useState(false);
  const [selected, setSelected] = useState<AgendaAppt | null>(null);
  const [selectedBlock, setSelectedBlock] = useState<AgendaBlock | null>(null);

  const showBarber = !p.filterBarberId && p.barbers.length > 1;
  const defaultBarberId = p.lockedBarberId ?? p.filterBarberId;
  const formDate = p.view === "dia" ? p.date : p.days.includes(p.today) ? p.today : p.days[0];

  const closeForm = useCallback(() => {
    if (form?.prefill) router.replace(p.cleanHref); // remove ?cliente= da URL
    setForm(null);
  }, [form, router, p.cleanHref]);
  const doneForm = useCallback((m: string) => { closeForm(); show(m); }, [closeForm, show]);
  const closeBlock = useCallback(() => setBlockOpen(false), []);
  const doneBlock = useCallback((m: string) => { setBlockOpen(false); show(m); }, [show]);

  const entriesFor = (d: string): Entry[] => [
    ...p.appts.filter((a) => a.date === d).map((a): Entry => ({ kind: "appt", at: a.time, a })),
    ...p.blocks.filter((b) => b.date === d).map((b): Entry => ({ kind: "block", at: b.time, b })),
  ].sort((x, y) => x.at.localeCompare(y.at));

  const live = p.appts.filter((a) => isActiveStatus(a.status) || a.status === "pending");
  const expected = live.reduce((s, a) => s + a.price, 0);
  const newAppointment = () => setForm({ appt: null, prefill: null });

  const renderEntry = (e: Entry) =>
    e.kind === "appt" ? (
      <li key={e.a.id}>
        <button onClick={() => setSelected(e.a)} className="flex w-full items-stretch gap-3 px-4 py-3.5 text-left transition-colors hover:bg-muted-bg/70">
          <span className="w-12 shrink-0">
            <span className="block text-[15px] font-semibold tabular-nums">{e.a.time}</span>
            <span className="block text-xs tabular-nums text-muted">{e.a.endTime}</span>
          </span>
          <span className={`w-1 shrink-0 rounded-full ${ACCENT[e.a.status]}`} aria-hidden="true" />
          <span className={`min-w-0 flex-1 ${e.a.status === "cancelled" || e.a.status === "no_show" ? "opacity-60" : ""}`}>
            <span className={`block truncate text-[15px] font-medium ${e.a.status === "cancelled" ? "line-through" : ""}`}>{e.a.clientName}</span>
            <span className="block truncate text-sm text-muted">{e.a.serviceName}{showBarber && ` · ${e.a.barberName}`}{e.a.isOverbook && " · Encaixe"}</span>
          </span>
          <span className="shrink-0 text-right">
            <span className="block text-[15px] font-medium">{brl(e.a.price)}</span>
            <span className={`block text-xs font-medium ${APPT_STYLE[e.a.status]}`}>{APPT_LABEL[e.a.status]}</span>
          </span>
        </button>
      </li>
    ) : (
      <li key={e.b.id}>
        <button onClick={() => setSelectedBlock(e.b)} className="flex w-full items-stretch gap-3 bg-muted-bg/70 px-4 py-3.5 text-left transition-colors hover:bg-muted-bg">
          <span className="w-12 shrink-0">
            <span className="block text-[15px] font-semibold tabular-nums text-muted">{e.b.time}</span>
            <span className="block text-xs tabular-nums text-muted">{e.b.endTime}</span>
          </span>
          <span className="w-1 shrink-0 rounded-full bg-muted/40" aria-hidden="true" />
          <span className="min-w-0 flex-1">
            <span className="block text-[15px] font-medium text-muted">Bloqueado</span>
            <span className="block truncate text-sm text-muted">{e.b.reason ?? "Sem motivo"}{showBarber && ` · ${e.b.barberName}`}</span>
          </span>
        </button>
      </li>
    );

  return (
    <>
      <div className="mb-5 flex gap-3">
        <Button onClick={newAppointment} className="flex-1 md:flex-none"><Icon name="plus" className="h-4 w-4" /> Novo agendamento</Button>
        <Button variant="secondary" onClick={() => setBlockOpen(true)}>Bloquear</Button>
      </div>

      {p.view === "dia" ? (
        <>
          {p.appts.length > 0 && (
            <p className="mb-3 text-sm text-muted">
              {live.length} {live.length === 1 ? "agendamento" : "agendamentos"} · {brl(expected)} previstos
            </p>
          )}
          {entriesFor(p.date).length === 0 ? (
            <EmptyState icon="calendar" title={p.date === p.today ? "Nenhum agendamento para hoje." : "Nenhum agendamento neste dia."}
              action={<Button onClick={newAppointment}><Icon name="plus" className="h-4 w-4" /> Novo agendamento</Button>} />
          ) : (
            <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">{entriesFor(p.date).map(renderEntry)}</ul>
          )}
        </>
      ) : (
        <div className="space-y-5">
          {p.days.map((d) => {
            const list = entriesFor(d);
            return (
              <section key={d} aria-label={dayLong(d)}>
                <Link href={`${p.cleanHref.split("?")[0]}?${new URLSearchParams({ view: "dia", date: d, ...(p.filterBarberId && !p.lockedBarberId ? { barber: p.filterBarberId } : {}) })}`}
                  className="mb-2 flex min-h-11 items-center justify-between">
                  <span className={`text-sm font-semibold ${d === p.today ? "text-primary" : "text-muted"}`}>
                    {weekdayShort(d)} {dayNum(d)}{d === p.today && " · Hoje"}
                  </span>
                  <span className="text-xs text-muted">{list.length === 0 ? "Livre" : `${list.length} ${list.length === 1 ? "item" : "itens"}`}</span>
                </Link>
                {list.length > 0 && <ul className="divide-y divide-line overflow-hidden rounded-2xl border border-line bg-surface shadow-card">{list.map(renderEntry)}</ul>}
              </section>
            );
          })}
        </div>
      )}

      <Sheet open={form !== null} onClose={closeForm} title={form?.appt ? "Editar / remarcar" : "Novo agendamento"}>
        {form && (
          <AppointmentForm key={form.appt?.id ?? "new"} appt={form.appt} prefill={form.prefill} defaultDate={formDate}
            defaultBarberId={defaultBarberId} lockedBarberId={p.lockedBarberId} barbers={p.barbers} services={p.services}
            allowOverbooking={p.allowOverbooking} onDone={doneForm} />
        )}
      </Sheet>

      <Sheet open={blockOpen} onClose={closeBlock} title="Bloquear horário">
        {blockOpen && <BlockForm defaultDate={formDate} defaultBarberId={defaultBarberId} lockedBarberId={p.lockedBarberId} barbers={p.barbers} onDone={doneBlock} />}
      </Sheet>

      <Sheet open={selected !== null} onClose={() => setSelected(null)} title="Agendamento">
        {selected && (
          <Detail a={selected} canAct={p.isOwner || selected.barberId === p.lockedBarberId}
            onEdit={() => { setForm({ appt: selected, prefill: null }); setSelected(null); }}
            onDone={(m) => { setSelected(null); show(m); }} />
        )}
      </Sheet>

      <Sheet open={selectedBlock !== null} onClose={() => setSelectedBlock(null)} title="Horário bloqueado">
        {selectedBlock && (
          <BlockDetail b={selectedBlock} canAct={p.isOwner || selectedBlock.barberId === p.lockedBarberId}
            onDone={(m) => { setSelectedBlock(null); show(m); }} />
        )}
      </Sheet>

      <Toast message={message} />
    </>
  );
}

function useAction(onDone: (m: string) => void) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const run = (fn: () => Promise<FormState>) => {
    setError(null);
    start(async () => {
      try {
        const r = await fn();
        if (r.error) setError(r.error); else onDone(r.message ?? "Atualizado");
      } catch (e) {
        console.error(e);
        setError("Erro inesperado. Tente novamente.");
      }
    });
  };
  return { pending, error, run };
}

function Detail({ a, canAct, onEdit, onDone }: { a: AgendaAppt; canAct: boolean; onEdit: () => void; onDone: (m: string) => void }) {
  const { pending, error, run } = useAction(onDone);
  const [confirmCancel, setConfirmCancel] = useState(false);
  const set = (s: AppointmentStatus) => run(() => setAppointmentStatus(a.id, s));
  const open = a.status === "pending" || a.status === "confirmed";

  return (
    <div>
      <dl className="mb-5 divide-y divide-line overflow-hidden rounded-2xl border border-border bg-card text-[15px]">
        <Row label="Cliente"><Link href={`/clientes/${a.clientId}`} className="font-medium underline-offset-4 hover:underline">{a.clientName}</Link><span className="block text-sm text-muted">{a.clientPhone}</span></Row>
        <Row label="Serviço">{a.serviceName}</Row>
        <Row label="Barbeiro">{a.barberName}</Row>
        <Row label="Quando">{dayLong(a.date)}<span className="block text-sm text-muted">{a.time} – {a.endTime}{a.isOverbook && " · Encaixe"}</span></Row>
        <Row label="Valor">{brl(a.price)}</Row>
        <Row label="Status"><span className={`font-medium ${APPT_STYLE[a.status]}`}>{APPT_LABEL[a.status]}</span></Row>
        {a.notes && <Row label="Observações"><span className="whitespace-pre-line">{a.notes}</span></Row>}
      </dl>

      {error && <div className="mb-3"><ErrorNote>{error}</ErrorNote></div>}

      {!canAct ? (
        <p className="text-sm text-muted">Este agendamento é de outro barbeiro. Só o dono ou o próprio barbeiro pode alterá-lo.</p>
      ) : confirmCancel ? (
        <div className="space-y-2">
          <p className="text-sm text-muted">Cancelar este agendamento? O horário volta a ficar livre.</p>
          <Button variant="danger" className="w-full" loading={pending} onClick={() => set("cancelled")}>Sim, cancelar agendamento</Button>
          <Button variant="ghost" className="w-full" onClick={() => setConfirmCancel(false)}>Voltar</Button>
        </div>
      ) : (
        <div className="space-y-2">
          {a.status === "pending" && <Button className="w-full" loading={pending} onClick={() => set("confirmed")}>Confirmar</Button>}
          {open && <Button className="w-full" variant={a.status === "pending" ? "secondary" : "primary"} loading={pending} onClick={() => set("completed")}>Concluir atendimento</Button>}
          <Button variant="secondary" className="w-full" onClick={onEdit}>Editar / remarcar</Button>
          {open && <Button variant="secondary" className="w-full" loading={pending} onClick={() => set("no_show")}>Marcar no-show</Button>}
          {!open && <Button variant="secondary" className="w-full" loading={pending} onClick={() => set("confirmed")}>Reabrir (confirmado)</Button>}
          {a.status !== "cancelled" && <Button variant="ghost" className="w-full text-danger" onClick={() => setConfirmCancel(true)}>Cancelar agendamento</Button>}
        </div>
      )}
    </div>
  );
}

function BlockDetail({ b, canAct, onDone }: { b: AgendaBlock; canAct: boolean; onDone: (m: string) => void }) {
  const { pending, error, run } = useAction(onDone);
  return (
    <div>
      <dl className="mb-5 divide-y divide-line overflow-hidden rounded-2xl border border-border bg-card text-[15px]">
        <Row label="Barbeiro">{b.barberName}</Row>
        <Row label="Quando">{dayLong(b.date)}<span className="block text-sm text-muted">{b.time} – {b.endTime}</span></Row>
        <Row label="Motivo">{b.reason ?? "—"}</Row>
      </dl>
      {error && <div className="mb-3"><ErrorNote>{error}</ErrorNote></div>}
      {canAct
        ? <Button variant="secondary" className="w-full" loading={pending} onClick={() => run(() => deleteBlock(b.id))}>Remover bloqueio</Button>
        : <p className="text-sm text-muted">Só o dono ou o próprio barbeiro pode remover este bloqueio.</p>}
    </div>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="flex gap-4 px-4 py-3">
      <dt className="w-24 shrink-0 text-sm text-muted">{label}</dt>
      <dd className="min-w-0 flex-1">{children}</dd>
    </div>
  );
}
