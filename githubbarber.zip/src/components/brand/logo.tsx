/**
 * Logo oficial (assets em /public/brand). Nunca recriada com texto.
 * - variant "full": símbolo + "BarberFlow"; "mark": só o símbolo.
 * - tone "dark": versão para fundo escuro; "light": para fundo claro.
 */
const SIZE = {
  full: { w: 1268, h: 235 },
  mark: { w: 273, h: 235 },
} as const;

export function Logo({
  variant = "full",
  tone = "light",
  height = 32,
  className = "",
}: {
  variant?: "full" | "mark";
  tone?: "light" | "dark";
  height?: number;
  className?: string;
}) {
  const { w, h } = SIZE[variant];
  const src = `/brand/barberflow-${variant}${tone === "dark" ? "-dark" : ""}.png`;

  return (
    <img
      src={src}
      alt="BarberFlow"
      width={w}
      height={h}
      loading="eager"
      style={{ height, width: "auto" }}
      className={`select-none ${className}`}
    />
  );
}
