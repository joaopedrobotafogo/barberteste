"use client";

import { useEffect, useId, useMemo, useRef, useState, type KeyboardEvent, type PointerEvent } from "react";
import { dayLong, dayMonth, dayNum, weekdayShort } from "@/lib/agenda";
import { brl } from "@/lib/format";
import type { DayPoint } from "@/lib/finance";
import { EmptyState, ErrorNote, Icon } from "@/components/ui";
import { CARD } from "@/components/ui-styles";

/**
 * "Evolução do faturamento" (Início, só dono).
 * Recebe os dias já calculados no servidor por loadRevenueBase (mesma fonte do Financeiro: tabela payments,
 * sem deletados, dias agrupados no fuso da barbearia, dias sem pagamento = 0). Os 30 dias vêm numa única
 * consulta; "7 dias" são os 7 últimos dos mesmos 30, então trocar o período não gera nova consulta.
 * Gráfico em SVG próprio (o projeto não tem biblioteca de gráficos; nenhuma dependência nova).
 * Cores: só tokens do tema (primary, border, muted-foreground, card) => acompanha as 6 paletas.
 */

const RANGES = [7, 30] as const;
type Range = (typeof RANGES)[number];

// ------------------------------------------------------------------ helpers puros
const toCents = (n: number) => Math.round(n * 100);

/** Passo "bonito" (1, 2, 2,5, 5 × 10^k) para dividir o eixo Y em 4 faixas. */
export function niceStep(max: number, intervals = 4): number {
  if (!(max > 0)) return 1;
  const raw = max / intervals;
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * pow >= raw) return m * pow;
  return 10 * pow;
}

/** Curva suave que nunca passa dos pontos (interpolação monotônica): sem "ondas" abaixo de R$ 0. */
export function smoothPath(pts: { x: number; y: number }[]): string {
  const n = pts.length;
  if (n === 0) return "";
  const f = (v: number) => Number(v.toFixed(2));
  if (n === 1) return `M${f(pts[0].x)},${f(pts[0].y)}`;
  const dx: number[] = [], m: number[] = [], t: number[] = new Array(n).fill(0);
  for (let i = 0; i < n - 1; i++) { dx[i] = pts[i + 1].x - pts[i].x; m[i] = (pts[i + 1].y - pts[i].y) / dx[i]; }
  t[0] = m[0]; t[n - 1] = m[n - 2];
  for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (m[i - 1] + m[i]) / 2;
  for (let i = 0; i < n - 1; i++) {
    if (m[i] === 0) { t[i] = 0; t[i + 1] = 0; continue; }
    const a = t[i] / m[i], b = t[i + 1] / m[i], s = a * a + b * b;
    if (s > 9) { const k = 3 / Math.sqrt(s); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; }
  }
  let d = `M${f(pts[0].x)},${f(pts[0].y)}`;
  for (let i = 0; i < n - 1; i++) {
    const h = dx[i] / 3, p = pts[i], q = pts[i + 1];
    d += ` C${f(p.x + h)},${f(p.y + t[i] * h)} ${f(q.x - h)},${f(q.y - t[i + 1] * h)} ${f(q.x)},${f(q.y)}`;
  }
  return d;
}

const tickLabel = (v: number) =>
  v >= 1000 ? `R$ ${(v / 1000).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} mil` : `R$ ${v.toLocaleString("pt-BR", { maximumFractionDigits: 1 })}`;

// ------------------------------------------------------------------ gráfico
function AreaChart({ days, range }: { days: DayPoint[]; range: Range }) {
  const gid = useId().replace(/[^a-zA-Z0-9_-]/g, "");
  const boxRef = useRef<HTMLDivElement>(null);
  const [size, setSize] = useState({ w: 0, h: 0 });
  const [active, setActive] = useState<number | null>(null);

  useEffect(() => {
    const el = boxRef.current;
    if (!el) return;
    const ro = new ResizeObserver(([e]) => setSize({ w: Math.floor(e.contentRect.width), h: Math.floor(e.contentRect.height) }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const n = days.length;
  const narrow = size.w < 420;
  const pad = { top: 14, right: 16, bottom: 28, left: narrow ? 50 : 58 };
  const innerW = Math.max(1, size.w - pad.left - pad.right);
  const innerH = Math.max(1, size.h - pad.top - pad.bottom);

  const geo = useMemo(() => {
    const max = Math.max(0, ...days.map((d) => d.revenue));
    const step = niceStep(max);
    const yMax = step * 4;
    const x = (i: number) => pad.left + (n === 1 ? innerW / 2 : (i * innerW) / (n - 1));
    const y = (v: number) => pad.top + innerH * (1 - v / yMax);
    const pts = days.map((d, i) => ({ x: x(i), y: y(d.revenue) }));
    const line = smoothPath(pts);
    const base = pad.top + innerH;
    const area = pts.length > 1 ? `${line} L${pts[n - 1].x.toFixed(2)},${base} L${pts[0].x.toFixed(2)},${base} Z` : "";
    const ticks = [0, 1, 2, 3, 4].map((k) => ({ v: step * k, y: y(step * k) }));
    return { pts, line, area, ticks, base };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [days, n, innerW, innerH, pad.left, pad.top]);

  // rótulos do eixo X: ancorados no dia mais recente, com espaço mínimo entre eles
  const perLabel = Math.max(1, Math.ceil(n / Math.max(1, Math.floor(innerW / 62))));
  const showLabel = (i: number) => (n - 1 - i) % perLabel === 0;
  const xLabel = (date: string) => (range === 7 ? `${weekdayShort(date)} ${dayNum(date)}` : dayMonth(date));

  const pick = (e: PointerEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const rel = (e.clientX - rect.left - pad.left) / innerW;
    setActive(Math.min(n - 1, Math.max(0, Math.round(rel * (n - 1)))));
  };
  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "ArrowLeft") { e.preventDefault(); setActive((a) => Math.max(0, (a ?? n) - 1)); }
    else if (e.key === "ArrowRight") { e.preventDefault(); setActive((a) => Math.min(n - 1, (a ?? -1) + 1)); }
    else if (e.key === "Home") { e.preventDefault(); setActive(0); }
    else if (e.key === "End") { e.preventDefault(); setActive(n - 1); }
    else if (e.key === "Escape") setActive(null);
  };

  const cur = active !== null && active < n ? days[active] : null;
  const curPt = cur && active !== null ? geo.pts[active] : null;
  const tipLeft = curPt ? Math.min(Math.max(curPt.x, 108), Math.max(108, size.w - 108)) : 0;
  const tipTop = curPt ? Math.max(0, curPt.y - 74) : 0;

  return (
    <div ref={boxRef} role="group" tabIndex={0} aria-label="Gráfico de faturamento por dia. Use as setas para ver cada dia."
      onPointerMove={pick} onPointerDown={pick}
      onPointerLeave={(e) => { if (e.pointerType === "mouse") setActive(null); }}
      onBlur={() => setActive(null)} onKeyDown={onKey}
      style={{ touchAction: "pan-y" }}
      className="relative min-h-[220px] w-full flex-1 rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 lg:max-h-[400px]">
      {size.w > 0 && size.h > 0 && (
        <svg width={size.w} height={size.h} className="absolute inset-0 overflow-visible" aria-hidden="true">
          <defs>
            <linearGradient id={`g${gid}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" style={{ stopColor: "rgb(var(--primary))", stopOpacity: 0.28 }} />
              <stop offset="100%" style={{ stopColor: "rgb(var(--primary))", stopOpacity: 0 }} />
            </linearGradient>
          </defs>

          {geo.ticks.map((t) => (
            <g key={t.v}>
              <line x1={pad.left} x2={size.w - pad.right} y1={t.y} y2={t.y} className="stroke-border" strokeWidth={1} strokeDasharray={t.v === 0 ? undefined : "3 4"} />
              <text x={pad.left - 8} y={t.y + 4} textAnchor="end" fontSize={11} className="fill-muted-foreground tabular-nums">{tickLabel(t.v)}</text>
            </g>
          ))}

          {days.map((d, i) => showLabel(i) && (
            <text key={d.date} x={geo.pts[i].x} y={size.h - 6} fontSize={11} className="fill-muted-foreground"
              textAnchor={i === n - 1 ? "end" : i === 0 ? "start" : "middle"}>{xLabel(d.date)}</text>
          ))}

          {geo.area && <path d={geo.area} fill={`url(#g${gid})`} />}
          <path d={geo.line} fill="none" className="stroke-primary" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" />

          {n <= 8 && geo.pts.map((p, i) => (
            <circle key={days[i].date} cx={p.x} cy={p.y} r={3.5} className="fill-card stroke-primary" strokeWidth={2} />
          ))}

          {curPt && (
            <g>
              <line x1={curPt.x} x2={curPt.x} y1={pad.top} y2={geo.base} className="stroke-primary" strokeOpacity={0.35} strokeWidth={1} strokeDasharray="4 4" />
              <circle cx={curPt.x} cy={curPt.y} r={9} className="fill-primary" fillOpacity={0.15} />
              <circle cx={curPt.x} cy={curPt.y} r={5} className="fill-card stroke-primary" strokeWidth={2.5} />
            </g>
          )}
        </svg>
      )}

      {cur && curPt && (
        <div className="pointer-events-none absolute z-10 w-52 -translate-x-1/2 rounded-xl border border-border bg-card px-3 py-2 shadow-pop"
          style={{ left: tipLeft, top: tipTop }}>
          <p className="whitespace-nowrap text-xs text-muted">{dayLong(cur.date)}</p>
          <p className="mt-0.5 text-[15px] font-semibold tabular-nums">{brl(cur.revenue)}</p>
        </div>
      )}
      <span className="sr-only" aria-live="polite">{cur ? `${dayLong(cur.date)}: ${brl(cur.revenue)}` : ""}</span>
    </div>
  );
}

// ------------------------------------------------------------------ card
export function RevenueChart({ days, error, truncated }: { days: DayPoint[]; error: boolean; truncated: boolean }) {
  const [range, setRange] = useState<Range>(30);
  const visible = useMemo(() => days.slice(-range), [days, range]);
  const totalCents = useMemo(() => visible.reduce((s, d) => s + toCents(d.revenue), 0), [visible]);
  const hasData = visible.some((d) => d.revenue > 0);

  return (
    <section aria-labelledby="evolucao" className={`${CARD} flex min-w-0 flex-col p-5`}>
      <div className="flex flex-wrap items-start justify-between gap-x-4 gap-y-3">
        <div className="min-w-0">
          <h2 id="evolucao" className="flex items-center gap-2.5 text-lg font-semibold tracking-tight">
            <Icon name="chart" className="h-5 w-5 text-primary" /> Evolução do faturamento
          </h2>
          {!error && (
            <>
              <p className="mt-3 text-[28px] font-bold leading-none tracking-tight tabular-nums">{brl(totalCents / 100)}</p>
              <p className="mt-1.5 text-xs text-muted">Faturado nos últimos {range} dias</p>
            </>
          )}
        </div>
        <div role="group" aria-label="Período do gráfico" className="inline-flex shrink-0 rounded-xl bg-muted-bg p-1">
          {RANGES.map((r) => (
            <button key={r} type="button" aria-pressed={range === r} onClick={() => setRange(r)}
              className={`h-10 min-w-[72px] rounded-lg px-3 text-sm font-medium transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 ${range === r ? "bg-card text-primary shadow-sm" : "text-muted hover:text-foreground"}`}>
              {r} dias
            </button>
          ))}
        </div>
      </div>

      <div className="mt-4 flex flex-1 flex-col">
        {error ? (
          <ErrorNote>Não foi possível carregar o faturamento. Atualize a página.</ErrorNote>
        ) : !hasData ? (
          <EmptyState icon="chart" title="Ainda não há faturamento registrado neste período." />
        ) : (
          <AreaChart days={visible} range={range} />
        )}
      </div>
      {!error && truncated && (
        <p className="mt-3 text-xs text-muted">Há muitos pagamentos no período; os valores mais antigos podem estar incompletos.</p>
      )}
    </section>
  );
}
