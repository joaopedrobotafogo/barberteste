"use client";

import { useCallback, useEffect, useRef, useState, type ButtonHTMLAttributes, type InputHTMLAttributes, type ReactNode } from "react";
import type { IconName } from "@/lib/nav";
import { initials } from "@/lib/format";
import { BUTTON_VARIANTS, CARD, FOCUS_RING, type ButtonVariant } from "@/components/ui-styles";

/* ============================================================ Ícones (um único estilo: traço 1.7, cantos redondos) */
const PATHS: Record<IconName, string> = {
  home: "M3 11l9-8 9 8M5 10v10h14V10M10 20v-6h4v6",
  calendar: "M7 3v4M17 3v4M4 9h16M5 5h14a1 1 0 011 1v14a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1zM8 13h.01M12 13h.01M16 13h.01M8 17h.01M12 17h.01",
  user: "M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0",
  scissors: "M6 9a3 3 0 100-6 3 3 0 000 6zM6 21a3 3 0 100-6 3 3 0 000 6zM20 4L8.1 15.9M14.5 14.5L20 20M8.1 8.1L12 12",
  users: "M16 20v-1a4 4 0 00-4-4H7a4 4 0 00-4 4v1M9.5 11a3.5 3.5 0 100-7 3.5 3.5 0 000 7zM21 20v-1a4 4 0 00-3-3.9M16 4.1a3.5 3.5 0 010 6.8",
  wallet: "M3 7a2 2 0 012-2h13v4M3 7v10a2 2 0 002 2h15a1 1 0 001-1v-3M3 7h16a2 2 0 012 2v3h-4a2 2 0 100 4h4",
  chart: "M4 20V10M10 20V4M16 20v-7M22 20H2",
  settings: "M4 6h10M18 6h2M4 12h4M12 12h8M4 18h12M20 18h0M14 4v4M8 10v4M16 16v4",
  search: "M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.3-4.3",
  more: "M5 12h.01M12 12h.01M19 12h.01",
  bell: "M6 8a6 6 0 1112 0c0 7 3 8 3 8H3s3-1 3-8M10.3 21a1.9 1.9 0 003.4 0",
  plus: "M12 5v14M5 12h14",
  logout: "M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9",
  mail: "M4 5h16a1 1 0 011 1v12a1 1 0 01-1 1H4a1 1 0 01-1-1V6a1 1 0 011-1zM3 7l9 6 9-6",
  chevron: "M9 6l6 6-6 6",
  check: "M5 12l5 5L20 7",
  clock: "M12 21a9 9 0 100-18 9 9 0 000 18zM12 7v5l3 2",
  userPlus: "M10 12a4 4 0 100-8 4 4 0 000 8zM2 21a8 8 0 0116 0M19 8v6M16 11h6",
  ticket: "M3 9a2 2 0 002-2h14a2 2 0 002 2v0a2 2 0 000 6v0a2 2 0 00-2 2H5a2 2 0 00-2-2v0a2 2 0 000-6zM14 7v10",
  palette: "M12 3a9 9 0 100 18c1.4 0 2-.9 2-1.8 0-1.2-1-1.6-1-2.7 0-.9.7-1.5 1.6-1.5H17a4 4 0 004-4c0-4.4-4-8-9-8zM7.5 11h.01M10 7.5h.01M14.5 7.5h.01",
  refresh: "M20 11a8 8 0 00-14.9-3M4 4v4h4M4 13a8 8 0 0014.9 3M20 20v-4h-4",
  alert: "M12 9v4M12 17h.01M10.3 3.9L2.4 18a2 2 0 001.7 3h15.8a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z",
  send: "M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z",
};

export function Icon({ name, className = "h-5 w-5", strokeWidth = 1.7 }: { name: IconName; className?: string; strokeWidth?: number }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={name === "more" ? 3 : strokeWidth}
      strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d={PATHS[name]} />
    </svg>
  );
}

/** Círculo com ícone (usado em cards de indicador e estados vazios). */
const TONES = {
  primary: "bg-primary-light text-primary",
  success: "bg-success/10 text-success",
  warning: "bg-warning/10 text-warning",
  accent: "bg-[rgb(124_58_237/0.10)] text-[rgb(109_40_217)]",
  neutral: "bg-muted-bg text-muted",
} as const;
export type Tone = keyof typeof TONES;

export function IconCircle({ name, tone = "primary", className = "h-11 w-11", iconClass = "h-5 w-5" }:
  { name: IconName; tone?: Tone; className?: string; iconClass?: string }) {
  return (
    <span className={`flex shrink-0 items-center justify-center rounded-full ${TONES[tone]} ${className}`} aria-hidden="true">
      <Icon name={name} className={iconClass} />
    </span>
  );
}

/* ============================================================ Botão */
export function Button({ variant = "primary", loading, className = "", children, disabled, ...rest }:
  ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant; loading?: boolean }) {
  return (
    <button {...rest} disabled={disabled || loading}
      className={`inline-flex h-12 items-center justify-center gap-2 rounded-xl px-5 text-[15px] font-medium transition-all duration-150 disabled:cursor-not-allowed ${FOCUS_RING} ${BUTTON_VARIANTS[variant]} ${className}`}>
      {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden="true" />}
      {children}
    </button>
  );
}

/* ============================================================ Campos */
const FIELD = "w-full rounded-xl border bg-card text-base outline-none transition-[border-color,box-shadow] placeholder:text-muted/70 focus:border-primary focus:ring-2 focus:ring-primary/15 disabled:bg-muted-bg disabled:text-muted";

export function Input({ label, hint, error, className = "", ...rest }:
  InputHTMLAttributes<HTMLInputElement> & { label: string; hint?: string; error?: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-foreground/80">{label}</span>
      <input {...rest} className={`${FIELD} h-12 px-4 ${error ? "border-danger" : "border-input"} ${className}`} />
      {error ? <span className="mt-1 block text-sm text-danger">{error}</span>
        : hint ? <span className="mt-1 block text-sm text-muted">{hint}</span> : null}
    </label>
  );
}

export function Textarea({ label, ...rest }: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-foreground/80">{label}</span>
      <textarea {...rest} rows={3} className={`${FIELD} border-input px-4 py-3`} />
    </label>
  );
}

export function Select({ label, className = "", children, ...rest }:
  React.SelectHTMLAttributes<HTMLSelectElement> & { label: string }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-medium text-foreground/80">{label}</span>
      <select {...rest} className={`${FIELD} h-12 border-input px-3 ${className}`}>{children}</select>
    </label>
  );
}

/** Interruptor para formulários (checkbox nativo => envia "on" quando marcado). */
export function Toggle({ name, label, defaultChecked }: { name: string; label: string; defaultChecked?: boolean }) {
  return (
    <label className="flex min-h-12 cursor-pointer items-center justify-between rounded-xl border border-input bg-card px-4">
      <span className="text-[15px]">{label}</span>
      <span className="relative inline-flex">
        <input type="checkbox" name={name} defaultChecked={defaultChecked} className="peer sr-only" />
        <span className="h-7 w-12 rounded-full bg-input transition-colors peer-checked:bg-primary peer-focus-visible:ring-2 peer-focus-visible:ring-ring/40" />
        <span className="absolute left-0.5 top-0.5 h-6 w-6 rounded-full bg-white shadow transition-transform peer-checked:translate-x-5" />
      </span>
    </label>
  );
}

/** Interruptor controlado, para ações diretas em listas. */
export function Switch({ checked, onChange, disabled, label }: { checked: boolean; onChange: (v: boolean) => void; disabled?: boolean; label: string }) {
  return (
    <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled}
      onClick={(e) => { e.stopPropagation(); onChange(!checked); }}
      className="relative inline-flex h-11 w-14 shrink-0 items-center justify-center disabled:opacity-50">
      <span className={`h-7 w-12 rounded-full transition-colors ${checked ? "bg-primary" : "bg-input"}`} />
      <span className={`absolute left-1.5 top-1/2 h-6 w-6 -translate-y-1/2 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-5" : ""}`} />
    </button>
  );
}

/* ============================================================ Modal / Sheet */
export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => { document.removeEventListener("keydown", onKey); document.body.style.overflow = ""; };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end md:items-center md:justify-center" role="dialog" aria-modal="true" aria-label={title}>
      <button aria-label="Fechar" className="animate-fade absolute inset-0 bg-foreground/45 backdrop-blur-[2px]" onClick={onClose} />
      <div className="pb-safe animate-sheet relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl bg-card px-5 pt-5 shadow-pop md:max-w-md md:rounded-3xl md:pb-5">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-xl font-semibold tracking-tight">{title}</h2>
          <button onClick={onClose} aria-label="Fechar" className="-mr-2 flex h-11 w-11 items-center justify-center rounded-full text-muted transition-colors hover:bg-foreground/5">
            <Icon name="plus" className="h-5 w-5 rotate-45" />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}

/* ============================================================ Toast */
export function useToast() {
  const [message, setMessage] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>(undefined);
  const show = useCallback((m: string) => {
    setMessage(m);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => setMessage(null), 3200);
  }, []);
  useEffect(() => () => clearTimeout(timer.current), []);
  return { message, show };
}

export function Toast({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <div role="status" className="animate-fade-up fixed inset-x-4 bottom-24 z-[60] mx-auto flex max-w-sm items-center gap-2 rounded-xl bg-sidebar px-4 py-3 text-sm text-white shadow-pop md:bottom-8">
      <Icon name="check" className="h-4 w-4 shrink-0" /> {message}
    </div>
  );
}

/* ============================================================ Blocos de página */
export function Avatar({ name, src, className = "h-11 w-11 text-sm" }: { name: string; src?: string | null; className?: string }) {
  // eslint-disable-next-line @next/next/no-img-element
  if (src) return <img src={src} alt="" className={`${className} shrink-0 rounded-full object-cover`} />;
  return (
    <span className={`${className} flex shrink-0 items-center justify-center rounded-full bg-primary-light font-semibold text-primary`} aria-hidden="true">
      {initials(name)}
    </span>
  );
}

export function Card({ className = "", children }: { className?: string; children: ReactNode }) {
  return <div className={`${CARD} ${className}`}>{children}</div>;
}

type BadgeTone = "neutral" | "primary" | "success" | "warning" | "danger";
const BADGE: Record<BadgeTone, string> = {
  neutral: "bg-foreground/5 text-foreground/70",
  primary: "bg-primary-light text-primary",
  success: "bg-success/10 text-success",
  warning: "bg-warning/10 text-warning",
  danger: "bg-danger/10 text-danger",
};
export function Badge({ tone = "neutral", children, className = "" }: { tone?: BadgeTone; children: ReactNode; className?: string }) {
  return <span className={`inline-flex h-6 items-center rounded-full px-2.5 text-xs font-medium ${BADGE[tone]} ${className}`}>{children}</span>;
}

export function StatCard({ label, value, hint, icon, tone = "primary" }:
  { label: string; value: string; hint?: string; icon: IconName; tone?: Tone }) {
  return (
    <div className={`${CARD} flex min-w-0 items-start gap-3 p-4 sm:gap-4 sm:p-5`}>
      <IconCircle name={icon} tone={tone} className="h-10 w-10 sm:h-12 sm:w-12" iconClass="h-5 w-5 sm:h-[22px] sm:w-[22px]" />
      <div className="min-w-0">
        <p className="truncate text-[13px] font-medium text-muted">{label}</p>
        <p className="mt-1 truncate text-[22px] font-bold leading-none tracking-tight tabular-nums sm:text-[28px]">{value}</p>
        {hint && <p className="mt-1.5 truncate text-xs text-muted">{hint}</p>}
      </div>
    </div>
  );
}

export function SectionHeader({ id, title, icon, aside }: { id?: string; title: string; icon?: IconName; aside?: ReactNode }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <h2 id={id} className="flex items-center gap-2.5 text-lg font-semibold tracking-tight">
        {icon && <Icon name={icon} className="h-5 w-5 text-primary" />}
        {title}
      </h2>
      {aside}
    </div>
  );
}

export function PageHeader({ title, subtitle, eyebrow, action }: { title: string; subtitle?: string; eyebrow?: string; action?: ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4 md:mb-8">
      <div className="min-w-0">
        {eyebrow && <p className="mb-1 text-sm font-medium text-primary">{eyebrow}</p>}
        <h1 className="text-[28px] font-bold leading-tight tracking-tight md:text-[32px]">{title}</h1>
        {subtitle && <p className="mt-1 text-[15px] text-muted">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ title, text, action, icon }: { title: string; text?: string; action?: ReactNode; icon?: IconName }) {
  return (
    <div className="rounded-2xl border border-dashed border-input bg-muted-bg/50 px-6 py-10 text-center">
      {icon && <div className="mb-3 flex justify-center"><IconCircle name={icon} tone="primary" className="h-12 w-12" iconClass="h-6 w-6" /></div>}
      <p className="text-base font-medium">{title}</p>
      {text && <p className="mx-auto mt-1 max-w-xs text-sm text-muted">{text}</p>}
      {action && <div className="mt-5 flex justify-center">{action}</div>}
    </div>
  );
}

export function ErrorNote({ children }: { children: ReactNode }) {
  return <p role="alert" className="rounded-xl bg-danger/10 px-4 py-3 text-sm text-danger">{children}</p>;
}

export function ErrorState({ title = "Algo deu errado", text, action }: { title?: string; text?: string; action?: ReactNode }) {
  return (
    <div role="alert" className="rounded-2xl border border-danger/20 bg-danger/5 px-6 py-8 text-center">
      <div className="mb-3 flex justify-center"><span className="flex h-12 w-12 items-center justify-center rounded-full bg-danger/10 text-danger"><Icon name="alert" className="h-6 w-6" /></span></div>
      <p className="text-base font-medium">{title}</p>
      {text && <p className="mx-auto mt-1 max-w-sm text-sm text-muted">{text}</p>}
      {action && <div className="mt-4 flex justify-center">{action}</div>}
    </div>
  );
}

export function LoadingState({ label = "Carregando…" }: { label?: string }) {
  return (
    <div role="status" aria-live="polite" className="flex items-center justify-center gap-3 py-12 text-sm text-muted">
      <span className="h-5 w-5 animate-spin rounded-full border-2 border-primary border-t-transparent" aria-hidden="true" /> {label}
    </div>
  );
}
