"use client";

import { useState, useTransition, type FormEvent, type ReactNode } from "react";
import { saveAgenda, saveBusinessName, saveClientRules, saveHours, saveReactivation } from "@/app/(app)/configuracoes/actions";
import { Button, ErrorNote, Icon, Input, Select, Switch, Toast, useToast } from "@/components/ui";
import { AppearanceSection } from "@/components/appearance";
import {
  DAYS, INTERVAL_OPTIONS, NOTICE_OPTIONS, TIMEZONES, minutesLabel,
  type AgendaForm, type BusinessSettings, type ClientRulesForm, type DayKey, type HoursForm,
} from "@/lib/settings";
import type { ReactivationSettings } from "@/lib/reactivation/settings";
import type { FormState } from "@/lib/types";

/**
 * Estado controlado (e não <form action>): o React 19 limpa o formulário depois de cada ação,
 * o que apagaria o que o dono digitou quando a validação do servidor devolve erro.
 */
function useSave<T>(action: (v: T) => Promise<FormState>, onSaved: (message: string) => void) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const save = (value: T) => {
    setError(null);
    start(async () => {
      try {
        const res = await action(value);
        if (res.error) setError(res.error);
        else onSaved(res.message ?? "Configurações salvas");
      } catch {
        setError("Não foi possível salvar. Tente novamente.");
      }
    });
  };
  return { pending, error, save };
}

function Section({ id, title, hint, pending, error, onSubmit, children }: {
  id: string; title: string; hint?: string; pending: boolean; error: string | null; onSubmit: () => void; children: ReactNode;
}) {
  const submit = (e: FormEvent) => { e.preventDefault(); onSubmit(); };
  return (
    <form id={id} onSubmit={submit} className="scroll-mt-24 rounded-2xl border border-border bg-card p-5 shadow-card sm:p-6">
      <h2 className="text-lg font-semibold tracking-tight">{title}</h2>
      {hint && <p className="mt-1 text-sm text-muted">{hint}</p>}
      <div className="mt-5 space-y-4">{children}</div>
      {error && <div className="mt-4"><ErrorNote>{error}</ErrorNote></div>}
      <Button type="submit" loading={pending} className="mt-5 w-full md:w-auto">Salvar</Button>
    </form>
  );
}

/** Mantém no seletor um valor já gravado que não está na lista padrão. */
const withCurrent = (options: number[], current: number) =>
  options.includes(current) ? options : [...options, current].sort((a, b) => a - b);

type Done = (message: string) => void;

// ---------------------------------------------------------------- 1. Barbearia
function BusinessSection({ name: initial, onSaved }: { name: string; onSaved: Done }) {
  const [name, setName] = useState(initial);
  const { pending, error, save } = useSave<string>(saveBusinessName, onSaved);
  return (
    <Section id="barbearia" title="Barbearia" pending={pending} error={error} onSubmit={() => save(name)}>
      <Input label="Nome da barbearia" value={name} onChange={(e) => setName(e.target.value)} maxLength={100} required />
    </Section>
  );
}

// ---------------------------------------------------------------- 2. Horário de funcionamento
interface DayState { enabled: boolean; open: string; close: string }

function HoursSection({ settings, onSaved }: { settings: BusinessSettings; onSaved: Done }) {
  const [timezone, setTimezone] = useState(settings.timezone);
  const [days, setDays] = useState<Record<DayKey, DayState>>(() => {
    const init = {} as Record<DayKey, DayState>;
    for (const { key } of DAYS) {
      const h = settings.opening_hours[key];
      init[key] = { enabled: h !== null, open: h?.open ?? "09:00", close: h?.close ?? "19:00" };
    }
    return init;
  });
  const { pending, error, save } = useSave<HoursForm>(saveHours, onSaved);
  const patch = (key: DayKey, p: Partial<DayState>) => setDays((d) => ({ ...d, [key]: { ...d[key], ...p } }));

  const submit = () => {
    const hours = {} as HoursForm["hours"];
    for (const { key } of DAYS) hours[key] = days[key].enabled ? { open: days[key].open, close: days[key].close } : null;
    save({ timezone, hours });
  };

  const zones = TIMEZONES.some((t) => t.value === timezone) ? TIMEZONES : [...TIMEZONES, { value: timezone, label: timezone }];

  return (
    <Section id="horario" title="Horário de funcionamento" pending={pending} error={error} onSubmit={submit}
      hint="A agenda só oferece horários dentro do expediente. Agendamentos já marcados não mudam.">
      <ul className="divide-y divide-line">
        {DAYS.map(({ key, label }) => {
          const d = days[key];
          return (
            <li key={key} className="py-3 first:pt-0 last:pb-0">
              <div className="flex items-center justify-between">
                <span className="text-[15px] font-medium">{label}</span>
                <div className="flex items-center">
                  <span className="text-sm text-muted">{d.enabled ? "Aberto" : "Fechado"}</span>
                  <Switch checked={d.enabled} onChange={(v) => patch(key, { enabled: v })} label={`${label}: aberto`} />
                </div>
              </div>
              {d.enabled && (
                <div className="mt-2 grid grid-cols-2 gap-3">
                  <Input label="Abre" type="time" value={d.open} required aria-label={`${label}: abertura`}
                    onChange={(e) => patch(key, { open: e.target.value })} />
                  <Input label="Fecha" type="time" value={d.close} required aria-label={`${label}: fechamento`}
                    onChange={(e) => patch(key, { close: e.target.value })} />
                </div>
              )}
            </li>
          );
        })}
      </ul>
      <Select label="Fuso horário" value={timezone} onChange={(e) => setTimezone(e.target.value)}>
        {zones.map((z) => <option key={z.value} value={z.value}>{z.label}</option>)}
      </Select>
      <p className="-mt-2 text-sm text-muted">Usado na agenda, no início, no financeiro e nos relatórios. Altere só se a barbearia estiver em outra região.</p>
    </Section>
  );
}

// ---------------------------------------------------------------- 3. Agenda
function AgendaSection({ settings, onSaved }: { settings: BusinessSettings; onSaved: Done }) {
  const [slot, setSlot] = useState(settings.slot_interval_minutes);
  const [notice, setNotice] = useState(settings.min_notice_minutes);
  const [overbook, setOverbook] = useState(settings.allow_overbooking);
  const { pending, error, save } = useSave<AgendaForm>(saveAgenda, onSaved);
  return (
    <Section id="agenda" title="Agenda" pending={pending} error={error}
      onSubmit={() => save({ slotInterval: slot, minNotice: notice, allowOverbooking: overbook })}>
      <Select label="Intervalo entre horários" value={slot} onChange={(e) => setSlot(Number(e.target.value))}>
        {withCurrent(INTERVAL_OPTIONS, slot).map((n) => <option key={n} value={n}>{n} minutos</option>)}
      </Select>
      <Select label="Antecedência mínima para agendar" value={notice} onChange={(e) => setNotice(Number(e.target.value))}>
        {withCurrent(NOTICE_OPTIONS, notice).map((n) => <option key={n} value={n}>{minutesLabel(n)}</option>)}
      </Select>
      <div className="flex min-h-14 items-center justify-between gap-3 rounded-xl border border-input bg-card py-1 pl-4 pr-1">
        <div className="min-w-0">
          <p className="text-[15px]">Permitir encaixes</p>
          <p className="text-sm text-muted">Deixa agendar por cima de outro horário.</p>
        </div>
        <Switch checked={overbook} onChange={setOverbook} label="Permitir encaixes" />
      </div>
    </Section>
  );
}

// ---------------------------------------------------------------- 4. Clientes
function ClientRulesSection({ settings, onSaved }: { settings: BusinessSettings; onSaved: Done }) {
  const [form, setForm] = useState<ClientRulesForm>({
    riskDays: String(settings.risk_after_days),
    lostDays: String(settings.lost_after_days),
    vipVisits: String(settings.vip_min_visits),
    vipSpent: settings.vip_min_spent.toFixed(2).replace(".", ","),
  });
  const { pending, error, save } = useSave<ClientRulesForm>(saveClientRules, onSaved);
  const set = (k: keyof ClientRulesForm) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: e.target.value }));
  return (
    <Section id="clientes" title="Clientes" pending={pending} error={error} onSubmit={() => save(form)}
      hint="Valem para todos os clientes assim que você salvar. O status é calculado na hora, só com atendimentos concluídos.">
      <div className="grid grid-cols-2 gap-3">
        <Input label="Em risco após (dias)" type="number" inputMode="numeric" min={1} max={3650} value={form.riskDays} onChange={set("riskDays")} required />
        <Input label="Perdido após (dias)" type="number" inputMode="numeric" min={1} max={3650} value={form.lostDays} onChange={set("lostDays")} required />
      </div>
      <p className="-mt-2 text-sm text-muted">Dias sem voltar desde o último atendimento concluído.</p>
      <div className="grid grid-cols-2 gap-3">
        <Input label="VIP: visitas" type="number" inputMode="numeric" min={1} max={1000} value={form.vipVisits} onChange={set("vipVisits")} required />
        <Input label="VIP: gasto (R$)" inputMode="decimal" value={form.vipSpent} onChange={set("vipSpent")} placeholder="500,00" required />
      </div>
      <p className="-mt-2 text-sm text-muted">O cliente é VIP ao atingir um dos dois valores.</p>
    </Section>
  );
}

// ---------------------------------------------------------------- 5. Reativação (Etapa 11)
const num = (v: number) => String(v);

function ReactivationSection({ settings, onSaved }: { settings: ReactivationSettings; onSaved: Done }) {
  const [f, setF] = useState({
    mode: settings.mode, marginPercent: num(settings.marginPercent), minVisits: num(settings.minVisits),
    windowStart: settings.windowStart, windowEnd: settings.windowEnd, dailyLimit: num(settings.dailyLimit),
    minDaysBetweenAttempts: num(settings.minDaysBetweenAttempts), maxAttempts: num(settings.maxAttempts),
    blockFutureAppointment: settings.blockFutureAppointment, attributionDays: num(settings.attributionDays),
  });
  const { pending, error, save } = useSave<typeof f>(saveReactivation, onSaved);
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF((s) => ({ ...s, [k]: e.target.value }));
  return (
    <Section id="reativacao" title="Reativação de clientes" pending={pending} error={error} onSubmit={() => save(f)}
      hint="O BarberFlow aprende de quanto em quanto tempo cada cliente costuma voltar e avisa quando ele passa do próprio ritmo. Vale só para a sua barbearia.">
      <Select label="Modo de reativação" value={f.mode} onChange={(e) => setF((s) => ({ ...s, mode: e.target.value as "manual" | "automatic" }))}>
        <option value="manual">Manual: eu escolho quem reativar</option>
        <option value="automatic">Automático: o sistema pede o envio seguindo as regras</option>
      </Select>
      <div className="grid grid-cols-2 gap-3">
        <Input label="Margem de atraso (%)" type="number" inputMode="numeric" min={0} max={100} value={f.marginPercent} onChange={set("marginPercent")} required />
        <Input label="Mínimo de atendimentos" type="number" inputMode="numeric" min={2} max={50} value={f.minVisits} onChange={set("minVisits")} required />
      </div>
      <p className="-mt-2 text-sm text-muted">O cliente entra quando passa do intervalo habitual dele mais a margem. Com menos atendimentos que o mínimo, o comportamento não é considerado (mínimo 2).</p>
      <div className="grid grid-cols-2 gap-3">
        <Input label="Enviar a partir de" type="time" value={f.windowStart} onChange={set("windowStart")} required />
        <Input label="Enviar até" type="time" value={f.windowEnd} onChange={set("windowEnd")} required />
      </div>
      <p className="-mt-2 text-sm text-muted">Horário do fuso da barbearia, independente do horário de funcionamento.</p>
      <div className="grid grid-cols-2 gap-3">
        <Input label="Limite por dia" type="number" inputMode="numeric" min={1} max={500} value={f.dailyLimit} onChange={set("dailyLimit")} required />
        <Input label="Máx. de tentativas" type="number" inputMode="numeric" min={1} max={20} value={f.maxAttempts} onChange={set("maxAttempts")} required />
        <Input label="Dias entre tentativas" type="number" inputMode="numeric" min={1} max={365} value={f.minDaysBetweenAttempts} onChange={set("minDaysBetweenAttempts")} required />
        <Input label="Prazo p/ contar o retorno (dias)" type="number" inputMode="numeric" min={1} max={90} value={f.attributionDays} onChange={set("attributionDays")} required />
      </div>
      <p className="-mt-2 text-sm text-muted">Um agendamento feito até o prazo depois da mensagem conta como vindo da reativação.</p>
      <div className="flex min-h-14 items-center justify-between gap-3 rounded-xl border border-input bg-card py-1 pl-4 pr-1">
        <div className="min-w-0">
          <p className="text-[15px]">Não contatar quem já tem horário</p>
          <p className="text-sm text-muted">Pula clientes com agendamento futuro.</p>
        </div>
        <Switch checked={f.blockFutureAppointment} onChange={(v) => setF((s) => ({ ...s, blockFutureAppointment: v }))} label="Não contatar quem já tem agendamento futuro" />
      </div>
      <p className="text-sm text-muted">Sempre ativos: quem pediu para não receber nunca é contatado, e nunca há duas campanhas ao mesmo tempo para o mesmo cliente.</p>
    </Section>
  );
}

const SECTIONS = [
  { id: "barbearia", label: "Barbearia", icon: "home" },
  { id: "aparencia", label: "Aparência", icon: "palette" },
  { id: "horario", label: "Horário", icon: "clock" },
  { id: "agenda", label: "Agenda", icon: "calendar" },
  { id: "clientes", label: "Clientes", icon: "user" },
  { id: "reativacao", label: "Reativação", icon: "refresh" },
] as const;

/** Navegação por âncoras: lateral no desktop, chips rolando na horizontal no celular. */
function SectionNav() {
  return (
    <nav aria-label="Seções das configurações" className="-mx-4 mb-5 overflow-x-auto px-4 md:sticky md:top-24 md:mx-0 md:mb-0 md:w-52 md:shrink-0 md:self-start md:overflow-visible md:px-0">
      <ul className="flex gap-2 md:flex-col md:gap-1">
        {SECTIONS.map((x) => (
          <li key={x.id} className="shrink-0">
            <a href={`#${x.id}`} className="flex h-11 items-center gap-2 rounded-full border border-border bg-card px-4 text-sm font-medium text-foreground/80 transition-colors hover:border-primary/40 hover:text-primary md:rounded-xl md:border-transparent md:bg-transparent md:px-3 md:hover:bg-card">
              <Icon name={x.icon} className="h-4 w-4" /> {x.label}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}

export function SettingsForms({ orgName, settings, reactivation, theme }: { orgName: string; settings: BusinessSettings; reactivation?: ReactivationSettings | null; theme?: string }) {
  const { message, show } = useToast();
  return (
    <div className="md:flex md:items-start md:gap-8">
      <SectionNav />
      <div className="min-w-0 max-w-2xl flex-1 space-y-6">
        <BusinessSection name={orgName} onSaved={show} />
        <AppearanceSection current={theme} onSaved={show} />
        <HoursSection settings={settings} onSaved={show} />
        <AgendaSection settings={settings} onSaved={show} />
        <ClientRulesSection settings={settings} onSaved={show} />
        {reactivation === undefined ? null : reactivation ? (
          <ReactivationSection settings={reactivation} onSaved={show} />
        ) : (
          <section id="reativacao" className="scroll-mt-24 rounded-2xl border border-border bg-card p-5 shadow-card sm:p-6">
            <h2 className="text-lg font-semibold tracking-tight">Reativação de clientes</h2>
            <div className="mt-3"><ErrorNote>Não foi possível carregar estas configurações. Confirme que a migration 0003_reactivation.sql foi aplicada e atualize a página.</ErrorNote></div>
          </section>
        )}
      </div>
      <Toast message={message} />
    </div>
  );
}
