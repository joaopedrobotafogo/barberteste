"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Icon } from "@/components/ui";
import { Logo } from "@/components/brand/logo";
import { bottomItemsFor, itemsFor, type NavItem } from "@/lib/nav";
import type { Role } from "@/lib/types";

const isActive = (path: string, href: string) =>
  href === "/" ? path === "/" : path === href || path.startsWith(href + "/");

export function Sidebar({ role }: { role: Role }) {
  const path = usePathname();
  return (
    <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 p-3 md:block">
      <div className="flex h-full flex-col rounded-3xl bg-sidebar px-3 py-6 shadow-pop">
        <Link href="/" aria-label="BarberFlow — Início" className="mb-8 block px-3">
          <Logo variant="full" tone="dark" height={30} />
        </Link>
        <nav className="flex flex-col gap-1" aria-label="Principal">
          {itemsFor(role).map((i: NavItem) => {
            const on = isActive(path, i.href);
            return (
              <Link key={i.href} href={i.href} aria-current={on ? "page" : undefined}
                className={`group flex h-12 items-center gap-3 rounded-full pl-1.5 pr-4 text-[15px] font-medium transition-all duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white/50 ${on ? "bg-sidebar-active text-sidebar-active-foreground shadow-md" : "text-sidebar-foreground hover:bg-sidebar-muted/70 hover:text-white"}`}>
                <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors ${on ? "bg-white/15" : "bg-sidebar-muted group-hover:bg-sidebar-muted"}`}>
                  <Icon name={i.icon} className="h-[18px] w-[18px]" />
                </span>
                {i.label}
              </Link>
            );
          })}
        </nav>
      </div>
    </aside>
  );
}

export function BottomNav({ role }: { role: Role }) {
  const path = usePathname();
  const items = bottomItemsFor(role);
  const moreActive = !items.some((i) => isActive(path, i.href));
  const cls = (on: boolean) => `relative flex min-h-[60px] flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-medium transition-colors ${on ? "text-primary" : "text-muted"}`;
  const bar = (on: boolean) => on ? <span className="absolute top-0 h-[3px] w-8 rounded-b-full bg-primary" aria-hidden="true" /> : null;
  return (
    <nav aria-label="Principal" className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-card/95 shadow-[0_-4px_20px_-8px_rgb(var(--foreground)/0.12)] backdrop-blur md:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}>
      <div className="mx-auto flex max-w-lg">
        {items.map((i) => {
          const on = isActive(path, i.href);
          return (
            <Link key={i.href} href={i.href} className={cls(on)} aria-current={on ? "page" : undefined}>
              {bar(on)}
              <Icon name={i.icon} className="h-6 w-6" strokeWidth={on ? 2.1 : 1.6} /> {i.label}
            </Link>
          );
        })}
        <Link href="/mais" className={cls(moreActive)} aria-current={moreActive ? "page" : undefined}>
          {bar(moreActive)}
          <Icon name="more" className="h-6 w-6" /> Mais
        </Link>
      </div>
    </nav>
  );
}
