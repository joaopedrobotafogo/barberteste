"use client";

import { useActionState, useEffect, useRef, useState } from "react";
import { getSlots, saveAppointment, searchClients } from "@/app/(app)/agenda/actions";
import { ALL_STATUSES, type AgendaAppt, type BarberOpt, type ClientPick, type ServiceOpt } from "@/lib/agenda";
import { APPT_LABEL } from "@/lib/clients";
import { brl } from "@/lib/format";
import type { FormState } from "@/lib/types";
import { Button, ErrorNote, Input, Select, Textarea, Toggle } from "@/components/ui";

export interface AppointmentFormProps {
  appt: AgendaAppt | null;
  prefill: ClientPick | null;
  defaultDate: string;
  defaultBarberId: string | null;
  lockedBarberId: string | null;
  barbers: BarberOpt[];
  services: ServiceOpt[];
  allowOverbooking: boolean;
  onDone: (message: string) => void;
}

interface SlotState { list: string[]; closed: boolean; loading: boolean; error?: string }
const money = (n: number) => n.toFixed(2).replace(".", ",");

export function AppointmentForm(p: AppointmentFormProps) {
  const { appt } = p;
  const [state, action, pending] = useActionState(saveAppointment, {} as FormState);

  // cliente
  const [client, setClient] = useState<ClientPick | null>(appt ? { id: appt.clientId, name: appt.clientName, phone: appt.clientPhone } : p.prefill);
  const [newMode, setNewMode] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<ClientPick[]>([]);
  const [searching, setSearching] = useState(false);

  // serviço, barbeiro, data, horário, valor
  const [serviceId, setServiceId] = useState(appt?.serviceId ?? "");
  const [barberId, setBarberId] = useState(appt?.barberId ?? p.lockedBarberId ?? p.defaultBarberId ?? p.barbers[0]?.id ?? "");
  const [date, setDate] = useState(appt?.date ?? p.defaultDate);
  const [time, setTime] = useState(appt?.time ?? "");
  const [overbook, setOverbook] = useState(appt?.isOverbook ?? false);
  const [price, setPrice] = useState(appt ? money(appt.price) : "");
  const priceTouched = useRef(!!appt);
  const [slots, setSlots] = useState<SlotState>({ list: [], closed: false, loading: false });

  useEffect(() => { if (state.ok) p.onDone(state.message ?? "Salvo"); }, [state]); // eslint-disable-line react-hooks/exhaustive-deps

  // busca de clientes (debounce)
  useEffect(() => {
    const q = query.trim();
    if (client || newMode || q.length < 2) { setResults([]); return; }
    let cancel = false;
    setSearching(true);
    const t = setTimeout(async () => {
      try { const r = await searchClients(q); if (!cancel) setResults(r); }
      catch { if (!cancel) setResults([]); }
      finally { if (!cancel) setSearching(false); }
    }, 250);
    return () => { cancel = true; clearTimeout(t); };
  }, [query, client, newMode]);

  // horários livres
  useEffect(() => {
    if (overbook || !barberId || !serviceId || !date) { setSlots({ list: [], closed: false, loading: false }); return; }
    let cancel = false;
    setSlots((s) => ({ ...s, loading: true, error: undefined }));
    getSlots({ barberId, serviceId, date, excludeId: appt?.id })
      .then((r) => {
        if (cancel) return;
        let list = r.slots;
        // ao remarcar, o horário atual continua selecionável
        if (appt && appt.barberId === barberId && appt.date === date && appt.serviceId === serviceId && !list.includes(appt.time)) {
          list = [...list, appt.time].sort();
        }
        setSlots({ list, closed: r.closed, loading: false, error: r.error });
        setTime((t) => (t && !list.includes(t) ? "" : t));
      })
      .catch(() => { if (!cancel) setSlots({ list: [], closed: false, loading: false, error: "Não foi possível carregar os horários." }); });
    return () => { cancel = true; };
  }, [barberId, serviceId, date, overbook, appt]);

  const service = p.services.find((s) => s.id === serviceId);
  const barberLocked = !!p.lockedBarberId;

  return (
    <form action={action} className="space-y-5">
      {appt && <input type="hidden" name="id" value={appt.id} />}

      {/* Cliente */}
      <div>
        <span className="mb-1.5 block text-sm font-medium text-ink/80">Cliente</span>
        {client ? (
          <div className="flex items-center justify-between gap-3 rounded-xl border border-line bg-surface px-4 py-3">
            <span className="min-w-0"><span className="block truncate text-[15px] font-medium">{client.name}</span><span className="block text-sm text-muted">{client.phone}</span></span>
            {!appt && <button type="button" onClick={() => { setClient(null); setQuery(""); }} className="h-11 shrink-0 px-2 text-sm font-medium underline-offset-4 hover:underline">Trocar</button>}
            <input type="hidden" name="client_id" value={client.id} />
          </div>
        ) : newMode ? (
          <div className="space-y-3 rounded-xl border border-line bg-surface p-4">
            <input type="hidden" name="new_client" value="1" />
            <Input label="Nome do novo cliente" name="new_name" autoComplete="off" />
            <Input label="Telefone" name="new_phone" type="tel" inputMode="tel" placeholder="(21) 99999-9999" autoComplete="off" />
            <button type="button" onClick={() => setNewMode(false)} className="h-11 text-sm text-muted underline-offset-4 hover:underline">Buscar cliente existente</button>
          </div>
        ) : (
          <div>
            <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Buscar por nome ou telefone" autoComplete="off" aria-label="Buscar cliente"
              className="h-12 w-full rounded-xl border border-line bg-surface px-4 text-base outline-none focus:border-primary focus:ring-2 focus:ring-primary/15" />
            {(results.length > 0 || searching || query.trim().length >= 2) && (
              <ul className="mt-2 divide-y divide-line overflow-hidden rounded-xl border border-line bg-surface">
                {results.map((c) => (
                  <li key={c.id}><button type="button" onClick={() => setClient(c)} className="flex min-h-12 w-full flex-col items-start justify-center px-4 py-2 text-left hover:bg-muted-bg">
                    <span className="text-[15px] font-medium">{c.name}</span><span className="text-sm text-muted">{c.phone}</span></button></li>
                ))}
                {!searching && results.length === 0 && <li className="px-4 py-3 text-sm text-muted">Nenhum cliente encontrado.</li>}
                {searching && <li className="px-4 py-3 text-sm text-muted">Buscando…</li>}
              </ul>
            )}
            <button type="button" onClick={() => setNewMode(true)} className="mt-2 h-11 text-sm font-medium underline-offset-4 hover:underline">+ Novo cliente</button>
          </div>
        )}
      </div>

      {/* Serviço e barbeiro */}
      <Select label="Serviço" name="service_id" value={serviceId} required
        onChange={(e) => {
          setServiceId(e.target.value);
          const s = p.services.find((x) => x.id === e.target.value);
          if (s && !priceTouched.current) setPrice(money(s.price));
        }}>
        <option value="" disabled>Selecione…</option>
        {p.services.map((s) => <option key={s.id} value={s.id}>{s.name} · {s.duration_minutes} min · {brl(s.price)}</option>)}
      </Select>

      <Select label="Barbeiro" name="barber_id" value={barberId} required disabled={barberLocked && p.barbers.length <= 1}
        onChange={(e) => setBarberId(e.target.value)}>
        {p.barbers.map((b) => <option key={b.id} value={b.id} disabled={barberLocked && b.id !== p.lockedBarberId}>{b.name}</option>)}
      </Select>
      {barberLocked && <input type="hidden" name="barber_id" value={barberId} />}

      {/* Data e horário */}
      <Input label="Data" name="date" type="date" value={date} onChange={(e) => setDate(e.target.value)} required />

      {p.allowOverbooking && <Toggle name="is_overbook" label="Encaixe (ignora conflitos)" defaultChecked={overbook} />}
      {p.allowOverbooking && <OverbookWatcher setOverbook={setOverbook} />}

      <div>
        <span className="mb-1.5 block text-sm font-medium text-ink/80">Horário{service ? ` · ${service.duration_minutes} min` : ""}</span>
        {overbook ? (
          <Input label="Hora do encaixe" name="time" type="time" value={time} onChange={(e) => setTime(e.target.value)} required />
        ) : !serviceId ? (
          <p className="text-sm text-muted">Escolha o serviço para ver os horários livres.</p>
        ) : slots.loading ? (
          <p className="text-sm text-muted" aria-live="polite">Buscando horários…</p>
        ) : slots.error ? (
          <ErrorNote>{slots.error}</ErrorNote>
        ) : slots.closed ? (
          <p className="text-sm text-muted">A barbearia está fechada neste dia.</p>
        ) : slots.list.length === 0 ? (
          <p className="text-sm text-muted">Sem horários livres neste dia. Tente outra data ou outro barbeiro.</p>
        ) : (
          <div className="grid grid-cols-4 gap-2" role="radiogroup" aria-label="Horários livres">
            {slots.list.map((h) => (
              <button key={h} type="button" role="radio" aria-checked={time === h} onClick={() => setTime(h)}
                className={`h-11 rounded-xl border text-sm font-medium tabular-nums transition-colors ${time === h ? "border-primary bg-primary text-primary-foreground" : "border-line bg-surface hover:border-primary/40"}`}>{h}</button>
            ))}
          </div>
        )}
        {!overbook && <input type="hidden" name="time" value={time} />}
      </div>

      {/* Status, valor, notas */}
      <Select label="Status" name="status" defaultValue={appt?.status ?? "confirmed"}>
        {ALL_STATUSES.map((s) => <option key={s} value={s}>{APPT_LABEL[s]}</option>)}
      </Select>
      <Input label="Valor (R$)" name="price" inputMode="decimal" value={price} placeholder={service ? money(service.price) : "0,00"}
        hint={service ? "Preenchido pelo serviço; pode ser alterado." : undefined}
        onChange={(e) => { priceTouched.current = true; setPrice(e.target.value); }} />
      <Textarea label="Observações (opcional)" name="notes" defaultValue={appt?.notes ?? ""} />

      {state.error && <ErrorNote>{state.error}</ErrorNote>}
      <Button type="submit" loading={pending} disabled={!time} className="w-full">{appt ? "Salvar alterações" : "Criar agendamento"}</Button>
    </form>
  );
}

/** O Toggle é um checkbox nativo não controlado; este observador sincroniza o estado para trocar slots por hora livre. */
function OverbookWatcher({ setOverbook }: { setOverbook: (v: boolean) => void }) {
  useEffect(() => {
    const el = document.querySelector<HTMLInputElement>('input[name="is_overbook"]');
    if (!el) return;
    const on = () => setOverbook(el.checked);
    el.addEventListener("change", on);
    return () => el.removeEventListener("change", on);
  }, [setOverbook]);
  return null;
}
