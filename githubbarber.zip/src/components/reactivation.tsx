import Link from "next/link";
import { Badge, EmptyState, ErrorNote, Icon, SectionHeader, type Tone } from "@/components/ui";
import { CARD } from "@/components/ui-styles";
import type { IconName } from "@/lib/nav";
import { ReactivationList, type ReactivationRow } from "@/components/reactivation-list";
import type { CandidateItem, Overview } from "@/lib/reactivation/service";
import type { ReactivationView } from "@/lib/reactivation/view";

function Metric({ label, value, hint, icon, highlight }: { label: string; value: number; hint?: string; icon: IconName; highlight?: boolean }) {
  return (
    <div className={`min-w-0 rounded-xl border px-3.5 py-3 ${highlight ? "border-success/30 bg-success/10" : "border-border bg-card"}`}>
      <p className={`flex items-center gap-1.5 truncate text-[11px] font-medium ${highlight ? "text-success" : "text-muted"}`}>
        <Icon name={icon} className="h-3.5 w-3.5 shrink-0" /> <span className="truncate">{label}</span>
      </p>
      <p className={`mt-1.5 text-2xl font-bold leading-none tabular-nums ${highlight ? "text-success" : ""}`}>{value}</p>
      {hint && <p className="mt-1 truncate text-[11px] text-muted">{hint}</p>}
    </div>
  );
}

const toRow = (c: CandidateItem): ReactivationRow => ({
  clientId: c.client.id, name: c.client.name, phone: c.client.phone, state: c.state, attemptId: c.attempt?.id ?? null,
  daysSince: c.behavior.daysSinceLastVisit, habitualDays: c.behavior.habitualIntervalDays, overdueDays: c.behavior.overdueDays,
  confidence: c.behavior.confidence, visits: c.behavior.visits,
});

function Legend({ icon, tone, title, text }: { icon: IconName; tone: Tone; title: string; text: string }) {
  const color = tone === "success" ? "bg-success/10 text-success" : "bg-foreground/5 text-foreground/70";
  return (
    <div className="flex items-start gap-2.5">
      <span className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${color}`}><Icon name={icon} className="h-3.5 w-3.5" /></span>
      <p className="text-xs leading-relaxed text-muted"><strong className="font-semibold text-foreground">{title}</strong> {text}</p>
    </div>
  );
}

/** Mesmos números de antes, agora separados em "Hoje" (mensagens) e "Resultado" (cliente voltou). */
export function ReactivationMetrics({ o }: { o: Overview }) {
  const m = o.metrics;
  return (
    <>
      <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted">Mensagens</p>
      <div className="grid grid-cols-3 gap-2">
        <Metric icon="users" label="Elegíveis" value={m.eligible} />
        <Metric icon="clock" label="Pedidos hoje" value={m.requestedToday} />
        <Metric icon="send" label="Enviadas hoje" value={m.sentToday} />
      </div>
      <p className="mb-2 mt-4 text-xs font-semibold uppercase tracking-wide text-muted">Resultado · últimos {m.periodDays} dias</p>
      <div className="grid grid-cols-3 gap-2">
        <Metric icon="mail" label="Respostas" value={m.responded} />
        <Metric icon="calendar" label="Agendaram" value={m.booked} />
        <Metric icon="check" label="Reativados" value={m.reactivated} highlight />
      </div>
      <div className="mt-4 space-y-2.5 rounded-xl bg-muted-bg/70 p-3.5">
        <Legend icon="send" tone="neutral" title="Mensagem enviada:" text="o aviso saiu para o cliente. Ainda não significa que ele voltou." />
        <Legend icon="check" tone="success" title="Cliente reativado:" text="ele voltou e o atendimento foi concluído." />
      </div>
    </>
  );
}

/** Seção "Clientes para reativar" (dono). `limit` corta a lista no Dashboard; sem limit mostra tudo (/reativacao). */
export function ReactivationSection({ view, limit, showAllLink }: { view: ReactivationView; limit?: number; showAllLink?: boolean }) {
  const title = <SectionHeader id="reativar" title="Clientes para reativar" icon="refresh" />;
  if (view.error) {
    return (
      <section aria-labelledby="reativar" className={`${CARD} min-w-0 p-5`}>
        {title}
        <ErrorNote>Não foi possível carregar a reativação agora. Atualize a página. Se continuar, confira a configuração do servidor.</ErrorNote>
      </section>
    );
  }
  const o = view.overview;
  const all = [...o.candidates, ...o.inProgress];
  const shown = limit ? all.slice(0, limit) : all;
  const rows = shown.map(toRow);
  const auto = o.settings.mode === "automatic";

  return (
    <section aria-labelledby="reativar" className={`${CARD} min-w-0 p-5`}>
      {title}
      <div className="mb-4 flex flex-wrap items-center gap-x-3 gap-y-1.5 text-xs text-muted">
        <Badge tone={auto ? "success" : "primary"}>Modo {auto ? "automático" : "manual"}</Badge>
        <span className="tabular-nums">{o.capacity.used}/{o.capacity.limit} hoje</span>
        {!o.windowOpen && <span>Envio só entre {o.settings.windowStart} e {o.settings.windowEnd}</span>}
        <Link href="/configuracoes#reativacao" className="flex h-8 items-center font-medium text-primary underline-offset-4 hover:underline">Ajustar</Link>
      </div>
      <ReactivationMetrics o={o} />
      <div className="mt-5">
        {rows.length === 0 ? (
          <EmptyState icon="userPlus" title="Você está em dia!" text="Nenhum cliente está atrasado em relação ao próprio ritmo de retorno agora." />
        ) : (
          <ReactivationList rows={rows} />
        )}
      </div>
      <div className="mt-2 flex flex-wrap gap-x-4 px-1 text-sm font-medium text-primary">
        {showAllLink && all.length > rows.length && (
          <Link href="/reativacao" className="flex h-11 items-center hover:text-primary-hover">Ver todos ({all.length})</Link>
        )}
        <Link href="/clientes?filtro=risco" className="flex h-11 items-center hover:text-primary-hover">Ver em risco</Link>
        <Link href="/clientes?filtro=perdidos" className="flex h-11 items-center hover:text-primary-hover">Ver perdidos</Link>
      </div>
    </section>
  );
}
