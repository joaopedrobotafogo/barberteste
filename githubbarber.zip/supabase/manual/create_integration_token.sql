-- BarberFlow - criar / listar / revogar token de integração (executar MANUALMENTE no SQL Editor)
-- Pré-requisito: migration 0002_integration_tokens.sql já executada.

-- 0) Descubra o id da sua barbearia
-- select id, name from public.organizations;

-- 1) CRIAR token. Troque o UUID e o nome. O token aparece UMA ÚNICA VEZ no resultado:
--    copie e guarde no n8n (credencial "Header Auth"). Não é possível recuperá-lo depois.
with t as (
  select 'bf_live_' || encode(extensions.gen_random_bytes(32), 'hex') as token
), ins as (
  insert into public.integration_tokens (organization_id, name, token_hash, token_prefix)
  select '00000000-0000-0000-0000-000000000000'::uuid,   -- <<< ID DA BARBEARIA
         'n8n WhatsApp',                                  -- <<< nome do token
         encode(extensions.digest(t.token, 'sha256'), 'hex'),
         left(t.token, 12)
  from t
  returning id
)
select t.token as token_copie_agora, ins.id as token_id from t, ins;

-- 2) LISTAR tokens (nunca mostra o token, só prefixo)
-- select id, organization_id, name, token_prefix, last_used_at, revoked_at, created_at
-- from public.integration_tokens order by created_at desc;

-- 3) REVOGAR um token (a API passa a responder 401 imediatamente)
-- update public.integration_tokens set revoked_at = now() where id = '<TOKEN_ID>' and revoked_at is null;
