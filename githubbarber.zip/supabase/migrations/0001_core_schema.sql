-- BarberFlow - 0001_core_schema.sql
-- Multi-tenant: toda tabela de negócio tem organization_id + RLS.
-- A agenda (appointments) é a ÚNICA fonte de verdade: app, WhatsApp e IA futuros usam a mesma tabela.

create extension if not exists btree_gist with schema extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------- enums
create type public.member_role as enum ('owner', 'barber');
create type public.appointment_status as enum ('pending', 'confirmed', 'completed', 'cancelled', 'no_show');
create type public.appointment_source as enum ('app', 'whatsapp', 'ai');
create type public.payment_method as enum ('cash', 'pix', 'debit', 'credit', 'other');

-- ---------------------------------------------------------------- helpers
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

-- ---------------------------------------------------------------- tabelas
create table public.organizations (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (length(trim(name)) > 0),
  slug        text unique,
  phone       text,
  address     text,
  logo_url    text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  deleted_at  timestamptz
);

create table public.profiles (
  id               uuid primary key references auth.users (id) on delete cascade,
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  full_name        text not null,
  phone            text,
  role             public.member_role not null default 'barber',
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz
);
create index profiles_org_idx on public.profiles (organization_id);

create table public.barbers (
  id                  uuid primary key default gen_random_uuid(),
  organization_id     uuid not null references public.organizations (id) on delete cascade,
  profile_id          uuid references public.profiles (id) on delete set null, -- login opcional do barbeiro
  name                text not null,
  phone               text,
  email               text,
  photo_url           text,
  is_active           boolean not null default true,
  commission_percent  numeric(5,2) check (commission_percent between 0 and 100),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  deleted_at          timestamptz,
  unique (id, organization_id)
);
create index barbers_org_idx on public.barbers (organization_id) where deleted_at is null;

create table public.clients (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  name             text not null,
  phone            text not null,
  phone_normalized text generated always as (regexp_replace(phone, '\D', '', 'g')) stored, -- busca por WhatsApp futura
  email            text,
  birth_date       date,
  notes            text,
  preferences      text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  unique (id, organization_id)
);
create index clients_org_idx on public.clients (organization_id) where deleted_at is null;
create index clients_org_name_idx on public.clients (organization_id, lower(name));
create unique index clients_org_phone_uq on public.clients (organization_id, phone_normalized) where deleted_at is null;

create table public.services (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  name             text not null,
  description      text,
  price            numeric(10,2) not null check (price >= 0),
  duration_minutes integer not null check (duration_minutes between 5 and 480),
  is_active        boolean not null default true,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  unique (id, organization_id)
);
create index services_org_idx on public.services (organization_id) where deleted_at is null;

create table public.appointments (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  client_id        uuid not null,
  barber_id        uuid not null,
  service_id       uuid not null,
  start_at         timestamptz not null,
  end_at           timestamptz not null,
  status           public.appointment_status not null default 'confirmed',
  price            numeric(10,2) not null check (price >= 0), -- copiado do serviço, editável
  is_overbook      boolean not null default false,            -- "encaixe"
  source           public.appointment_source not null default 'app',
  notes            text,
  cancelled_at     timestamptz,
  created_by       uuid references auth.users (id) on delete set null,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  check (end_at > start_at),
  -- FKs compostas: impossível referenciar cliente/barbeiro/serviço de outra organização
  foreign key (client_id,  organization_id) references public.clients  (id, organization_id),
  foreign key (barber_id,  organization_id) references public.barbers  (id, organization_id),
  foreign key (service_id, organization_id) references public.services (id, organization_id),
  -- Conflito de horário garantido PELO BANCO (vale para app, WhatsApp e IA)
  constraint appointments_no_overlap exclude using gist (
    barber_id with =,
    tstzrange(start_at, end_at, '[)') with &&
  ) where (status in ('pending','confirmed','completed') and deleted_at is null and not is_overbook)
);
create index appointments_org_start_idx  on public.appointments (organization_id, start_at) where deleted_at is null;
create index appointments_barber_start_idx on public.appointments (barber_id, start_at) where deleted_at is null;
create index appointments_client_idx     on public.appointments (client_id, start_at desc) where deleted_at is null;

create table public.time_blocks (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  barber_id        uuid not null,
  start_at         timestamptz not null,
  end_at           timestamptz not null,
  reason           text,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  check (end_at > start_at),
  foreign key (barber_id, organization_id) references public.barbers (id, organization_id),
  constraint time_blocks_no_overlap exclude using gist (
    barber_id with =, tstzrange(start_at, end_at, '[)') with &&
  ) where (deleted_at is null)
);
create index time_blocks_barber_start_idx on public.time_blocks (barber_id, start_at) where deleted_at is null;

create table public.payments (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  appointment_id   uuid not null,
  client_id        uuid not null,
  barber_id        uuid not null,
  service_id       uuid not null,
  amount           numeric(10,2) not null check (amount >= 0),
  method           public.payment_method not null default 'other',
  paid_at          timestamptz not null default now(),
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now(),
  deleted_at       timestamptz,
  foreign key (appointment_id, organization_id) references public.appointments (id, organization_id),
  foreign key (client_id,  organization_id) references public.clients  (id, organization_id),
  foreign key (barber_id,  organization_id) references public.barbers  (id, organization_id),
  foreign key (service_id, organization_id) references public.services (id, organization_id)
);
-- pagamento é gerado a partir do atendimento concluído: no máximo um ativo por atendimento
create unique index payments_appointment_uq on public.payments (appointment_id) where deleted_at is null;
create index payments_org_paid_idx on public.payments (organization_id, paid_at) where deleted_at is null;

create table public.business_settings (
  organization_id        uuid primary key references public.organizations (id) on delete cascade,
  timezone               text not null default 'America/Sao_Paulo',
  -- {"mon":{"open":"09:00","close":"19:00"}, "sun":null, ...}
  opening_hours          jsonb not null default '{
    "mon":{"open":"09:00","close":"19:00"},"tue":{"open":"09:00","close":"19:00"},
    "wed":{"open":"09:00","close":"19:00"},"thu":{"open":"09:00","close":"19:00"},
    "fri":{"open":"09:00","close":"19:00"},"sat":{"open":"09:00","close":"17:00"},"sun":null}'::jsonb,
  default_duration_minutes integer not null default 30 check (default_duration_minutes > 0),
  slot_interval_minutes  integer not null default 15 check (slot_interval_minutes > 0),
  min_notice_minutes     integer not null default 0 check (min_notice_minutes >= 0),
  allow_overbooking      boolean not null default false,
  risk_after_days        integer not null default 30 check (risk_after_days > 0),
  lost_after_days        integer not null default 60 check (lost_after_days > 0),
  vip_min_visits         integer not null default 10 check (vip_min_visits > 0),
  vip_min_spent          numeric(10,2) not null default 500 check (vip_min_spent >= 0),
  created_at             timestamptz not null default now(),
  updated_at             timestamptz not null default now(),
  check (lost_after_days > risk_after_days)
);

-- updated_at automático
do $$
declare t text;
begin
  foreach t in array array['organizations','profiles','barbers','clients','services',
                           'appointments','time_blocks','payments','business_settings']
  loop
    execute format('create trigger %I before update on public.%I for each row execute function public.set_updated_at()',
                   t || '_set_updated_at', t);
  end loop;
end $$;

-- ---------------------------------------------------------------- helpers de tenant (RLS)
create or replace function public.auth_org_id()
returns uuid language sql stable security definer set search_path = public as $$
  select organization_id from public.profiles where id = auth.uid() and deleted_at is null
$$;

create or replace function public.auth_is_owner()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'owner' from public.profiles where id = auth.uid() and deleted_at is null), false)
$$;

revoke all on function public.auth_org_id(), public.auth_is_owner() from public, anon;
grant execute on function public.auth_org_id(), public.auth_is_owner() to authenticated;

-- ---------------------------------------------------------------- regras de negócio na agenda
-- 1) encaixe só se permitido nas configurações; 2) não sobrepor bloqueios; 3) cancelamento carimba data
create or replace function public.appointments_rules()
returns trigger language plpgsql as $$
declare allow_ob boolean;
begin
  if new.is_overbook then
    select allow_overbooking into allow_ob from public.business_settings where organization_id = new.organization_id;
    if not coalesce(allow_ob, false) then
      raise exception 'Encaixes não estão habilitados para esta barbearia' using errcode = 'P0001';
    end if;
  end if;

  if new.status in ('pending','confirmed','completed') and new.deleted_at is null and not new.is_overbook then
    if exists (
      select 1 from public.time_blocks b
      where b.barber_id = new.barber_id and b.deleted_at is null
        and tstzrange(b.start_at, b.end_at, '[)') && tstzrange(new.start_at, new.end_at, '[)')
    ) then
      raise exception 'Horário bloqueado para este barbeiro' using errcode = 'P0001';
    end if;
  end if;

  if new.status = 'cancelled' and (tg_op = 'INSERT' or old.status <> 'cancelled') then
    new.cancelled_at = now();
  end if;
  return new;
end $$;
create trigger appointments_rules_trg before insert or update on public.appointments
  for each row execute function public.appointments_rules();

create or replace function public.time_blocks_rules()
returns trigger language plpgsql as $$
begin
  if new.deleted_at is null and exists (
    select 1 from public.appointments a
    where a.barber_id = new.barber_id and a.deleted_at is null
      and a.status in ('pending','confirmed','completed')
      and tstzrange(a.start_at, a.end_at, '[)') && tstzrange(new.start_at, new.end_at, '[)')
  ) then
    raise exception 'Já existem agendamentos neste período' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger time_blocks_rules_trg before insert or update on public.time_blocks
  for each row execute function public.time_blocks_rules();

-- Atendimento concluído gera pagamento; sair de "concluído" anula o pagamento (soft delete)
create or replace function public.appointments_sync_payment()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'completed' and new.deleted_at is null then
    insert into public.payments (organization_id, appointment_id, client_id, barber_id, service_id, amount, paid_at)
    values (new.organization_id, new.id, new.client_id, new.barber_id, new.service_id, new.price, now())
    on conflict (appointment_id) where deleted_at is null
    do update set amount = excluded.amount, updated_at = now();
  elsif tg_op = 'UPDATE' and (old.status = 'completed') then
    update public.payments set deleted_at = now()
    where appointment_id = new.id and deleted_at is null;
  end if;
  return new;
end $$;
create trigger appointments_sync_payment_trg after insert or update of status, price, deleted_at on public.appointments
  for each row execute function public.appointments_sync_payment();

-- ---------------------------------------------------------------- proteção de perfil
create or replace function public.profiles_protect()
returns trigger language plpgsql as $$
begin
  if auth.uid() is not null and (new.organization_id <> old.organization_id or new.role <> old.role) then
    raise exception 'Não é permitido alterar organização ou papel' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger profiles_protect_trg before update on public.profiles
  for each row execute function public.profiles_protect();

-- ---------------------------------------------------------------- cadastro: cria barbearia + owner
create or replace function public.create_organization_with_owner(
  p_org_name text, p_owner_name text, p_phone text default null
) returns uuid language plpgsql security definer set search_path = public as $$
declare v_org uuid; v_profile uuid;
begin
  if auth.uid() is null then raise exception 'Não autenticado' using errcode = '42501'; end if;
  if exists (select 1 from public.profiles where id = auth.uid()) then
    raise exception 'Usuário já pertence a uma barbearia';
  end if;

  insert into public.organizations (name, phone) values (trim(p_org_name), p_phone) returning id into v_org;
  insert into public.profiles (id, organization_id, full_name, phone, role)
    values (auth.uid(), v_org, trim(p_owner_name), p_phone, 'owner') returning id into v_profile;
  insert into public.business_settings (organization_id) values (v_org);
  insert into public.barbers (organization_id, profile_id, name, phone)
    values (v_org, v_profile, trim(p_owner_name), p_phone); -- dono também atende, pode ser desativado depois
  return v_org;
end $$;
revoke all on function public.create_organization_with_owner(text, text, text) from public, anon;
grant execute on function public.create_organization_with_owner(text, text, text) to authenticated;

-- ---------------------------------------------------------------- status do cliente (lógica CENTRALIZADA)
create or replace function public.client_status(p_days_since_last integer, p_risk integer, p_lost integer)
returns text language sql immutable as $$
  select case
    when p_days_since_last is null then 'new'      -- ainda sem atendimento concluído
    when p_days_since_last >= p_lost then 'lost'
    when p_days_since_last >= p_risk then 'at_risk'
    else 'active'
  end
$$;

-- Métricas calculadas só de atendimentos concluídos. security_invoker => respeita RLS do chamador.
create view public.client_overview with (security_invoker = true) as
select
  c.*,
  s.first_visit_at,
  s.last_visit_at,
  coalesce(s.visits, 0)       as visits,
  coalesce(s.total_spent, 0)  as total_spent,
  case when coalesce(s.visits,0) > 0 then round(s.total_spent / s.visits, 2) else 0 end as avg_ticket,
  public.client_status(
    case when s.last_visit_at is null then null
         else (current_date - (s.last_visit_at at time zone bs.timezone)::date) end,
    bs.risk_after_days, bs.lost_after_days
  ) as status,
  (coalesce(s.visits,0) >= bs.vip_min_visits or coalesce(s.total_spent,0) >= bs.vip_min_spent) as is_vip
from public.clients c
join public.business_settings bs on bs.organization_id = c.organization_id
left join lateral (
  select min(a.start_at) as first_visit_at, max(a.start_at) as last_visit_at,
         count(*) as visits, sum(a.price) as total_spent
  from public.appointments a
  where a.client_id = c.id and a.status = 'completed' and a.deleted_at is null
) s on true
where c.deleted_at is null;

-- ---------------------------------------------------------------- RLS
alter table public.organizations      enable row level security;
alter table public.profiles           enable row level security;
alter table public.barbers            enable row level security;
alter table public.clients            enable row level security;
alter table public.services           enable row level security;
alter table public.appointments       enable row level security;
alter table public.time_blocks        enable row level security;
alter table public.payments           enable row level security;
alter table public.business_settings  enable row level security;

-- organizations
create policy org_select on public.organizations for select to authenticated using (id = public.auth_org_id());
create policy org_update on public.organizations for update to authenticated
  using (id = public.auth_org_id() and public.auth_is_owner())
  with check (id = public.auth_org_id());

-- profiles
create policy profiles_select on public.profiles for select to authenticated using (organization_id = public.auth_org_id());
create policy profiles_update_self on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid() and organization_id = public.auth_org_id());

-- business_settings
create policy settings_select on public.business_settings for select to authenticated using (organization_id = public.auth_org_id());
create policy settings_update on public.business_settings for update to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner())
  with check (organization_id = public.auth_org_id());

-- barbers e services: todos leem; só owner escreve
create policy barbers_select on public.barbers for select to authenticated using (organization_id = public.auth_org_id());
create policy barbers_write  on public.barbers for all to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner())
  with check (organization_id = public.auth_org_id() and public.auth_is_owner());

create policy services_select on public.services for select to authenticated using (organization_id = public.auth_org_id());
create policy services_write  on public.services for all to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner())
  with check (organization_id = public.auth_org_id() and public.auth_is_owner());

-- clients, appointments, time_blocks: owner e barber operam a agenda
create policy clients_all on public.clients for all to authenticated
  using (organization_id = public.auth_org_id()) with check (organization_id = public.auth_org_id());
create policy appointments_all on public.appointments for all to authenticated
  using (organization_id = public.auth_org_id()) with check (organization_id = public.auth_org_id());
create policy time_blocks_all on public.time_blocks for all to authenticated
  using (organization_id = public.auth_org_id()) with check (organization_id = public.auth_org_id());

-- payments: leitura só do owner; escrita ocorre via trigger (security definer)
create policy payments_select_owner on public.payments for select to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner());
create policy payments_update_owner on public.payments for update to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner())
  with check (organization_id = public.auth_org_id());

-- Privilégios: nada para anon
revoke all on all tables in schema public from anon;
grant select, insert, update, delete on all tables in schema public to authenticated;
revoke insert, delete on public.payments from authenticated;
revoke insert, delete on public.organizations, public.profiles, public.business_settings from authenticated;
