-- BarberFlow - 0003_reactivation.sql
-- ETAPA 11: inteligência de reativação de clientes (comportamento individual de retorno).
--
-- *** NÃO é executada automaticamente. Rode manualmente no SQL Editor do Supabase. ***
-- Migration ADITIVA: cria 3 tabelas + 1 função/trigger próprios e faz 1 INSERT de configuração padrão.
-- NÃO altera, remove ou reescreve nenhuma tabela, enum, view, função, trigger ou policy existente.
-- Pode ser executada uma única vez; não recria nada do 0001/0002.
--
-- Princípios:
--  * appointments continua sendo a fonte de verdade. O estado "candidato" NÃO é gravado:
--    é calculado na hora (lib/reactivation/behavior.ts) a partir dos atendimentos concluídos.
--  * Só se persiste o que é fato/decisão: configuração da organização, TENTATIVAS de reativação e OPT-OUT.
--  * Toda tabela tem organization_id + RLS. O app acessa SOMENTE pelo servidor (service role),
--    sempre filtrando por organization_id. As policies abaixo dão leitura ao OWNER como defesa em profundidade;
--    ninguém (anon/authenticated) escreve direto.

-- ---------------------------------------------------------------- 1) configuração (1 linha por organização)
create table public.reactivation_settings (
  organization_id              uuid primary key references public.organizations (id) on delete cascade,
  mode                         text    not null default 'manual'  check (mode in ('manual', 'automatic')),
  margin_percent               integer not null default 15        check (margin_percent between 0 and 100),
  min_visits                   integer not null default 3         check (min_visits between 2 and 50),
  -- janela de envio em HH:MM no fuso da organização (business_settings.timezone); independente de opening_hours
  send_window_start            text    not null default '09:00'   check (send_window_start ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  send_window_end              text    not null default '19:00'   check (send_window_end   ~ '^([01][0-9]|2[0-3]):[0-5][0-9]$'),
  daily_limit                  integer not null default 20        check (daily_limit between 1 and 500),
  min_days_between_attempts    integer not null default 30        check (min_days_between_attempts between 1 and 365),
  max_attempts                 integer not null default 3         check (max_attempts between 1 and 20),
  block_if_future_appointment  boolean not null default true,
  -- quantos dias após o ENVIO um novo agendamento ainda é atribuído à reativação (e quando a tentativa expira)
  attribution_days             integer not null default 14        check (attribution_days between 1 and 90),
  created_at                   timestamptz not null default now(),
  updated_at                   timestamptz not null default now(),
  check (send_window_end > send_window_start)
);

-- ---------------------------------------------------------------- 2) tentativas (histórico + estado)
-- requested  = pedido registrado (mensagem PENDENTE de envio)
-- sent       = n8n confirmou o envio                (mensagem enviada  ≠ reativado)
-- responded  = cliente respondeu                    (resposta          ≠ agendamento)
-- booked     = existe agendamento válido criado depois do envio (agendou ≠ reativado)
-- reactivated= o atendimento desse agendamento foi CONCLUÍDO (cliente efetivamente voltou)
-- failed | cancelled | expired = encerradas sem resultado;  dismissed = dono ignorou o candidato
create table public.reactivation_attempts (
  id                        uuid primary key default gen_random_uuid(),
  organization_id           uuid not null references public.organizations (id) on delete cascade,
  client_id                 uuid not null,
  origin                    text not null check (origin in ('manual', 'automatic')),
  status                    text not null default 'requested'
                            check (status in ('requested','sent','responded','booked','reactivated',
                                              'failed','cancelled','expired','dismissed')),
  reason                    text not null default 'behavior_due',
  -- cálculo no momento do pedido (intervalo habitual, dias sem vir, confiança, parâmetros usados...)
  snapshot                  jsonb not null default '{}'::jsonb,
  requested_by              uuid references auth.users (id) on delete set null, -- null quando veio do n8n
  requested_at              timestamptz not null default now(),
  sent_at                   timestamptz,
  responded_at              timestamptz,
  booked_at                 timestamptz,
  reactivated_at            timestamptz,
  closed_at                 timestamptz,
  failed_reason             text,
  dismissed_until           timestamptz,
  resulting_appointment_id  uuid references public.appointments (id) on delete set null,
  created_at                timestamptz not null default now(),
  updated_at                timestamptz not null default now(),
  -- FK composta: impossível apontar para cliente de outra organização
  foreign key (client_id, organization_id) references public.clients (id, organization_id)
);
create index reactivation_attempts_org_requested_idx on public.reactivation_attempts (organization_id, requested_at desc);
create index reactivation_attempts_client_idx        on public.reactivation_attempts (organization_id, client_id, requested_at desc);
create index reactivation_attempts_org_status_idx    on public.reactivation_attempts (organization_id, status);

-- NO MÁXIMO uma tentativa ABERTA por cliente (barreira final contra campanhas simultâneas, mesmo com concorrência)
create unique index reactivation_attempts_open_uq on public.reactivation_attempts (client_id)
  where status in ('requested', 'sent', 'responded', 'booked');

-- O agendamento atribuído tem de ser do mesmo cliente e da mesma organização.
-- (appointments não tem unique (id, organization_id), então a FK composta não é possível; o trigger cobre isso.)
create or replace function public.reactivation_attempts_guard()
returns trigger language plpgsql as $$
begin
  if new.resulting_appointment_id is not null and not exists (
    select 1 from public.appointments a
    where a.id = new.resulting_appointment_id
      and a.organization_id = new.organization_id
      and a.client_id = new.client_id
  ) then
    raise exception 'Agendamento não pertence a este cliente/organização' using errcode = 'P0001';
  end if;
  return new;
end $$;
create trigger reactivation_attempts_guard_trg before insert or update on public.reactivation_attempts
  for each row execute function public.reactivation_attempts_guard();

-- ---------------------------------------------------------------- 3) opt-out (cliente pediu para não receber)
create table public.reactivation_opt_outs (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  client_id        uuid not null,
  source           text not null default 'whatsapp' check (source in ('whatsapp', 'manual', 'api')),
  note             text,
  opted_out_at     timestamptz not null default now(),
  revoked_at       timestamptz,
  created_at       timestamptz not null default now(),
  foreign key (client_id, organization_id) references public.clients (id, organization_id)
);
create index reactivation_opt_outs_org_idx on public.reactivation_opt_outs (organization_id);
create unique index reactivation_opt_outs_active_uq on public.reactivation_opt_outs (client_id) where revoked_at is null;

-- ---------------------------------------------------------------- updated_at (função já existente no 0001)
create trigger reactivation_settings_set_updated_at before update on public.reactivation_settings
  for each row execute function public.set_updated_at();
create trigger reactivation_attempts_set_updated_at before update on public.reactivation_attempts
  for each row execute function public.set_updated_at();

-- ---------------------------------------------------------------- RLS + privilégios
alter table public.reactivation_settings enable row level security;
alter table public.reactivation_attempts enable row level security;
alter table public.reactivation_opt_outs enable row level security;

create policy reactivation_settings_select_owner on public.reactivation_settings for select to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner());
create policy reactivation_attempts_select_owner on public.reactivation_attempts for select to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner());
create policy reactivation_opt_outs_select_owner on public.reactivation_opt_outs for select to authenticated
  using (organization_id = public.auth_org_id() and public.auth_is_owner());

-- O Supabase concede privilégios por padrão em tabelas novas; removemos e devolvemos só SELECT.
-- Escrita: exclusivamente service role (servidor do BarberFlow), com organization_id vindo da sessão do dono
-- ou do token de integração.
revoke all on public.reactivation_settings, public.reactivation_attempts, public.reactivation_opt_outs from anon, authenticated;
grant select on public.reactivation_settings, public.reactivation_attempts, public.reactivation_opt_outs to authenticated;

-- ---------------------------------------------------------------- 4) configuração padrão para as organizações existentes
-- Único INSERT de dados desta migration (idempotente). Organizações novas usam os padrões do app
-- (o código trata "sem linha" como padrão e cria a linha ao salvar em Configurações).
insert into public.reactivation_settings (organization_id)
select id from public.organizations
on conflict (organization_id) do nothing;
