-- BarberFlow - 0002_integration_tokens.sql
-- ETAPA 9: tokens de integração (n8n / WhatsApp), um ou mais por organização.
--
-- *** NÃO é executada automaticamente. Rode manualmente no SQL Editor do Supabase. ***
-- Só ADICIONA uma tabela nova. Não altera nenhuma tabela, enum, trigger ou policy existente.
--
-- Segurança:
--  * o token em texto puro NUNCA é gravado; só o hash SHA-256 (token_hash);
--  * RLS ligada e SEM policies + revoke explícito: anon/authenticated não leem nem escrevem.
--    Somente o service role (usado apenas no servidor da API) acessa esta tabela;
--  * token_prefix (primeiros caracteres) serve só para você identificar qual token é qual.

create table public.integration_tokens (
  id               uuid primary key default gen_random_uuid(),
  organization_id  uuid not null references public.organizations (id) on delete cascade,
  name             text not null check (length(trim(name)) > 0),
  token_hash       text not null unique check (token_hash ~ '^[0-9a-f]{64}$'),
  token_prefix     text not null,
  last_used_at     timestamptz,
  revoked_at       timestamptz,
  created_at       timestamptz not null default now()
);
create index integration_tokens_org_idx on public.integration_tokens (organization_id);

alter table public.integration_tokens enable row level security;
-- Sem policies de propósito (nega tudo para quem respeita RLS).
-- O Supabase concede privilégios por padrão em tabelas novas; removemos explicitamente.
revoke all on public.integration_tokens from anon, authenticated;
