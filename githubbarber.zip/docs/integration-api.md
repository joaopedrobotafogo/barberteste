# API de integração BarberFlow (n8n / WhatsApp)

API REST para o n8n consultar e alterar a agenda **real** do BarberFlow. O BarberFlow é a fonte de verdade:
disponibilidade e conflito são calculados aqui, com a mesma regra da tela de Agenda. O n8n não deve manter agenda própria nem recalcular horários.

- **Base URL:** `https://SEU-DOMINIO/api/integration` (local: `http://localhost:3000/api/integration`)
- **Formato:** JSON (`Content-Type: application/json` nos POST). Datas `YYYY-MM-DD` e horas `HH:MM` **no fuso da barbearia** (campo `timezone` de `/business`).
- **Telefones:** aceita `21999999999`, `5521999999999`, `+55 (21) 99999-9999`. A busca encontra o cliente com ou sem DDI 55 e com ou sem o 9º dígito.

---

## 1. Autenticação

Todas as chamadas exigem o header:

```
Authorization: Bearer bf_live_<64 caracteres hexadecimais>
```

- Cada **token pertence a uma barbearia**. A organização é identificada **somente pelo token**: qualquer `organization_id` enviado no body/query é ignorado.
- O token **nunca** vai na URL, no frontend nem em variável `NEXT_PUBLIC_*`. Guarde-o só na credencial do n8n (tipo *Header Auth*: nome `Authorization`, valor `Bearer bf_live_...`).
- O banco guarda apenas o hash SHA-256 do token. Ele aparece **uma única vez**, quando é gerado.
- Token ausente, malformado, desconhecido ou revogado → `401 UNAUTHORIZED` (mesma resposta para todos os casos).

### Como criar / revogar um token (manual, no SQL Editor do Supabase)

1. Execute **uma vez** `supabase/migrations/0002_integration_tokens.sql` (cria a tabela `integration_tokens`; não altera nada existente).
2. Abra `supabase/manual/create_integration_token.sql`, troque o UUID da barbearia (`select id, name from organizations;`) e execute o bloco **1**. Copie o `token_copie_agora` do resultado.
3. Para revogar: bloco **3** do mesmo arquivo. A API passa a responder 401 na hora.

### Variáveis de ambiente do servidor

A API usa `SUPABASE_SERVICE_ROLE_KEY` **no servidor** (já usada no convite de barbeiros). Configure também no Vercel (Project → Settings → Environment Variables). Nenhuma variável nova.

---

## 2. Formato das respostas

Sucesso:
```json
{ "success": true, "data": { } }
```
Erro:
```json
{ "success": false, "error": "TIME_UNAVAILABLE", "message": "Esse horário não está mais disponível." }
```
Decida o fluxo no n8n pelo campo **`error`** (estável); `message` é texto para humanos/IA.

| HTTP | `error` | Quando |
|---|---|---|
| 400 | `INVALID_INPUT` | Parâmetro ausente/inválido (UUID, data, hora, telefone…) |
| 400 | `INVALID_BODY` | Body não é um objeto JSON válido |
| 401 | `UNAUTHORIZED` | Token ausente/inválido/revogado |
| 403 | `FORBIDDEN` | Organização do token inativa |
| 404 | `CLIENT_NOT_FOUND` | Cliente não existe nesta barbearia |
| 404 | `SERVICE_NOT_FOUND` | Serviço não existe, está inativo ou é de outra barbearia |
| 404 | `BARBER_NOT_FOUND` | Barbeiro não existe, está inativo ou é de outra barbearia |
| 404 | `APPOINTMENT_NOT_FOUND` | Agendamento não existe, é de outra barbearia **ou não é do cliente informado** |
| 409 | `TIME_UNAVAILABLE` | Horário ocupado/bloqueado (inclui perder a corrida para outro canal) |
| 409 | `BUSINESS_CLOSED` | Barbearia fechada nesse dia da semana |
| 409 | `OUTSIDE_BUSINESS_HOURS` | Fora do expediente, atendimento ultrapassaria o fechamento, ou fora da grade de horários |
| 409 | `TOO_SOON` | Horário já passou ou está dentro da antecedência mínima |
| 409 | `INVALID_STATUS` | Agendamento não está `pending`/`confirmed` (ex.: concluído, cancelado, no-show) |
| 409 | `APPOINTMENT_IN_PAST` | Agendamento já começou/passou |
| 500 | `INTERNAL_ERROR` | Erro interno (detalhes só no log do servidor) |
| 500 | `SERVER_MISCONFIGURED` | Servidor sem `SUPABASE_SERVICE_ROLE_KEY` válida |

---

## 3. Endpoints

### GET `/business`
Dados da barbearia + **"agora" no fuso dela** (use `now` para resolver "hoje", "amanhã", "sexta").
```json
{ "success": true, "data": {
  "name": "Barbearia do Zé", "phone": "(21) 3000-0000", "address": "Rua X, 10",
  "timezone": "America/Sao_Paulo",
  "now": { "date": "2026-10-05", "time": "14:32", "weekday": "mon" },
  "opening_hours": { "mon": {"open":"09:00","close":"19:00"}, "tue": {"open":"09:00","close":"19:00"}, "wed": {"open":"09:00","close":"19:00"},
                     "thu": {"open":"09:00","close":"19:00"}, "fri": {"open":"09:00","close":"19:00"}, "sat": {"open":"09:00","close":"17:00"}, "sun": null },
  "slot_interval_minutes": 15, "min_notice_minutes": 0
} }
```
`null` em um dia = fechado.

### GET `/services`
Só serviços **ativos**.
```json
{ "success": true, "data": [ { "id": "…", "name": "Corte", "description": null, "price": 35, "duration_minutes": 30 } ] }
```

### GET `/barbers`
Só barbeiros **ativos** (somente `id` e `name`).
```json
{ "success": true, "data": [ { "id": "…", "name": "João" } ] }
```

### GET `/clients?phone=5521999999999`
Busca por telefone. **Nunca cria.**
```json
{ "success": true, "data": { "id": "…", "name": "Ana", "phone": "(21) 99999-9999", "whatsapp_phone": "5521999999999", "status": "active" } }
```
`status`: `new` (nunca concluiu atendimento), `active`, `at_risk`, `lost`. Não encontrado → `404 CLIENT_NOT_FOUND`.

### POST `/clients`
```json
{ "name": "Ana Souza", "phone": "5521999999999" }
```
- Telefone novo → `201`, `created: true`.
- Telefone já existe (em qualquer formato) → `200`, `created: false`, devolve o cliente existente. **Não duplica**, nem com duas chamadas simultâneas.
```json
{ "success": true, "data": { "id": "…", "name": "Ana Souza", "phone": "(21) 99999-9999", "whatsapp_phone": "5521999999999", "status": "new", "created": true } }
```
Clientes criados pela API são salvos no formato da tela de Clientes: `(21) 99999-9999`.

### GET `/availability?service_id=…&date=2026-10-10[&barber_id=…]`
Horários **realmente livres**, calculados no BarberFlow considerando: duração do serviço, expediente e dias fechados, intervalo da agenda, antecedência mínima, agendamentos existentes e bloqueios de horário. Um atendimento que ultrapasse o fechamento nunca é listado (ex.: serviço de 60 min, fechamento 18:00 → 17:30 não aparece).

- Sem `barber_id`: devolve **todos os barbeiros ativos**, cada um com seus horários.
- `date` aceita até 365 dias à frente.
```json
{ "success": true, "data": {
  "date": "2026-10-10", "timezone": "America/Sao_Paulo", "closed": false,
  "service": { "id": "…", "name": "Corte", "duration_minutes": 30, "price": 35 },
  "barbers": [ { "id": "…", "name": "João", "slots": ["09:00","09:15","09:30","10:30"] } ]
} }
```
`closed: true` (e `slots` vazio) = a barbearia não abre nesse dia. `slots` vazio com `closed: false` = dia lotado.

### POST `/appointments`
```json
{ "phone": "5521999999999", "service_id": "…", "barber_id": "…", "date": "2026-10-10", "time": "10:30", "notes": "opcional", "source": "whatsapp" }
```
- Cliente: `client_id` **ou** `phone` (se ambos, vale `client_id`). Cliente inexistente → `404 CLIENT_NOT_FOUND` (crie antes com `POST /clients`; a API não cria cliente escondido).
- `source`: `whatsapp` (padrão) ou `ai`.
- Status inicial `confirmed` (igual à Agenda), preço copiado do serviço. Nunca cria pagamento nem conclui: o fluxo financeiro continua sendo o da Agenda (concluir atendimento).
- **Revalida tudo** no servidor (organização, cliente, serviço, barbeiro, expediente, duração, antecedência, conflito). Não confie só em `/availability`.
- Criado → `201`. Horário ocupado → `409` e **nada é criado**.
```json
{ "success": true, "data": {
  "id": "…", "status": "confirmed", "source": "whatsapp",
  "date": "2026-10-10", "time": "10:30", "end_time": "11:00",
  "start_at": "2026-10-10T13:30:00+00:00", "end_at": "2026-10-10T14:00:00+00:00",
  "price": 35, "notes": null,
  "client": { "id": "…", "name": "Ana", "phone": "(21) 99999-9999" },
  "service": { "id": "…", "name": "Corte", "duration_minutes": 30 },
  "barber": { "id": "…", "name": "João" },
  "idempotent_replay": false
} }
```

**Idempotência:** se o n8n repetir a mesma criação (mesmo cliente, serviço, barbeiro e horário de início, agendamento ainda ativo), a API devolve **o mesmo agendamento** com `200` e `idempotent_replay: true`, sem duplicar. Vale também para duas requisições idênticas simultâneas. Se o cliente cancelar e pedir o mesmo horário de novo, é um agendamento novo.

### GET `/appointments?phone=5521999999999[&client_id=…][&limit=10]`
Lista os **próximos agendamentos ativos de UM cliente** (status `pending`/`confirmed` e que ainda não começaram), do mais próximo ao mais distante. É o que permite "qual é meu horário?", "cancela meu horário" e "quero remarcar" sem o n8n guardar ids.

- **Obrigatório** `phone` **ou** `client_id` (se vierem os dois, vale `client_id`). Não existe listagem geral da agenda por esta API.
- `limit`: 1 a 20 (padrão 10). Fora disso → `400 INVALID_INPUT`.
- Telefone sem cadastro → `404 CLIENT_NOT_FOUND`. Cliente sem horários futuros ativos → `200` com `count: 0` (não é erro).
- Cancelados, concluídos, no-show e horários passados **não** aparecem. Se o mesmo número existir cadastrado em mais de um formato (duplicata antiga, com e sem 55), os agendamentos de todos esses cadastros são listados.
- Cada item tem a mesma estrutura de `GET /appointments/:id`. Somente leitura; filtra sempre pela organização do token.
```json
{ "success": true, "data": { "count": 1, "appointments": [
  { "id": "…", "status": "confirmed", "source": "whatsapp",
    "date": "2026-10-10", "time": "10:30", "end_time": "11:00",
    "start_at": "2026-10-10T13:30:00+00:00", "end_at": "2026-10-10T14:00:00+00:00",
    "price": 35, "notes": null,
    "client": { "id": "…", "name": "Ana", "phone": "(21) 99999-9999" },
    "service": { "id": "…", "name": "Corte", "duration_minutes": 30 },
    "barber": { "id": "…", "name": "João" } }
] } }
```

### GET `/appointments/:id`
Mesma estrutura acima (sem `idempotent_replay`). Opcionalmente `?client_id=…` ou `?phone=…` para confirmar o dono (divergência → 404). Agendamento de outra barbearia → 404.

### POST `/appointments/:id/cancel`
```json
{ "phone": "5521999999999" }
```
- **Obrigatório** `client_id` ou `phone`: o agendamento precisa ser **desse cliente**, senão `404 APPOINTMENT_NOT_FOUND` (impede cancelar horário de outra pessoa).
- Só `pending`/`confirmed` e que ainda não começou. Concluído/no-show → `409 INVALID_STATUS`; já iniciado → `409 APPOINTMENT_IN_PAST`.
- Mesma operação da Agenda (status → `cancelled`): o horário volta a ficar livre imediatamente.
- Repetir o cancelamento é seguro: `200` com `already_cancelled: true`.

### POST `/appointments/:id/reschedule`
```json
{ "phone": "5521999999999", "date": "2026-10-12", "time": "15:00", "barber_id": "opcional" }
```
- Mesmo requisito de dono e de status do cancelamento.
- Sem `barber_id` mantém o barbeiro atual. Mantém serviço, preço e status.
- Valida o novo horário com a mesma regra de disponibilidade (o próprio agendamento não conta como ocupação, então dá para mover 30 min dentro do próprio intervalo). Ocupado → `409`, e o agendamento **não muda**.
- Repetir a mesma remarcação: `200` com `unchanged: true`.

---

## 4. Fluxo recomendado no n8n

1. `GET /business` no início da conversa (fuso, `now`, horários) — pode ser cacheado por alguns minutos.
2. `GET /clients?phone=<telefone do WhatsApp>`.
3. `404 CLIENT_NOT_FOUND` → perguntar o nome → `POST /clients` (um `200 created:false` também serve).
4. `GET /services` e `GET /barbers` (ou pular o barbeiro e usar `/availability` sem `barber_id`).
5. Cliente escolhe serviço e dia → `GET /availability`.
6. Cliente escolhe horário (e barbeiro).
7. `POST /appointments`.
8. `409 TIME_UNAVAILABLE` / `TOO_SOON` / `OUTSIDE_BUSINESS_HOURS` → voltar ao passo 5 e oferecer novos horários.
9. `201`/`200` → confirmar ao cliente com `date`, `time`, `service.name`, `barber.name`.
10. Consultar/cancelar/remarcar: `GET /appointments?phone=…` lista os horários do cliente (se houver mais de um, pergunte qual); depois use `/cancel` ou `/reschedule` com o `id` escolhido, sempre com o `phone` do WhatsApp.

Dicas: reenviar um POST por timeout é seguro (idempotente). Não invente horários: ofereça apenas os de `slots`. Use sempre `now` de `/business` para interpretar datas relativas.

---

## 5. Segurança e logs

- Cliente Supabase com service role usado **só no servidor**; toda consulta filtra por `organization_id` do token.
- IDs de cliente/serviço/barbeiro/agendamento de outra barbearia retornam 404, como se não existissem.
- Respostas trazem só o necessário (sem comissão, e-mail de barbeiro, financeiro, notas internas do cliente).
- Erros internos não vazam detalhes. Logs no servidor, sem token nem dados do cliente:
  `[integration] organization=<uuid> operation=create_appointment success=false reason=TIME_UNAVAILABLE`
- Não há limite de taxa (rate limit) embutido. O token tem 256 bits de entropia; se quiser proteção extra, use o Firewall do Vercel.

---

## 6. Testes

**Lógica (sem rede, banco em memória que emula as constraints):**
```bash
npx tsx scripts/test-integration.ts
```

**Ponta a ponta com o Supabase real** (depois da migration e do token). Substitua `BASE`, `TOKEN` e os UUIDs:
```bash
BASE=http://localhost:3000/api/integration
TOKEN=bf_live_...
H="Authorization: Bearer $TOKEN"

curl -i $BASE/services                                   # 401 (sem token)
curl -s -H "$H" $BASE/business
curl -s -H "$H" $BASE/services
curl -s -H "$H" $BASE/barbers
curl -s -H "$H" "$BASE/clients?phone=21999999999"        # 404 se não existe
curl -s -H "$H" -H "Content-Type: application/json" -d '{"name":"Teste API","phone":"21999999999"}' $BASE/clients
curl -s -H "$H" "$BASE/availability?service_id=SERVICE_ID&date=2026-10-14"
curl -s -H "$H" -H "Content-Type: application/json" \
  -d '{"phone":"21999999999","service_id":"SERVICE_ID","barber_id":"BARBER_ID","date":"2026-10-14","time":"10:00"}' $BASE/appointments
# repita o POST acima: 200 + idempotent_replay:true. Confira o agendamento na tela da Agenda.
# Mesmo horário com OUTRO telefone: 409 TIME_UNAVAILABLE
curl -s -H "$H" "$BASE/appointments?phone=21999999999"        # próximos horários do cliente
curl -s -H "$H" "$BASE/appointments/APPT_ID?phone=21999999999"
curl -s -H "$H" -H "Content-Type: application/json" -d '{"phone":"21999999999","date":"2026-10-14","time":"11:00"}' $BASE/appointments/APPT_ID/reschedule
curl -s -H "$H" -H "Content-Type: application/json" -d '{"phone":"21999999999"}' $BASE/appointments/APPT_ID/cancel
```

---

## 7. Limitações conhecidas

- "Dias fechados" = dia da semana sem expediente (`null` em `opening_hours`). Não há calendário de feriados/datas específicas no schema.
- Não há pausa de almoço nem horário por barbeiro no schema; só bloqueios (`time_blocks`) criados na Agenda, que a API respeita.
- Encaixes (`is_overbook`) não são criados pela API.
- Sem rate limit embutido e sem chave de idempotência explícita (a idempotência usa cliente + serviço + barbeiro + horário).
- Um cliente antigo duplicado no banco (mesmo número salvo com e sem 55) faz a busca devolver o cadastro **mais antigo**.

---

## 8. Reativação de clientes (Etapa 11)

Endpoints para o n8n **executar** a reativação. Toda a inteligência (de quanto em quanto tempo cada cliente costuma voltar, quem está atrasado, proteções contra spam, limite diário, janela de horário) fica no BarberFlow: **o n8n não recalcula elegibilidade e não tem base própria de clientes**. Mesma autenticação (`Bearer bf_live_...`), mesmo formato de resposta (seção 2) e `organization_id` sempre do token (qualquer `organization_id` no body/query é ignorado).

> Requer a migration `supabase/migrations/0003_reactivation.sql` aplicada manualmente. Sem ela, estes endpoints respondem `500 INTERNAL_ERROR`.

**Fluxo:** o dono clica **Reativar** (manual) ou o n8n chama `trigger` (automático, só se o modo da barbearia for *Automático*) → o pedido fica `requested` (mensagem pendente) → o n8n busca `pending`, a IA redige, o n8n envia → `sent` → cliente responde → `responded` → novo agendamento criado depois do envio → `booked` → atendimento concluído → `reactivated`. **Enviada ≠ respondeu ≠ agendou ≠ reativado.**

### GET `/reactivation/settings`
Modo (`manual`|`automatic`), margem, mínimo de atendimentos, janela de envio (`send_window.open_now`), limite diário, intervalo mínimo entre tentativas, máximo de tentativas e `capacity` (`limit`, `used`, `remaining` de hoje).

### GET `/reactivation/candidates[?limit=20]`
Quem **pode** receber reativação agora (todas as proteções já aplicadas: sem opt-out, sem campanha em andamento, sem agendamento futuro, dentro de tentativas/intervalo). Ordenado pelo maior atraso.
```json
{ "success": true, "data": {
  "mode": "automatic", "window_open": true, "can_trigger_now": true,
  "capacity": { "limit": 20, "used": 3, "remaining": 17 },
  "total_eligible": 6, "count": 6,
  "candidates": [{
    "client": { "id": "…", "name": "João", "phone": "(21) 99999-0001", "whatsapp_phone": "5521999990001" },
    "reactivation": { "reason": "behavior_due", "days_since_last_visit": 40, "habitual_interval_days": 32, "overdue_days": 8,
                      "due_after_days": 36.8, "visits": 8, "confidence": "high", "confidence_score": 85, "last_visit_date": "2026-08-23" }
  }] } }
```
`can_trigger_now` = modo automático **e** janela aberta **e** limite diário disponível.

### POST `/reactivation/:clientId/trigger`
Pedido **automático**. Revalida tudo no backend e devolve o **evento** (corpo vazio). Idempotente: repetir enquanto o pedido está pendente devolve `200` com `idempotent_replay:true`; criação nova devolve `201`.
```json
{ "success": true, "data": {
  "event": "reactivation.requested",
  "attempt": { "id": "…", "origin": "automatic", "status": "requested", "requested_at": "…" },
  "client": { "id": "…", "name": "João da Silva", "first_name": "João", "phone": "…", "whatsapp_phone": "5521999990001" },
  "reactivation": { "reason": "behavior_due", "days_since_last_visit": 40, "habitual_interval_days": 32, "overdue_days": 8,
                    "visits": 8, "confidence": "high", "last_visit_date": "2026-08-23", "calculated_at": "…" },
  "last_visit": { "date": "2026-08-23", "service_name": "Corte", "barber_name": "Carlos" },
  "business": { "name": "Barbearia X", "timezone": "America/Sao_Paulo" },
  "message_context": { "language": "pt-BR", "goal": "…", "tone": ["…"], "must_not": ["inventar preço, serviço, horário ou disponibilidade", "…"], "must_do": ["…"], "example": "…" },
  "idempotent_replay": false } }
```
Os números do bloco `reactivation` são o **snapshot** gravado no pedido. A IA não deve inventar preço, serviço, horário ou disponibilidade: ela consulta o BarberFlow (ferramentas do atendimento WhatsApp) antes de citar qualquer um.

### GET `/reactivation/pending[?limit=20]`
Pedidos (manuais **e** automáticos) aguardando envio, cada item no formato do evento acima. **Só devolve itens dentro da janela de envio**: fora dela vem `window_open:false` e `items:[]`.

### POST `/reactivation/:clientId/sent`
O n8n confirma que a mensagem foi enviada (`requested → sent`). Idempotente.

### POST `/reactivation/:clientId/failed` — `{ "reason"?: "…" }`
O envio falhou (`requested → failed`). Não conta no limite diário nem nas tentativas e libera o cliente.

### POST `/reactivation/:clientId/responded`
O cliente respondeu (`sent → responded`). Não é agendamento. Idempotente.

### POST `/reactivation/:clientId/opt-out` — `{ "note"?: "…" }`
O cliente pediu para não receber. Bloqueia **toda** reativação futura (manual e automática) e cancela pedido ainda pendente. Idempotente.

> Não existe endpoint para marcar "agendou" nem "reativado": isso é **derivado da agenda** (`appointments`). Um agendamento válido (aguardando/confirmado/concluído) criado **depois do envio** e dentro de `attribution_days` vira `booked`; quando é concluído, `reactivated`. Agendamento cancelado/no-show volta a tentativa para `sent`/`responded`. Sem agendamento no prazo → `expired`. O n8n continua criando o agendamento pelos endpoints normais (`POST /appointments`).

### Erros novos (`error`)
| HTTP | `error` | Quando |
|---|---|---|
| 409 | `AUTOMATIC_MODE_DISABLED` | `trigger` com a barbearia em modo manual |
| 409 | `OUTSIDE_SEND_WINDOW` | `trigger` fora da janela de envio |
| 429 | `DAILY_LIMIT_REACHED` | limite diário atingido |
| 409 | `NOT_ELIGIBLE` | cliente não está atrasado em relação ao próprio ritmo / histórico insuficiente |
| 409 | `OPTED_OUT` | cliente pediu para não receber |
| 409 | `ALREADY_IN_PROGRESS` | já existe campanha enviada/respondida/agendada |
| 409 | `HAS_FUTURE_APPOINTMENT` | cliente já tem agendamento futuro (configurável) |
| 409 | `MAX_ATTEMPTS_REACHED` | máximo de tentativas desde a última visita |
| 409 | `TOO_SOON_SINCE_LAST_ATTEMPT` | última tentativa recente demais |
| 409 | `DISMISSED` | dono ignorou o cliente recentemente |
| 409 | `INVALID_STATE` | transição não permitida (ex.: `responded` antes de `sent`) |
| 404 | `NO_ACTIVE_REACTIVATION` | não há reativação em andamento para o cliente |
| 404 | `CLIENT_NOT_FOUND` | cliente inexistente **ou de outra organização** |
| 422 | `CLIENT_PHONE_INVALID` | telefone do cliente não é WhatsApp válido |

### Como o comportamento é calculado
- **Visitas** = dias distintos com atendimento `completed` (cancelado, no-show e futuro nunca contam; dois atendimentos no mesmo dia são uma visita). Janela de leitura: últimos 730 dias.
- **Intervalos** = dias entre visitas consecutivas. Com 4+ intervalos descartam-se os anormais (escore z modificado por MAD > 3,5, escala mínima de 10% da mediana ou 1 dia).
- **Intervalo habitual** = **mediana** dos intervalos mantidos (ex.: 30,31,32,33,90 → 31,5; a média daria 43).
- **Elegível** = visitas ≥ `min_visits` (padrão 3, mínimo 2) **e** dias desde a última visita > habitual × (1 + `margin_percent`/100) (padrão 15%).
- **Confiança** 0–100: 1 visita = nenhuma · 2 visitas = baixa · cresce com mais intervalos e regularidade; cai com dispersão alta/outliers. Níveis: baixa < 40 ≤ média < 70 ≤ alta.
- `client_status` (ativo/em risco/perdido, por dias fixos) **continua separado** e inalterado no CRM.
