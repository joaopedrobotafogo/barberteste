# BarberFlow — Design System (front-end)

## Temas (6 paletas)
- Cores = variáveis CSS em `src/app/globals.css`, um bloco por tema: `:root`/`[data-theme="ocean"]` (padrão), `royal`, `emerald`, `sunset`, `burgundy`, `obsidian`.
- Tokens: `primary`, `primary-hover`, `primary-light`, `primary-foreground`, `sidebar`, `sidebar-foreground`, `sidebar-muted`, `sidebar-active`, `background`, `card`, `foreground`, `muted`, `muted-foreground`, `border`, `input`, `ring`, `success`, `warning`, `danger`. Valores em canais RGB (`R G B`) para aceitar opacidade (`bg-primary/10`).
- Tailwind (`tailwind.config.ts`) expõe os tokens (`bg-primary`, `text-muted-foreground`, `bg-card`...). Apelidos legados continuam valendo e apontam para os mesmos tokens: `ink→foreground`, `paper→background`, `surface→card`, `line→border`, `muted→muted-foreground`, `brass→warning`, `ok→success`.
- Catálogo (id, nome, amostras do preview): `src/lib/theme.ts`.
- **Nova paleta:** 1 item em `THEMES` + 1 bloco `[data-theme="id"]` em `globals.css`. Nenhuma página muda.
- Persistência (sem migration): `user_metadata.theme` do Supabase Auth (por usuário, vale em qualquer aparelho) + cookie `bf-theme` lido em `src/app/layout.tsx` (pinta o `<html data-theme>` no servidor, sem flash). `ThemeSync` aplica o tema do usuário em aparelho novo. Ação: `saveTheme` em `configuracoes/actions.ts`.

## Logo
Assets em `public/brand/`: `barberflow-logo.png`, `-logo-dark.png` (fundo escuro), `-mark.png`, `-mark-dark.png`. Uso sempre via `<Logo variant="full|mark" tone="light|dark" height={n} />` (`src/components/brand/logo.tsx`). `src/app/icon.png` = favicon.

## Componentes (`src/components/ui.tsx` + `ui-styles.ts`)
Button, linkButton, Input, Select, Textarea, Toggle, Switch, Sheet (modal), Toast, Avatar, Card, Badge, StatCard, IconCircle, SectionHeader, PageHeader, EmptyState, ErrorNote, ErrorState, LoadingState, Icon.
`ui-styles.ts` não é "use client": constantes/funções usadas por Server Components (`CARD`, `linkButton`) ficam lá.
