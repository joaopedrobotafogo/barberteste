# BarberFlow — CONTEXT.md

> **Aviso de origem.** O `CONTEXT.md` original **não veio** no ZIP da Etapa 10. Este arquivo foi **reconstruído** na Etapa 11 a partir do código, do schema, do `README.md`, de `docs/integration-api.md` e de `n8n/README.md`. As decisões das etapas 1–10 abaixo são o que o código e essas docs evidenciam, **não** a memória das conversas originais. Se o seu `CONTEXT.md` antigo tiver decisões que não aparecem aqui, mescle-as (e me avise se alguma contradisser o que está escrito).

SaaS multi-tenant de gestão para barbearias. Next.js 15 (App Router) + TypeScript (strict) + Tailwind 3 + Supabase (Postgres, Auth, RLS). Automação de atendimento por WhatsApp via n8n + Evolution API + OpenAI.

## 1. Princípios permanentes

1. **`appointments` é a única agenda e a fonte de verdade.** App, WhatsApp e IA usam a mesma tabela. Não existe segunda agenda, Google Calendar nem segunda base de clientes.
2. **Multi-tenant:** toda tabela de negócio tem `organization_id` + RLS. FKs compostas `(id, organization_id)` impedem referenciar dados de outra organização.
3. **BarberFlow decide, n8n executa.** O n8n não tem banco de clientes, não calcula disponibilidade nem elegibilidade; chama a API `/api/integration/*`.
4. **`organization_id` nunca vem do cliente/n8n:** na API vem do token Bearer; no app vem da sessão.
5. **Service role (`createAdminClient`) só no servidor**, sempre filtrando por `organization_id` explicitamente (ignora RLS), e só após validar dono (telas) ou token (API).
6. **Migrations são manuais** (SQL Editor do Supabase), aditivas e documentadas. Nunca executadas automaticamente.
7. Banco decide status do cliente (`client_status()` / view `client_overview`): ativo / em risco / perdido / VIP. Regra por dias fixos (`risk_after_days`=30, `lost_after_days`=60).
8. Nada de credencial real em código, JSON de workflow ou ZIP. `.env.local` nunca entra no ZIP.

## 2. Histórico das etapas (reconstruído)

| Etapa | Entregue | Evidência |
|---|---|---|
| 1 | Banco: schema, RLS, regras de agenda (exclusion constraint anti-conflito, trigger de bloqueios, trigger que gera `payments` ao concluir), `client_overview`, `create_organization_with_owner` | `supabase/migrations/0001_core_schema.sql` |
| 2 | App base, autenticação (login/cadastro/recuperação de senha), layout, permissões owner/barber, Serviços, Equipe + convite | README |
| 3 | Clientes: lista (busca, filtros, ordenação, paginação), cadastro/edição, perfil com histórico | README |
| 4 | Agenda: dia/semana, agendar/editar/remarcar, status, cancelamento, bloqueios, conflito | README |
| 5 | Início (Dashboard) | README |
| 6 | Financeiro | README |
| 7 | Relatórios | README |
| 8 | Configurações (nome, horário de funcionamento, regras de agenda e de clientes) | README |
| 9 | API de integração `/api/integration/*` com token por organização (`0002_integration_tokens.sql`), núcleo `agenda-core.ts` compartilhado com a Agenda, idempotência sem migration | README, docs |
| 10 | Workflows n8n (atendimento WhatsApp + gateway com 11 ferramentas), prompt, `GET /appointments?phone=`. **Só é "concluída" após os testes ponta a ponta com WhatsApp real (Parte 2 de `n8n/README.md`)**; este ZIP não prova que isso foi feito | n8n/README |
| 11 | **Reativação inteligente** (este documento, seção 4) | — |

Pendências antigas conhecidas (do README/docs, não tratadas na Etapa 11): seed de demonstração e testes de RLS/conflito contra banco real; reagendamento por `client_id` retornou `APPOINTMENT_NOT_FOUND` em um teste antigo (o fluxo WhatsApp usa telefone); BARBER lê agenda/clientes de toda a organização (RLS não restringe por barbeiro); sem rate limit na API.

## 3. Schema (estado após a Etapa 11)

Enums: `member_role(owner,barber)`, `appointment_status(pending,confirmed,completed,cancelled,no_show)`, `appointment_source(app,whatsapp,ai)`, `payment_method`.
Tabelas: `organizations`, `profiles`, `barbers`, `clients`, `services`, `appointments`, `time_blocks`, `payments`, `business_settings`, `integration_tokens` (0002), **`reactivation_settings`, `reactivation_attempts`, `reactivation_opt_outs` (0003)**.
View: `client_overview` (security_invoker). Funções: `set_updated_at`, `auth_org_id`, `auth_is_owner`, `client_status`, `appointments_rules`, `appointments_sync_payment`, `create_organization_with_owner`, `reactivation_attempts_guard` (0003).

**Atendimento realizado = `appointments.status = 'completed'` (e `deleted_at is null`).** Pagamento é gerado por trigger ao concluir.

> ⚠ **Achado na revisão do 0001:** `payments` declara FK composta para `appointments (id, organization_id)`, mas `appointments` **não declara** `unique (id, organization_id)` (só `clients`, `barbers`, `services` declaram). Em Postgres isso costuma falhar com "no unique constraint matching given keys". Se o seu banco real funciona, você já ajustou isso manualmente; **o arquivo do repositório pode estar divergente do banco**. Não foi alterado. A migration 0003 **não depende** dessa FK (usa FK simples + trigger para o agendamento atribuído).

## 4. Etapa 11 — Reactivation Intelligence

### 4.1 Objetivo
Identificar clientes **atrasados em relação ao próprio ritmo de retorno** (não "X dias sem vir"), registrar o pedido de reativação com todas as proteções contra spam no **backend**, e deixar tudo pronto para o n8n executar o envio. **Nenhum WhatsApp real é enviado nesta etapa.**

### 4.2 Modelo de comportamento (`src/lib/reactivation/behavior.ts`, funções puras)
1. **Visitas** = dias distintos (fuso da barbearia) com atendimento `completed`. Cancelado, no-show e futuro nunca contam; dois atendimentos no mesmo dia = 1 visita (evita intervalo 0). Leitura limitada aos últimos **730 dias**.
2. **Intervalos** = dias entre visitas consecutivas.
3. **Outliers:** com 4+ intervalos, descarta os que fogem do padrão do cliente (escore z modificado por MAD > 3,5; escala mínima = max(MAD, 10% da mediana, 1 dia), para não punir variação normal).
4. **Intervalo habitual = mediana** dos intervalos mantidos. Ex.: `30,31,32,33,90` → 90 descartado, habitual 31,5 (a média simples daria 43,2).
5. **Elegível** = `visitas ≥ min_visits` **e** `dias desde a última visita > habitual × (1 + margem/100)`.
6. **Confiança (0–100):** 1 visita = nenhuma; base por nº de intervalos (1→30, 2→50, 3→60, 4→70, 5+→80) ± dispersão relativa robusta (+15 / +5 / 0 / −15) − 5 por outlier descartado (máx. −15), teto 95. Níveis: baixa < 40 ≤ média < 70 ≤ alta.
7. **Atraso** = dias desde a última visita − habitual (negativo = ainda no ritmo).
8. Sem histórico suficiente **nada é inventado**: `habitual`/`due_after` ficam `null` com 1 visita; comportamento só é "conhecido" com `visitas ≥ min_visits`.

Padrões aprovados: **mín. 3 atendimentos** (configurável de 2 a 50; 1 nunca basta), **margem 15%**, **20 envios/dia**, **30 dias** entre tentativas, **3 tentativas**, janela **09:00–19:00** no fuso da organização (independente de `opening_hours`), bloquear quem tem agendamento futuro (ligado), prazo de atribuição **14 dias** (extra, necessário para medir o resultado).

`client_status` (ativo/em risco/perdido) **continua separado e inalterado**; a lista antiga "Ver em risco/Ver perdidos" segue no CRM.

### 4.3 Estados (persistidos em `reactivation_attempts.status`)
`requested` (mensagem pendente) → `sent` (enviada) → `responded` (respondeu) → `booked` (agendou) → `reactivated` (voltou e o atendimento foi **concluído**). Encerramentos: `failed`, `cancelled`, `expired`, `dismissed` (dono ignorou). **"Candidato" não é gravado:** é calculado na hora.

**Enviada ≠ respondeu ≠ agendou ≠ reativado**, contados separadamente nas métricas.

Reconciliação com a agenda (`reconcileOutcomes`, idempotente, roda ao carregar o Dashboard/`/reativacao`, `candidates` e `pending`): agendamento válido (pendente/confirmado/concluído) **criado depois do envio** e até `attribution_days` depois → `booked`; esse agendamento concluído → `reactivated`; agendamento cancelado/no-show/removido → volta a `sent`/`responded`; sem agendamento no prazo → `expired`.

### 4.4 Proteções (backend, uma única função `blockReason` para lista, manual e automático)
Opt-out (sempre) · campanha em andamento (sempre; **índice único parcial no banco**: 1 tentativa aberta por cliente) · elegibilidade atual · cliente ignorado · agendamento futuro (configurável) · máximo de tentativas **desde a última visita** (depois que o cliente volta, o contador recomeça) · intervalo mínimo desde a última tentativa · limite diário (dia local; `failed`/`cancelled`/`dismissed` não contam) · no automático: modo *Automático* e janela de envio. Pedido repetido enquanto `requested` é idempotente (replay). Pedido manual fora da janela é aceito (fica pendente); o `/pending` só entrega dentro da janela.

### 4.5 Modo manual × automático (por organização, `reactivation_settings.mode`)
Mesmo service (`src/lib/reactivation/service.ts`), mesma elegibilidade, mesmas proteções, mesmo registro, mesma API/evento. Diferença: **manual** = dono clica **Reativar** (Server Action, `origin='manual'`); **automático** = n8n chama `trigger` (`origin='automatic'`), recusado com `AUTOMATIC_MODE_DISABLED` se a barbearia estiver em modo manual. Em ambos, o n8n entrega os pendentes via `GET /pending`.

### 4.6 Arquivos
Novos: `supabase/migrations/0003_reactivation.sql`; `src/lib/reactivation/{behavior,settings,service,integration,owner,view}.ts`; `src/app/api/integration/reactivation/**/route.ts` (8 rotas); `src/app/(app)/reativacao/{page.tsx,actions.ts}`; `src/components/{reactivation,reactivation-list}.tsx`; `scripts/test-reactivation.ts`; `n8n/barberflow-reactivation.workflow.json`; `n8n/reactivation-prompt.md`; `CONTEXT.md`.
Modificados (aditivos): `src/lib/integration/http.ts` (novos códigos de erro), `src/components/dashboard.tsx` (dono vê a nova seção; barbeiro mantém a lista antiga), `src/components/settings.tsx`, `src/app/(app)/configuracoes/{page,actions}.ts(x)`, `package.json` (scripts `test:integration`, `test:reactivation`), `README.md`, `docs/integration-api.md` (seção 8), `n8n/README.md`.
**Não alterados:** 0001/0002, `client_status`/`client_overview`, `ops.ts`, `auth.ts`, rotas existentes, workflows `barberflow-whatsapp`/`barberflow-gateway`, `scripts/test-integration.ts`.

### 4.7 API (`/api/integration/reactivation/*`, mesma auth Bearer; ver `docs/integration-api.md` §8)
`GET settings` · `GET candidates` · `GET pending` · `POST :clientId/trigger` · `POST :clientId/sent` · `POST :clientId/failed` · `POST :clientId/responded` · `POST :clientId/opt-out`. (Além dos 5 sugeridos, `pending`, `sent` e `failed` são necessários para o manual funcionar e para o n8n confirmar o envio.)

### 4.8 Como aplicar a migration (NÃO foi aplicada)
1. Backup/snapshot do projeto Supabase (boa prática; a migration é aditiva).
2. Confirme que `0001` e `0002` já estão aplicadas.
3. SQL Editor → cole e execute **uma vez** `supabase/migrations/0003_reactivation.sql`.
4. Verifique: `select count(*) from reactivation_settings;` (= nº de barbearias). Teste Configurações → "Reativação de clientes".
Sem a migration: o resto do app funciona; a seção de reativação do Início mostra estado de erro e Configurações mostra aviso. Requer `SUPABASE_SERVICE_ROLE_KEY` no servidor (a mesma da API de integração).

### 4.9 n8n (preparado, travado)
`n8n/barberflow-reactivation.workflow.json`: Ramo A (modo Automático → candidatos → `trigger`) e Ramo B (pendentes → IA → trava de segurança → Evolution **não conectada** → `sent`/`failed`). `REACTIVATION_SEND_ENABLED="false"` no nó Config mantém o Ramo B desligado (nada enviado, IA não chamada). Sem tokens/chaves no arquivo (só nomes de credenciais). Não importado em n8n real.

### 4.10 Testes executados (neste ambiente)
| Verificação | Resultado |
|---|---|
| `npm run typecheck` | limpo |
| `npm run lint` | sem avisos/erros |
| `npx tsx scripts/test-integration.ts` | **66 ok, 0 falhas** (igual ao baseline) |
| `npx tsx scripts/test-reactivation.ts` | **70 ok, 0 falhas, 2 SKIP** (abaixo) |
| Mutação (paginação quebrada de propósito) | o teste correspondente falhou, como deve |

Cobertura de `test-reactivation.ts` (itens do enunciado): 1–7 comportamento (1/2/3+ atendimentos, regular, outlier, dentro do ritmo, atrasado, margem, mesmo dia, futuro, fuso); 8 agendamento futuro; 9 opt-out; 10 limite diário; 11 intervalo mínimo e máximo de tentativas; 12 já reativado; 13 enviada sem agendamento; 14 agendamento após campanha (+ cancelado, antes do envio, fora do prazo, idempotência); 15 isolamento por `organization_id` (pedir, enviar, responder, opt-out, cancelar, reconciliar, limite, configuração, FK); 16 manual; 17 automático; 18 persistência; 19 recarga **em nível de service**; API (`api*`) e **401 em todas as 8 rotas** sem token válido (inclui `organization_id`/token em query/header ignorados); validação de configurações.

O banco do teste é **em memória** e emula as constraints do 0003; **não executa SQL real**.

### 4.11 NÃO verificado neste ambiente (não afirmar como feito)
- **Item 19 no navegador (reload/F5)** e **item 20 (mobile):** exigem navegador/dispositivo + Supabase real. Só foram verificados persistência/reavaliação em nível de service e, por revisão de código, o uso de classes responsivas (alvos de toque de 44px, métricas em grade 3 colunas, botões em largura total no celular, lista em cartões). **Faça manualmente** (checklist abaixo).
- **`next build`:** falhou aqui **apenas** porque o sandbox não acessa o Google Fonts (`next/font` baixa a Inter); typecheck e lint passam. Rode `npm run build` na sua máquina.
- Migration 0003 em Postgres real; RLS real; workflows no n8n real; Evolution API.

**Checklist manual sugerido (você):** aplicar 0003 → Configurações: salvar regras, recarregar a página e conferir que persistiram (incl. modo) → ter 3+ clientes com atendimentos `completed` regulares e um atrasado → Início (celular e desktop): ver o cartão, **Reativar**, ver "Mensagem pendente", recarregar (F5) e conferir que persiste, **Cancelar pedido** → **Ignorar** → logar como BARBER (não vê a seção nova; vê a lista antiga) → conferir que o n8n/token de outra barbearia não vê nada.

### 4.12 Interpretações e decisões a conhecer
- **"Reativado" = o atendimento do agendamento foi concluído** (não basta agendar). Agendou = `booked`. Constante `REACTIVATED_REQUIRES_COMPLETED` em `service.ts`; mudar para "agendou já é reativado" é pequeno, mas altera as métricas.
- **Atribuição por `created_at`:** agendamento criado após o `sent_at` e dentro de `attribution_days` (qualquer origem: app, WhatsApp, IA).
- **"Respondeu" só é registrado se o n8n chamar `/responded`.** Hoje o atendimento WhatsApp **ainda não faz isso** (nem `/opt-out`): o contador de respostas ficará subestimado e opt-out por mensagem só funcionará depois dessa alteração. Agendou/reativado já são derivados da agenda.
- Com a margem de 15%, o exemplo "Carlos: 51 dias, habitual 45" **não** entra (limite = 51,75). Os exemplos do enunciado eram ilustrativos; ajuste a margem se quiser.
- **Dashboard do dono:** a lista antiga por `at_risk/lost` foi substituída pela nova seção (os links "Ver em risco/perdidos" continuam). BARBER continua vendo a lista antiga (reativação é ação do dono).
- Acesso às tabelas de reativação **só pelo servidor (service role)**; RLS dá apenas SELECT ao dono (defesa em profundidade). O dono autentica por `requireOwner()`.
- Candidatos incluem somente quem **pode** receber agora (proteções aplicadas); limite diário e janela são checados no clique/trigger (pode haver erro amigável se estourar).
- Por segurança de privacidade, o evento ao n8n **não** inclui `organization_id`.

### 4.13 Limitações
- Cada carregamento do Dashboard lê clientes + atendimentos concluídos (730 dias) da organização, paginando de 1000 em 1000. Funciona para barbearias pequenas/médias; para volumes grandes, mover o cálculo para uma view/função SQL.
- Limite diário: checagem-e-insere (sem trava transacional): requisições simultâneas no limite podem exceder por 1–2 pedidos. A campanha única por cliente **é** garantida pelo banco.
- Sem UI para revogar opt-out (a coluna `revoked_at` existe; revogar hoje é manual no SQL).
- Sem push do BarberFlow para o n8n: o n8n **puxa** (`pending`) a cada 15 min; latência de até 15 min entre o clique e o envio. Um webhook de saída é um próximo passo possível.
- Só números brasileiros; um cliente por telefone (já era assim).
- `payments` pode refletir o achado do 0001 (seção 3).

### 4.14 Próximo passo recomendado
1. Aplicar a `0003` e rodar o checklist manual (inclui reload e celular, que não pude verificar).
2. **Etapa 12:** (a) alterar o atendimento WhatsApp para chamar `/responded` e `/opt-out` quando o cliente responder à reativação (usar `last_visit`/contexto da tentativa); (b) conectar a Evolution API real ao workflow de reativação (credenciais só no n8n), ligar `REACTIVATION_SEND_ENABLED` e validar ponta a ponta com 1 cliente de teste; (c) opcional: webhook de saída em vez de polling.


## Etapa 12 — Redesign do front-end (somente visual)
Novo design system com 6 paletas (Ocean, Royal, Emerald, Sunset, Burgundy, Obsidian) escolhidas em Configurações → Aparência; logo oficial em `public/brand`; sidebar/topbar/login/dashboard/reativação/configurações redesenhados; demais telas herdam os tokens. **Sem alteração de banco, API, RLS, regras ou workflows.** Tema persistido em `auth.users.raw_user_meta_data.theme` + cookie `bf-theme`. Detalhes em `docs/design-system.md`.
