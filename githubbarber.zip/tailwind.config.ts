import type { Config } from "tailwindcss";

/** Cor = variável CSS (canais RGB) definida em globals.css por tema. */
const v = (name: string) => `rgb(var(--${name}) / <alpha-value>)`;

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        // ---- tokens do design system ----
        primary: { DEFAULT: v("primary"), hover: v("primary-hover"), light: v("primary-light"), foreground: v("primary-foreground") },
        sidebar: {
          DEFAULT: v("sidebar"), foreground: v("sidebar-foreground"), muted: v("sidebar-muted"),
          active: v("sidebar-active"), "active-foreground": v("sidebar-active-foreground"),
        },
        background: v("background"),
        card: v("card"),
        foreground: v("foreground"),
        "muted-bg": v("muted"),
        "muted-foreground": v("muted-foreground"),
        border: v("border"),
        input: v("input"),
        ring: v("ring"),
        success: v("success"),
        warning: v("warning"),
        danger: v("danger"),
        // ---- apelidos legados (o código antigo usa estes nomes; apontam para os mesmos tokens) ----
        ink: v("foreground"),
        paper: v("background"),
        surface: v("card"),
        line: v("border"),
        muted: v("muted-foreground"),
        brass: v("warning"),
        ok: v("success"),
      },
      fontFamily: { sans: ["var(--font-inter)", "system-ui", "sans-serif"] },
      boxShadow: {
        card: "0 1px 2px rgb(var(--foreground) / 0.04), 0 4px 16px -6px rgb(var(--foreground) / 0.08)",
        pop: "0 12px 32px -8px rgb(var(--foreground) / 0.22)",
      },
      borderRadius: { "2xl": "1rem", "3xl": "1.5rem" },
    },
  },
  plugins: [],
};
export default config;
