// @ts-nocheck — script de teste com banco fake; fora do typecheck/build do app de propósito.
/**
 * Testes de LÓGICA da API de integração (Etapa 9), sem rede e sem Supabase real.
 * Rodam as operações reais (src/lib/integration/ops.ts + src/lib/agenda-core.ts) contra um banco em memória
 * que EMULA as regras do schema: appointments_no_overlap (23P01), unicidade de telefone (23505),
 * trigger de bloqueio (P0001), filtros eq/in/is/lt/gt/neq.
 *
 *   npx tsx scripts/test-integration.ts
 *
 * Não substitui o teste ponta a ponta com o Supabase real (veja docs/integration-api.md, seção "Testes").
 */
import { randomUUID } from "node:crypto";
import { bearerToken, hashToken } from "../src/lib/integration/auth";
import { parseBrPhone } from "../src/lib/integration/phone";
import { ApiError } from "../src/lib/integration/http";
import {
  cancelAppointment, createAppointment, createClientIdempotent, getAppointment, getAvailability,
  getBusiness, getClientByPhone, listAppointments, listBarbers, listServices, rescheduleAppointment,
} from "../src/lib/integration/ops";
import { addDays, todayIn, weekdayOf } from "../src/lib/agenda";

// ------------------------------------------------------------------ banco em memória
type Row = Record<string, any>;
const T: Record<string, Row[]> = {
  organizations: [], business_settings: [], barbers: [], clients: [], services: [], appointments: [], time_blocks: [],
};
let seq = 0;
const tbl = (n: string) => (n === "client_overview" ? T.clients : T[n]);
const err = (code: string, message: string) => ({ code, message });
const rng = (r: Row) => [Date.parse(r.start_at), Date.parse(r.end_at)] as const;
const overlap = (a: Row, b: Row) => { const [s1, e1] = rng(a), [s2, e2] = rng(b); return s1 < e2 && s2 < e1; };
const ACTIVE = ["pending", "confirmed", "completed"];

function checkConstraints(table: string, row: Row, self?: Row): { code: string; message: string } | null {
  if (table === "clients") {
    row.phone_normalized = String(row.phone).replace(/\D/g, "");
    if (T.clients.some((c) => c !== self && !c.deleted_at && c.organization_id === row.organization_id && c.phone_normalized === row.phone_normalized))
      return err("23505", "duplicate key");
  }
  if (table === "appointments") {
    const live = ACTIVE.includes(row.status) && !row.deleted_at && !row.is_overbook;
    if (live) {
      if (T.time_blocks.some((b) => !b.deleted_at && b.barber_id === row.barber_id && overlap(b, row))) return err("P0001", "Horário bloqueado para este barbeiro");
      if (T.appointments.some((a) => a !== self && ACTIVE.includes(a.status) && !a.deleted_at && !a.is_overbook && a.barber_id === row.barber_id && overlap(a, row)))
        return err("23P01", "conflicting key value violates exclusion constraint");
    }
  }
  return null;
}

class Q implements PromiseLike<any> {
  private f: ((r: Row) => boolean)[] = [];
  private op: "select" | "insert" | "update" = "select";
  private payload: any; private lim?: number; private ord?: [string, boolean]; private single = false;
  constructor(private table: string) {}
  select() { return this; }
  insert(p: any) { this.op = "insert"; this.payload = p; return this; }
  update(p: any) { this.op = "update"; this.payload = p; return this; }
  eq(c: string, v: any) { this.f.push((r) => r[c] === v); return this; }
  neq(c: string, v: any) { this.f.push((r) => r[c] !== v); return this; }
  in(c: string, v: any[]) { this.f.push((r) => v.includes(r[c])); return this; }
  is(c: string, v: null) { this.f.push((r) => (r[c] ?? null) === v); return this; }
  lt(c: string, v: any) { this.f.push((r) => Date.parse(r[c]) < Date.parse(v)); return this; }
  gt(c: string, v: any) { this.f.push((r) => Date.parse(r[c]) > Date.parse(v)); return this; }
  order(c: string, o?: { ascending?: boolean }) { this.ord = [c, o?.ascending ?? true]; return this; }
  limit(n: number) { this.lim = n; return this; }
  maybeSingle() { this.single = true; return this; }
  then<A, B>(ok?: (v: any) => A, ko?: (e: any) => B) { return Promise.resolve(this.run()).then(ok, ko); }
  private run() {
    const rows = tbl(this.table);
    const match = () => rows.filter((r) => this.f.every((fn) => fn(r)));
    if (this.op === "insert") {
      const row: Row = { id: randomUUID(), created_at: new Date(Date.now() + ++seq).toISOString(), deleted_at: null, ...this.payload };
      if (this.table === "services" || this.table === "barbers") row.is_active ??= true;
      const bad = checkConstraints(this.table, row);
      if (bad) return { data: null, error: bad };
      rows.push(row);
      return { data: [{ ...row }], error: null };
    }
    if (this.op === "update") {
      const hit = match();
      for (const r of hit) {
        const next = { ...r, ...this.payload };
        const bad = checkConstraints(this.table, next, r);
        if (bad) return { data: null, error: bad };
      }
      hit.forEach((r) => Object.assign(r, this.payload));
      return { data: hit.map((r) => ({ ...r })), error: null };
    }
    let out = match().map((r) => ({ ...r }));
    if (this.table === "client_overview") out = out.filter((r) => !r.deleted_at).map((r) => ({ ...r, status: r.status ?? "active" }));
    if (this.ord) { const [c, asc] = this.ord; out.sort((a, b) => (a[c] < b[c] ? -1 : 1) * (asc ? 1 : -1)); }
    if (this.lim !== undefined) out = out.slice(0, this.lim);
    return this.single ? { data: out[0] ?? null, error: null } : { data: out, error: null };
  }
}
const db: any = { from: (t: string) => new Q(t) };

// ------------------------------------------------------------------ cenário
const ORG_A = randomUUID(), ORG_B = randomUUID();
const ctxA = { db, orgId: ORG_A, tokenId: "t" }; const ctxB = { db, orgId: ORG_B, tokenId: "t" };
const hrs = (open: string, close: string) => ({ open, close });
const HOURS = { mon: hrs("08:00", "18:00"), tue: hrs("08:00", "18:00"), wed: hrs("08:00", "18:00"), thu: hrs("08:00", "18:00"), fri: hrs("08:00", "18:00"), sat: hrs("08:00", "13:00"), sun: null };
const mk = (table: string, row: Row) => { const r = { id: randomUUID(), created_at: new Date(Date.now() + ++seq).toISOString(), deleted_at: null, is_active: true, ...row }; T[table].push(r); return r; };

T.organizations.push({ id: ORG_A, name: "Barbearia A", phone: "(21) 3000-0000", address: "Rua A", deleted_at: null }, { id: ORG_B, name: "Barbearia B", deleted_at: null });
const settingsA = mk("business_settings", { organization_id: ORG_A, timezone: "America/Sao_Paulo", opening_hours: HOURS, slot_interval_minutes: 30, min_notice_minutes: 0, allow_overbooking: false });
mk("business_settings", { organization_id: ORG_B, timezone: "America/Sao_Paulo", opening_hours: HOURS, slot_interval_minutes: 30, min_notice_minutes: 0 });
const joao = mk("barbers", { organization_id: ORG_A, name: "João" });
const pedro = mk("barbers", { organization_id: ORG_A, name: "Pedro" });
const inativo = mk("barbers", { organization_id: ORG_A, name: "Inativo", is_active: false });
const barberB = mk("barbers", { organization_id: ORG_B, name: "Zé (outra barbearia)" });
const corte = mk("services", { organization_id: ORG_A, name: "Corte", price: 35, duration_minutes: 30 });
const combo = mk("services", { organization_id: ORG_A, name: "Corte + Barba", price: 55, duration_minutes: 60 });
const antigo = mk("services", { organization_id: ORG_A, name: "Antigo", price: 10, duration_minutes: 30, is_active: false });
const svcB = mk("services", { organization_id: ORG_B, name: "Serviço B", price: 99, duration_minutes: 30 });

const tz = "America/Sao_Paulo";
let wed = addDays(todayIn(tz), 7); while (weekdayOf(wed) !== 3) wed = addDays(wed, 1);
const sun = addDays(wed, 4);
const sat = addDays(wed, 3);

// ------------------------------------------------------------------ runner
let pass = 0, fail = 0;
const t = async (name: string, fn: () => Promise<void> | void) => {
  try { await fn(); pass++; console.log(`  ok   ${name}`); }
  catch (e) { fail++; console.log(`  FAIL ${name}\n       ${e instanceof Error ? e.message : e}`); }
};
const eq = (a: unknown, b: unknown, m = "") => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m} esperado ${JSON.stringify(b)} obtido ${JSON.stringify(a)}`); };
const truthy = (v: unknown, m: string) => { if (!v) throw new Error(m); };
async function rejects(p: Promise<unknown>, status: number, code: string) {
  try { await p; } catch (e) {
    if (!(e instanceof ApiError)) throw new Error(`erro inesperado: ${e}`);
    if (e.status !== status || e.code !== code) throw new Error(`esperado ${status} ${code}, obtido ${e.status} ${e.code}`);
    return;
  }
  throw new Error(`esperado erro ${status} ${code}, mas teve sucesso`);
}
const slotsOf = async (service: string, barber: string, date: string, ctx = ctxA) =>
  (await getAvailability(ctx, { serviceId: service, barberId: barber, date })).barbers[0].slots;
const book = (o: Record<string, unknown>) => createAppointment(ctxA, { service_id: corte.id, barber_id: joao.id, date: wed, time: "09:00", source: "whatsapp", ...o });

async function main() {
  console.log("\n# 1-3 Autenticação (parsing/hash do token)");
  const good = "bf_live_" + "a".repeat(64);
  await t("sem header -> null", () => eq(bearerToken(null), null));
  await t("formato inválido -> null", () => { eq(bearerToken("Bearer abc"), null); eq(bearerToken("Basic " + good), null); eq(bearerToken(good), null); });
  await t("token válido é extraído; hash SHA-256 de 64 hex", () => { eq(bearerToken(`Bearer ${good}`), good); truthy(/^[0-9a-f]{64}$/.test(hashToken(good)), "hash"); });

  console.log("\n# Telefone");
  await t("21999999999 e 5521999999999 -> mesmas variantes", () => {
    const a = parseBrPhone("21999999999")!, b = parseBrPhone("+55 (21) 99999-9999")!;
    eq(a.whatsapp, "5521999999999"); eq(b.national, "21999999999"); eq(a.display, "(21) 99999-9999");
    truthy(a.variants.includes("21999999999") && a.variants.includes("5521999999999") && a.variants.includes("2199999999") , "variantes");
  });
  await t("DDD 55 (RS) de 11 dígitos não é confundido com DDI", () => eq(parseBrPhone("55999999999")!.national, "55999999999"));
  await t("inválidos", () => { for (const x of ["123", "0999999999", "21899999999", "", null, "abc"]) eq(parseBrPhone(x), null, String(x)); });

  console.log("\n# 4-5 Organização, serviços e barbeiros");
  await t("business traz fuso/horários/now da organização do token", async () => {
    const b = await getBusiness(ctxA); eq(b.name, "Barbearia A"); eq(b.timezone, tz); eq(b.opening_hours.sun, null); eq(b.opening_hours.mon, hrs("08:00", "18:00"));
  });
  await t("serviços: só ativos da própria organização", async () => {
    const s = await listServices(ctxA); eq(s.map((x) => x.name).sort(), ["Corte", "Corte + Barba"]);
    eq(Object.keys(s[0]).sort(), ["description", "duration_minutes", "id", "name", "price"]);
  });
  await t("barbeiros: só ativos da própria organização, só id+nome", async () => {
    const b = await listBarbers(ctxA); eq(b.map((x) => x.name).sort(), ["João", "Pedro"]); eq(Object.keys(b[0]).sort(), ["id", "name"]);
  });

  console.log("\n# 6-9 Clientes");
  await t("cliente inexistente -> 404 CLIENT_NOT_FOUND (GET não cria)", async () => {
    await rejects(getClientByPhone(ctxA, "5521988887777"), 404, "CLIENT_NOT_FOUND"); eq(T.clients.length, 0);
  });
  await t("telefone inválido -> 400", () => rejects(getClientByPhone(ctxA, "123"), 400, "INVALID_INPUT"));
  let ana: any;
  await t("cria cliente: salva no formato do app, devolve whatsapp_phone", async () => {
    const r = await createClientIdempotent(ctxA, { name: "Ana", phone: "5521988887777" });
    eq(r.created, true); eq(r.client.phone, "(21) 98888-7777"); eq(r.client.whatsapp_phone, "5521988887777"); ana = r.client;
  });
  await t("não duplica: mesmo telefone em outro formato devolve o existente", async () => {
    for (const p of ["21988887777", "(21) 98888-7777", "+55 21 98888-7777"]) {
      const r = await createClientIdempotent(ctxA, { name: "Ana 2", phone: p }); eq(r.created, false); eq(r.client.id, ana.id);
    }
    eq(T.clients.length, 1);
  });
  await t("duas criações simultâneas -> 1 cliente só", async () => {
    const [a, b] = await Promise.all([1, 2].map(() => createClientIdempotent(ctxA, { name: "Beto", phone: "21977776666" })));
    eq(a.client.id, b.client.id); eq(T.clients.filter((c) => c.phone_normalized === "21977776666").length, 1);
  });
  await t("busca tolerante: cliente antigo salvo COM 55 é achado por número sem 55 (e vice-versa)", async () => {
    mk("clients", { organization_id: ORG_A, name: "Antigo55", phone: "5521955554444", phone_normalized: "5521955554444" });
    eq((await getClientByPhone(ctxA, "21955554444")).name, "Antigo55");
    eq((await getClientByPhone(ctxA, "5521988887777")).id, ana.id);
  });
  await t("nome obrigatório", () => rejects(createClientIdempotent(ctxA, { phone: "21999990000" }), 400, "INVALID_INPUT"));

  console.log("\n# 10-13 Disponibilidade");
  await t("quarta, serviço 30 min: 08:00..17:30 de 30 em 30", async () => {
    const s = await slotsOf(corte.id, joao.id, wed); eq(s[0], "08:00"); eq(s[s.length - 1], "17:30"); eq(s.length, 20);
  });
  await t("serviço 60 min: 17:30 NÃO aparece; 17:00 aparece", async () => {
    const s = await slotsOf(combo.id, joao.id, wed); truthy(!s.includes("17:30"), "17:30 não pode"); truthy(s.includes("17:00"), "17:00 deve"); eq(s.length, 19);
  });
  await t("domingo (dia fechado): closed=true e sem horários", async () => {
    const r = await getAvailability(ctxA, { serviceId: corte.id, barberId: joao.id, date: sun }); eq(r.closed, true); eq(r.barbers[0].slots, []);
  });
  await t("sábado fecha 13:00: 60 min só até 12:00", async () => {
    const s = await slotsOf(combo.id, joao.id, sat); eq(s[s.length - 1], "12:00");
  });
  await t("sem barber_id: devolve todos os barbeiros ativos", async () => {
    const r = await getAvailability(ctxA, { serviceId: corte.id, barberId: null, date: wed }); eq(r.barbers.map((b) => b.name).sort(), ["João", "Pedro"]);
  });
  await t("serviço inativo / de outra organização / barbeiro inativo / de outra org -> 404", async () => {
    await rejects(getAvailability(ctxA, { serviceId: antigo.id, barberId: joao.id, date: wed }), 404, "SERVICE_NOT_FOUND");
    await rejects(getAvailability(ctxA, { serviceId: svcB.id, barberId: joao.id, date: wed }), 404, "SERVICE_NOT_FOUND");
    await rejects(getAvailability(ctxA, { serviceId: corte.id, barberId: inativo.id, date: wed }), 404, "BARBER_NOT_FOUND");
    await rejects(getAvailability(ctxA, { serviceId: corte.id, barberId: barberB.id, date: wed }), 404, "BARBER_NOT_FOUND");
  });
  await t("parâmetros inválidos -> 400", async () => {
    await rejects(getAvailability(ctxA, { serviceId: "x", barberId: null, date: wed }), 400, "INVALID_INPUT");
    await rejects(getAvailability(ctxA, { serviceId: corte.id, barberId: null, date: "2026-13-40" }), 400, "INVALID_INPUT");
  });

  console.log("\n# 14-16 Criação, conflito, consulta");
  let a1: any;
  await t("cria agendamento 10:00 (source=whatsapp, status confirmed, preço do serviço)", async () => {
    const r = await book({ phone: "21988887777", time: "10:00" });
    eq(r.replay, false); a1 = r.appointment;
    eq(a1.status, "confirmed"); eq(a1.source, "whatsapp"); eq(a1.date, wed); eq(a1.time, "10:00"); eq(a1.end_time, "10:30"); eq(a1.price, 35); eq(a1.client.name, "Ana");
    const row = T.appointments.find((x) => x.id === a1.id)!; eq(row.organization_id, ORG_A); eq(row.is_overbook, false); eq(row.created_by, null);
  });
  await t("10:00 sumiu da disponibilidade; 09:30 e 10:30 continuam (serviço 30)", async () => {
    const s = await slotsOf(corte.id, joao.id, wed); truthy(!s.includes("10:00"), "10:00"); truthy(s.includes("09:30") && s.includes("10:30"), "vizinhos");
  });
  await t("serviço 60 min: 09:30 e 10:00 somem (sobrepõem), 09:00 e 10:30 ficam", async () => {
    const s = await slotsOf(combo.id, joao.id, wed); truthy(!s.includes("09:30") && !s.includes("10:00"), "sobrepostos"); truthy(s.includes("09:00") && s.includes("10:30"), "livres");
  });
  await t("OUTRO barbeiro continua livre às 10:00", async () => truthy((await slotsOf(corte.id, pedro.id, wed)).includes("10:00"), "Pedro"));
  await t("conflito: outro cliente no mesmo horário -> 409 TIME_UNAVAILABLE e nada é criado", async () => {
    const before = T.appointments.length;
    await rejects(book({ phone: "21977776666", time: "10:00" }), 409, "TIME_UNAVAILABLE"); eq(T.appointments.length, before);
  });
  await t("conflito por duração: combo 60 min às 09:30 invade o 10:00 -> 409", () => rejects(book({ phone: "21977776666", service_id: combo.id, time: "09:30" }), 409, "TIME_UNAVAILABLE"));
  await t("concorrência: disponibilidade dizia livre, mas o banco barra (corrida simulada) -> 409", async () => {
    const free = (await slotsOf(corte.id, joao.id, wed)).includes("11:00"); truthy(free, "11:00 livre");
    // outro canal (Agenda) ocupa 11:00 entre a consulta e a criação
    mk("appointments", { organization_id: ORG_A, client_id: ana.id, barber_id: joao.id, service_id: corte.id, start_at: new Date(Date.parse(a1.start_at) + 3600_000).toISOString(), end_at: new Date(Date.parse(a1.end_at) + 3600_000).toISOString(), status: "confirmed", is_overbook: false, price: 35 });
    await rejects(book({ phone: "21977776666", time: "11:00" }), 409, "TIME_UNAVAILABLE");
  });
  await t("bloqueio de horário (time_blocks) tira o slot e barra a criação", async () => {
    const s = new Date(Date.parse(a1.start_at) + 3 * 3600_000), e = new Date(s.getTime() + 1800_000);
    mk("time_blocks", { organization_id: ORG_A, barber_id: joao.id, start_at: s.toISOString(), end_at: e.toISOString() });
    truthy(!(await slotsOf(corte.id, joao.id, wed)).includes("13:00"), "13:00 bloqueado");
    await rejects(book({ phone: "21977776666", time: "13:00" }), 409, "TIME_UNAVAILABLE");
  });
  await t("IDEMPOTÊNCIA: repetir a mesma criação devolve o mesmo agendamento (200, replay) sem duplicar", async () => {
    const before = T.appointments.length;
    const r = await book({ phone: "21988887777", time: "10:00" }); eq(r.replay, true); eq(r.appointment.id, a1.id); eq(T.appointments.length, before);
  });
  await t("IDEMPOTÊNCIA com requisições simultâneas: 1 agendamento, ambas com sucesso", async () => {
    const before = T.appointments.length;
    const [x, y] = await Promise.all([1, 2].map(() => book({ phone: "21977776666", time: "15:00" })));
    eq(x.appointment.id, y.appointment.id); eq(T.appointments.length, before + 1); eq([x.replay, y.replay].sort(), [false, true]);
  });
  await t("horário fora do funcionamento (07:30 / 17:30 com 60 min) -> 409 OUTSIDE_BUSINESS_HOURS", async () => {
    await rejects(book({ phone: "21988887777", time: "07:30" }), 409, "OUTSIDE_BUSINESS_HOURS");
    await rejects(book({ phone: "21988887777", service_id: combo.id, time: "17:30" }), 409, "OUTSIDE_BUSINESS_HOURS");
    await rejects(book({ phone: "21988887777", time: "09:10" }), 409, "OUTSIDE_BUSINESS_HOURS"); // fora da grade de 30 min
  });
  await t("dia fechado -> 409 BUSINESS_CLOSED", () => rejects(book({ phone: "21988887777", date: sun }), 409, "BUSINESS_CLOSED"));
  await t("horário no passado -> 409 TOO_SOON", async () => {
    let past = addDays(todayIn(tz), -1); while (weekdayOf(past) === 0) past = addDays(past, -1);
    await rejects(book({ phone: "21988887777", date: past }), 409, "TOO_SOON");
  });
  await t("antecedência mínima configurada é respeitada -> 409 TOO_SOON", async () => {
    settingsA.min_notice_minutes = 60 * 24 * 60; // 60 dias
    try { await rejects(book({ phone: "21988887777", time: "16:00" }), 409, "TOO_SOON"); } finally { settingsA.min_notice_minutes = 0; }
  });
  await t("cliente inexistente na criação -> 404 (não cria cliente)", async () => {
    const n = T.clients.length; await rejects(book({ phone: "21911112222" }), 404, "CLIENT_NOT_FOUND"); eq(T.clients.length, n);
  });
  await t("validações do body -> 400", async () => {
    await rejects(createAppointment(ctxA, { service_id: corte.id, barber_id: joao.id, date: wed, time: "9h", phone: "21988887777" }), 400, "INVALID_INPUT");
    await rejects(createAppointment(ctxA, { service_id: corte.id, barber_id: joao.id, date: wed, time: "10:00" }), 400, "INVALID_INPUT"); // sem cliente
    await rejects(book({ phone: "21988887777", source: "app" }), 400, "INVALID_INPUT");
  });
  await t("consulta de agendamento", async () => {
    const g = await getAppointment(ctxA, a1.id, {}); eq(g.id, a1.id); eq(g.client.name, "Ana"); eq(g.service.name, "Corte"); eq(g.barber.name, "João"); eq(g.time, "10:00");
    eq(Object.keys(g).sort(), ["barber", "client", "date", "end_at", "end_time", "id", "notes", "price", "service", "source", "start_at", "status", "time"]);
  });

  console.log("\n# 17 Cancelamento");
  await t("cliente errado não cancela (404, igual a não existir)", async () => {
    const outro = (await getClientByPhone(ctxA, "21977776666")).id;
    await rejects(cancelAppointment(ctxA, a1.id, { client_id: outro }), 404, "APPOINTMENT_NOT_FOUND");
    await rejects(cancelAppointment(ctxA, a1.id, { phone: "21977776666" }), 404, "APPOINTMENT_NOT_FOUND");
  });
  await t("sem client_id/phone -> 400", () => rejects(cancelAppointment(ctxA, a1.id, {}), 400, "INVALID_INPUT"));
  await t("dono cancela (por telefone com 55): status cancelled e horário volta a ficar livre", async () => {
    const r = await cancelAppointment(ctxA, a1.id, { phone: "5521988887777" }); eq(r.appointment.status, "cancelled"); eq(r.already, false);
    truthy((await slotsOf(corte.id, joao.id, wed)).includes("10:00"), "10:00 livre de novo");
  });
  await t("cancelar de novo é idempotente (já cancelado)", async () => {
    const r = await cancelAppointment(ctxA, a1.id, { client_id: ana.id }); eq(r.already, true);
  });
  await t("concluído / no-show não cancela -> 409 INVALID_STATUS", async () => {
    for (const status of ["completed", "no_show"]) {
      const r = mk("appointments", { organization_id: ORG_A, client_id: ana.id, barber_id: pedro.id, service_id: corte.id, start_at: new Date(Date.now() + 5 * 86400_000).toISOString(), end_at: new Date(Date.now() + 5 * 86400_000 + 1800_000).toISOString(), status, is_overbook: false, price: 35 });
      await rejects(cancelAppointment(ctxA, r.id, { client_id: ana.id }), 409, "INVALID_STATUS");
      await rejects(rescheduleAppointment(ctxA, r.id, { client_id: ana.id, date: wed, time: "08:00" }), 409, "INVALID_STATUS");
    }
  });
  await t("agendamento que já começou -> 409 APPOINTMENT_IN_PAST", async () => {
    const r = mk("appointments", { organization_id: ORG_A, client_id: ana.id, barber_id: pedro.id, service_id: corte.id, start_at: new Date(Date.now() - 600_000).toISOString(), end_at: new Date(Date.now() + 1200_000).toISOString(), status: "confirmed", is_overbook: false, price: 35 });
    await rejects(cancelAppointment(ctxA, r.id, { client_id: ana.id }), 409, "APPOINTMENT_IN_PAST");
  });

  console.log("\n# 18 Remarcação");
  let a2: any;
  await t("cria 14:00 e remarca para 16:00 (mesmo barbeiro)", async () => {
    a2 = (await book({ phone: "21988887777", time: "14:00" })).appointment;
    const r = await rescheduleAppointment(ctxA, a2.id, { phone: "21988887777", date: wed, time: "16:00" });
    eq(r.appointment.time, "16:00"); eq(r.appointment.end_time, "16:30"); eq(r.appointment.status, "confirmed");
    truthy((await slotsOf(corte.id, joao.id, wed)).includes("14:00"), "14:00 liberado"); truthy(!(await slotsOf(corte.id, joao.id, wed)).includes("16:00"), "16:00 ocupado");
  });
  await t("remarcar para horário ocupado -> 409 e nada muda", async () => {
    const x = (await book({ phone: "21977776666", time: "09:00" })).appointment; // ocupa 09:00
    await rejects(rescheduleAppointment(ctxA, a2.id, { client_id: ana.id, date: wed, time: "09:00" }), 409, "TIME_UNAVAILABLE");
    eq((await getAppointment(ctxA, a2.id, {})).time, "16:00"); void x;
  });
  await t("remarcar para um horário que sobrepõe o próprio (60 min: 10:00 -> 10:30) funciona", async () => {
    const c = (await book({ phone: "21988887777", service_id: combo.id, barber_id: pedro.id, time: "10:00" })).appointment;
    const r = await rescheduleAppointment(ctxA, c.id, { client_id: ana.id, date: wed, time: "10:30" }); eq(r.appointment.time, "10:30"); eq(r.appointment.end_time, "11:30");
  });
  await t("remarcar trocando de barbeiro", async () => {
    const r = await rescheduleAppointment(ctxA, a2.id, { client_id: ana.id, date: wed, time: "16:00", barber_id: pedro.id }); eq(r.appointment.barber.name, "Pedro");
  });
  await t("remarcar repetido para o mesmo horário é idempotente", async () => {
    const r = await rescheduleAppointment(ctxA, a2.id, { client_id: ana.id, date: wed, time: "16:00", barber_id: pedro.id }); eq(r.unchanged, true);
  });
  await t("remarcar fora do expediente / dia fechado -> 409", async () => {
    await rejects(rescheduleAppointment(ctxA, a2.id, { client_id: ana.id, date: wed, time: "19:00" }), 409, "OUTSIDE_BUSINESS_HOURS");
    await rejects(rescheduleAppointment(ctxA, a2.id, { client_id: ana.id, date: sun, time: "10:00" }), 409, "BUSINESS_CLOSED");
  });
  await t("remarcar cancelado -> 409 INVALID_STATUS", () => rejects(rescheduleAppointment(ctxA, a1.id, { client_id: ana.id, date: wed, time: "08:00" }), 409, "INVALID_STATUS"));

  console.log("\n# 18b Listagem dos agendamentos do cliente");
  const L = (o: Record<string, unknown>, ctx = ctxA) => listAppointments(ctx, { phone: undefined, clientId: undefined, limit: undefined, ...o });
  await t("lista só os próximos ATIVOS do cliente, em ordem de horário (exclui cancelado, concluído e passado)", async () => {
    const r = await L({ phone: "21988887777" });
    truthy(r.count >= 2, "deveria haver pelo menos 2 ativos");
    const starts = r.appointments.map((a: any) => a.start_at);
    eq(starts, [...starts].sort(), "ordem");
    for (const a of r.appointments) {
      truthy(["pending", "confirmed"].includes(a.status), "status ativo: " + a.status);
      truthy(Date.parse(a.start_at) > Date.now(), "no futuro");
      eq(a.client.id, ana.id, "dono");
    }
    truthy(!r.appointments.some((x: any) => x.id === a1.id), "cancelado não aparece");
    truthy(r.appointments.some((x: any) => x.id === a2.id), "o remarcado (a2) aparece");
  });
  await t("formato igual ao de GET /appointments/:id e telefone com 55 / client_id dão o mesmo resultado", async () => {
    const byPhone = await L({ phone: "21988887777" });
    const with55 = await L({ phone: "+55 (21) 98888-7777" });
    const byId = await L({ clientId: ana.id });
    eq(with55.appointments.map((a: any) => a.id), byPhone.appointments.map((a: any) => a.id));
    eq(byId.appointments.map((a: any) => a.id), byPhone.appointments.map((a: any) => a.id));
    const one = byPhone.appointments.find((x: any) => x.id === a2.id);
    eq(one, await getAppointment(ctxA, a2.id, {}), "mesma estrutura do get");
    truthy(one.service.name && one.barber.name, "nomes de serviço e barbeiro presentes");
  });
  await t("não mistura clientes: o outro cliente só vê os próprios horários", async () => {
    const r = await L({ phone: "21977776666" });
    truthy(r.count >= 1, "tem o de 09:00");
    for (const a of r.appointments) eq(a.client.phone, "(21) 97777-6666");
  });
  await t("limit limita; limit inválido -> 400", async () => {
    eq((await L({ phone: "21988887777", limit: "1" })).count, 1);
    await rejects(L({ phone: "21988887777", limit: "0" }), 400, "INVALID_INPUT");
    await rejects(L({ phone: "21988887777", limit: "21" }), 400, "INVALID_INPUT");
    await rejects(L({ phone: "21988887777", limit: "abc" }), 400, "INVALID_INPUT");
  });
  await t("sem phone/client_id -> 400; telefone inválido -> 400; telefone desconhecido -> 404 CLIENT_NOT_FOUND", async () => {
    await rejects(L({}), 400, "INVALID_INPUT");
    await rejects(L({ phone: "123" }), 400, "INVALID_INPUT");
    await rejects(L({ phone: "21900000001" }), 404, "CLIENT_NOT_FOUND");
    await rejects(L({ clientId: randomUUID() }), 404, "CLIENT_NOT_FOUND");
  });
  await t("cliente sem horários futuros ativos -> count 0 (não é erro)", async () => {
    const novo = (await createClientIdempotent(ctxA, { name: "Sem Horário", phone: "21955554444" })).client;
    eq(await L({ phone: "21955554444" }), { count: 0, appointments: [] }); void novo;
  });
  await t("cancelar remove da listagem; criar adiciona", async () => {
    const created = (await book({ phone: "21955554444", time: "12:00", barber_id: pedro.id })).appointment;
    eq((await L({ phone: "21955554444" })).appointments.map((a: any) => a.id), [created.id]);
    await cancelAppointment(ctxA, created.id, { phone: "21955554444" });
    eq((await L({ phone: "21955554444" })).count, 0);
  });
  await t("duplicata antiga do mesmo número (com e sem 55): lista os agendamentos de todos os cadastros", async () => {
    const dupe = mk("clients", { organization_id: ORG_A, name: "Dupe", phone: "5521944443333", phone_normalized: "5521944443333" });
    const dupe2 = mk("clients", { organization_id: ORG_A, name: "Dupe", phone: "21944443333", phone_normalized: "21944443333" });
    const x = mk("appointments", { organization_id: ORG_A, client_id: dupe.id, barber_id: pedro.id, service_id: corte.id, start_at: new Date(Date.now() + 40 * 86400_000).toISOString(), end_at: new Date(Date.now() + 40 * 86400_000 + 1800_000).toISOString(), status: "confirmed", is_overbook: false, price: 35, source: "app" });
    const y = mk("appointments", { organization_id: ORG_A, client_id: dupe2.id, barber_id: pedro.id, service_id: corte.id, start_at: new Date(Date.now() + 41 * 86400_000).toISOString(), end_at: new Date(Date.now() + 41 * 86400_000 + 1800_000).toISOString(), status: "pending", is_overbook: false, price: 35, source: "app" });
    eq((await L({ phone: "21944443333" })).appointments.map((a: any) => a.id), [x.id, y.id]);
  });

  console.log("\n# 19 Multi-tenancy");
  await t("outra organização não enxerga nem altera agendamentos", async () => {
    await rejects(getAppointment(ctxB, a2.id, {}), 404, "APPOINTMENT_NOT_FOUND");
    await rejects(cancelAppointment(ctxB, a2.id, { client_id: ana.id }), 404, "APPOINTMENT_NOT_FOUND");
    await rejects(rescheduleAppointment(ctxB, a2.id, { client_id: ana.id, date: wed, time: "08:00" }), 404, "APPOINTMENT_NOT_FOUND");
  });
  await t("outra organização não enxerga clientes nem serviços/barbeiros da A", async () => {
    await rejects(getClientByPhone(ctxB, "21988887777"), 404, "CLIENT_NOT_FOUND");
    eq((await listServices(ctxB)).map((s) => s.name), ["Serviço B"]); eq((await listBarbers(ctxB)).length, 1);
  });
  await t("organization_id no body/query é ignorado: usar IDs da A no token da B falha", async () => {
    const r = await createClientIdempotent(ctxB, { name: "Ana", phone: "21988887777", organization_id: ORG_A });
    eq(r.created, true); eq(T.clients.find((c) => c.id === r.client.id)!.organization_id, ORG_B);
    await rejects(createAppointment(ctxB, { service_id: corte.id, barber_id: barberB.id, date: wed, time: "09:00", phone: "21988887777" }), 404, "SERVICE_NOT_FOUND");
    await rejects(createAppointment(ctxB, { service_id: svcB.id, barber_id: joao.id, date: wed, time: "09:00", phone: "21988887777" }), 404, "BARBER_NOT_FOUND");
    await rejects(createAppointment(ctxB, { service_id: svcB.id, barber_id: barberB.id, date: wed, time: "09:00", client_id: ana.id }), 404, "CLIENT_NOT_FOUND");
  });
  await t("mesmo horário em organizações diferentes não conflita", async () => {
    const r = await createAppointment(ctxB, { service_id: svcB.id, barber_id: barberB.id, date: wed, time: "10:00", phone: "21988887777" }); eq(r.replay, false);
  });

  await t("listagem é isolada por organização: a B só enxerga os próprios agendamentos do mesmo telefone", async () => {
    const rb = await L({ phone: "21988887777" }, ctxB);
    truthy(rb.count >= 1, "B tem o dela");
    for (const a of rb.appointments) { eq(a.barber.name, "Zé (outra barbearia)"); truthy(a.id !== a2.id, "não vaza agendamento da A"); }
    await rejects(L({ clientId: ana.id }, ctxB), 404, "CLIENT_NOT_FOUND");
    await rejects(L({ phone: "21977776666" }, ctxB), 404, "CLIENT_NOT_FOUND");
  });

  console.log(`\nResultado: ${pass} ok, ${fail} falhas`);
  process.exit(fail ? 1 : 0);
}
main();
