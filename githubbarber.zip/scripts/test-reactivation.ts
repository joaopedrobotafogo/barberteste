// @ts-nocheck — script de teste com banco fake; fora do typecheck/build do app de propósito.
/**
 * Testes da Etapa 11 (Reactivation Intelligence), sem rede e sem Supabase real.
 *
 *   npx tsx scripts/test-reactivation.ts
 *
 * Roda o CÓDIGO REAL (src/lib/reactivation/*) contra um banco em memória que EMULA as regras do schema
 * 0003_reactivation.sql: índice único de campanha aberta por cliente (23505), opt-out ativo único (23505),
 * FK composta cliente/organização (23503), upsert de settings, paginação (.range) e filtros eq/in/is/gt/gte/lt/lte.
 *
 * LIMITES (ditos com franqueza): não executa SQL real, não abre navegador. Os itens "recarregar" e "mobile"
 * da lista do enunciado só podem ser verificados em nível de service (persistência/reavaliação) e de código
 * (classes responsivas); a verificação visual em celular/navegador NÃO é feita aqui — veja o relatório.
 */
import { randomUUID } from "node:crypto";
import { computeBehavior, filterOutliers } from "../src/lib/reactivation/behavior";
import {
  DEFAULT_REACTIVATION_SETTINGS, loadReactivationSettings, saveReactivationSettings, validateReactivationSettings,
} from "../src/lib/reactivation/settings";
import {
  cancelRequest, dismissCandidate, getOverview, markFailed, markResponded, markSent, reconcileOutcomes,
  recordOptOut, requestReactivation, listPending,
} from "../src/lib/reactivation/service";
import {
  apiCandidates, apiFailed, apiOptOut, apiPending, apiResponded, apiSent, apiSettings, apiTrigger,
} from "../src/lib/reactivation/integration";
import { ApiError } from "../src/lib/integration/http";

// ------------------------------------------------------------------ banco em memória
type Row = Record<string, any>;
const T: Record<string, Row[]> = {};
const TABLES = ["organizations", "business_settings", "barbers", "clients", "services", "appointments",
  "reactivation_settings", "reactivation_attempts", "reactivation_opt_outs"];
let seq = 0;
const OPEN = ["requested", "sent", "responded", "booked"];
const err = (code: string, message: string) => ({ code, message });

const DEFAULTS: Record<string, Row> = {
  reactivation_attempts: { status: "requested", reason: "behavior_due", requested_by: null, sent_at: null, responded_at: null,
    booked_at: null, reactivated_at: null, closed_at: null, failed_reason: null, dismissed_until: null, resulting_appointment_id: null, snapshot: {} },
  reactivation_opt_outs: { revoked_at: null, note: null, source: "whatsapp" },
  reactivation_settings: { mode: "manual", margin_percent: 15, min_visits: 3, send_window_start: "09:00", send_window_end: "19:00",
    daily_limit: 20, min_days_between_attempts: 30, max_attempts: 3, block_if_future_appointment: true, attribution_days: 14 },
};

function constraints(table: string, row: Row, self?: Row) {
  if (table === "reactivation_attempts") {
    if (!T.clients.some((c) => c.id === row.client_id && c.organization_id === row.organization_id)) return err("23503", "fk cliente/organização");
    if (OPEN.includes(row.status) && T.reactivation_attempts.some((a) => a !== self && a.client_id === row.client_id && OPEN.includes(a.status)))
      return err("23505", "reactivation_attempts_open_uq");
  }
  if (table === "reactivation_opt_outs") {
    if (!T.clients.some((c) => c.id === row.client_id && c.organization_id === row.organization_id)) return err("23503", "fk cliente/organização");
    if (!row.revoked_at && T.reactivation_opt_outs.some((o) => o !== self && o.client_id === row.client_id && !o.revoked_at)) return err("23505", "opt_out_active_uq");
  }
  return null;
}

const cmp = (a: any, b: any) => (a < b ? -1 : a > b ? 1 : 0);
class Q implements PromiseLike<any> {
  f: ((r: Row) => boolean)[] = []; op = "select"; payload: any; lim?: number; ords: [string, boolean][] = []; rng?: [number, number];
  single = false; conflict?: string;
  constructor(public table: string) {}
  select() { return this; }
  insert(p: any) { this.op = "insert"; this.payload = p; return this; }
  update(p: any) { this.op = "update"; this.payload = p; return this; }
  upsert(p: any, o?: any) { this.op = "upsert"; this.payload = p; this.conflict = o?.onConflict; return this; }
  eq(c: string, v: any) { this.f.push((r) => r[c] === v); return this; }
  neq(c: string, v: any) { this.f.push((r) => r[c] !== v); return this; }
  in(c: string, v: any[]) { this.f.push((r) => v.includes(r[c])); return this; }
  is(c: string, v: null) { this.f.push((r) => (r[c] ?? null) === v); return this; }
  gt(c: string, v: any) { this.f.push((r) => r[c] != null && Date.parse(r[c]) > Date.parse(v)); return this; }
  gte(c: string, v: any) { this.f.push((r) => r[c] != null && Date.parse(r[c]) >= Date.parse(v)); return this; }
  lt(c: string, v: any) { this.f.push((r) => r[c] != null && Date.parse(r[c]) < Date.parse(v)); return this; }
  lte(c: string, v: any) { this.f.push((r) => r[c] != null && Date.parse(r[c]) <= Date.parse(v)); return this; }
  order(c: string, o?: { ascending?: boolean }) { this.ords.push([c, o?.ascending ?? true]); return this; }
  limit(n: number) { this.lim = n; return this; }
  range(a: number, b: number) { this.rng = [a, b]; return this; }
  maybeSingle() { this.single = true; return this; }
  then(ok?: any, ko?: any) { return Promise.resolve(this.run()).then(ok, ko); }
  run() {
    const rows = T[this.table];
    if (!rows) return { data: null, error: err("42P01", `tabela ${this.table} inexistente`) };
    const match = () => rows.filter((r) => this.f.every((fn) => fn(r)));
    const mk = (p: Row) => ({ id: randomUUID(), created_at: new Date(Date.now() + ++seq).toISOString(), deleted_at: null,
      ...(DEFAULTS[this.table] ?? {}), ...p });
    if (this.op === "insert") {
      const out: Row[] = [];
      for (const p of Array.isArray(this.payload) ? this.payload : [this.payload]) {
        const row = mk(p);
        const bad = constraints(this.table, row);
        if (bad) return { data: null, error: bad };
        rows.push(row); out.push({ ...row });
      }
      return { data: out, error: null };
    }
    if (this.op === "update") {
      const hit = match();
      for (const r of hit) {
        const next = { ...r, ...this.payload };
        const bad = constraints(this.table, next, r);
        if (bad) return { data: null, error: bad };
        Object.assign(r, this.payload);
      }
      return { data: hit.map((r) => ({ ...r })), error: null };
    }
    if (this.op === "upsert") {
      const col = this.conflict ?? "id";
      const cur = rows.find((r) => r[col] === this.payload[col]);
      if (cur) { Object.assign(cur, this.payload); return { data: [{ ...cur }], error: null }; }
      const row = mk(this.payload); rows.push(row); return { data: [{ ...row }], error: null };
    }
    let out = match();
    for (const [c, asc] of [...this.ords].reverse()) out = [...out].sort((a, b) => (asc ? 1 : -1) * cmp(a[c], b[c]));
    if (this.rng) out = out.slice(this.rng[0], this.rng[1] + 1);
    if (this.lim !== undefined) out = out.slice(0, this.lim);
    const data = out.map((r) => ({ ...r }));
    return { data: this.single ? data[0] ?? null : data, error: null };
  }
}
const db: any = { from: (t: string) => new Q(t) };

// ------------------------------------------------------------------ cenário
const DAY = 86_400_000;
const NOW = new Date("2026-10-02T15:00:00.000Z"); // 12:00 em São Paulo: dentro da janela 09:00–19:00
const NIGHT = new Date("2026-10-02T23:30:00.000Z"); // 20:30 em São Paulo: fora da janela
const ago = (days: number, from = NOW) => new Date(from.getTime() - days * DAY).toISOString();
const ctxOf = (orgId: string, now: Date = NOW) => ({ db, orgId, now: () => now, tokenId: "t" });

let phoneSeq = 0;
function reset() {
  for (const t of TABLES) T[t] = [];
  const mkOrg = (name: string) => {
    const orgId = randomUUID();
    T.organizations.push({ id: orgId, name, deleted_at: null });
    T.business_settings.push({ organization_id: orgId, timezone: "America/Sao_Paulo" });
    const barber = { id: randomUUID(), organization_id: orgId, name: "Carlos", is_active: true, deleted_at: null };
    const service = { id: randomUUID(), organization_id: orgId, name: "Corte", price: 50, is_active: true, deleted_at: null };
    T.barbers.push(barber); T.services.push(service);
    return { orgId, barber, service };
  };
  return { A: mkOrg("Barbearia A"), B: mkOrg("Barbearia B") };
}
function addClient(org: any, name: string) {
  const n = ++phoneSeq;
  const phone = `(21) 99${String(n).padStart(3, "0")}-${String(1000 + n)}`;
  const c = { id: randomUUID(), organization_id: org.orgId, name, phone, phone_normalized: phone.replace(/\D/g, ""), deleted_at: null, created_at: ago(500) };
  T.clients.push(c);
  return c;
}
function addAppt(org: any, clientId: string, o: { status?: string; startDaysAgo: number; createdDaysAgo?: number; createdAt?: string }) {
  const a = {
    id: randomUUID(), organization_id: org.orgId, client_id: clientId, barber_id: org.barber.id, service_id: org.service.id,
    start_at: ago(o.startDaysAgo), end_at: ago(o.startDaysAgo - 0.02), status: o.status ?? "completed", price: 50,
    created_at: o.createdAt ?? ago(o.createdDaysAgo ?? o.startDaysAgo + 1), deleted_at: null, is_overbook: false,
  };
  T.appointments.push(a);
  return a;
}
const visits = (org: any, clientId: string, daysAgoList: number[]) => daysAgoList.forEach((d) => addAppt(org, clientId, { startDaysAgo: d }));
/** Cliente regular: volta a cada ~32 dias; última visita há `last` dias. */
function regular(org: any, name: string, last = 40, gap = 32, n = 4) {
  const c = addClient(org, name);
  visits(org, c.id, Array.from({ length: n }, (_, i) => last + gap * i));
  return c;
}
function seedAttempt(org: any, clientId: string, o: Partial<Row> & { requestedDaysAgo?: number }) {
  const row = { id: randomUUID(), organization_id: org.orgId, client_id: clientId, origin: "manual", status: "sent", reason: "behavior_due",
    snapshot: {}, requested_by: null, requested_at: ago(o.requestedDaysAgo ?? 5), sent_at: null, responded_at: null, booked_at: null,
    reactivated_at: null, closed_at: null, failed_reason: null, dismissed_until: null, resulting_appointment_id: null,
    created_at: ago(5), deleted_at: null, ...o };
  delete (row as any).requestedDaysAgo;
  T.reactivation_attempts.push(row);
  return row;
}
const setSettings = (org: any, patch: Row) => {
  const cur = T.reactivation_settings.find((s) => s.organization_id === org.orgId);
  if (cur) Object.assign(cur, patch); else T.reactivation_settings.push({ organization_id: org.orgId, ...DEFAULTS.reactivation_settings, ...patch });
};
const attemptsOf = (clientId: string) => T.reactivation_attempts.filter((a) => a.client_id === clientId);

// ------------------------------------------------------------------ mini-framework
let pass = 0, failCount = 0, skipped = 0;
const failures: string[] = [];
const section = (n: string) => console.log(`\n# ${n}`);
async function t(name: string, fn: () => any) {
  try { await fn(); pass++; console.log(`  ok   ${name}`); }
  catch (e: any) { failCount++; failures.push(name); console.log(`  FAIL ${name}\n       ${e?.message ?? e}`); }
}
function skip(name: string, why: string) { skipped++; console.log(`  SKIP ${name}\n       ${why}`); }
const assert = (c: any, m = "asserção falhou") => { if (!c) throw new Error(m); };
const eq = (a: any, b: any, m = "") => { if (JSON.stringify(a) !== JSON.stringify(b)) throw new Error(`${m} esperado ${JSON.stringify(b)}, recebido ${JSON.stringify(a)}`); };
async function code(fn: () => Promise<any>): Promise<string> {
  try { await fn(); } catch (e: any) { if (e instanceof ApiError) return e.code; throw e; }
  return "NO_ERROR";
}
async function status(fn: () => Promise<any>): Promise<number> {
  try { await fn(); } catch (e: any) { if (e instanceof ApiError) return e.status; throw e; }
  return 0;
}
const TZ = "America/Sao_Paulo";
const P = { marginPercent: 15, minVisits: 3 };
/** Gera instantes de visitas com os intervalos dados, terminando `lastAgo` dias antes de `now`. */
function seq_(gaps: number[], lastAgo: number, now = NOW) {
  let d = new Date(now.getTime() - lastAgo * DAY);
  const out = [d.toISOString()];
  for (const g of [...gaps].reverse()) { d = new Date(d.getTime() - g * DAY); out.unshift(d.toISOString()); }
  return out;
}

// ================================================================== A. COMPORTAMENTO (puro)
async function behaviorTests() {
  section("A. Cálculo do comportamento (função pura)");
  await t("1) cliente com 1 atendimento: sem histórico suficiente, nada é inventado", () => {
    const b = computeBehavior(seq_([], 10), NOW, TZ, P);
    eq(b.visits, 1); eq(b.habitualIntervalDays, null); eq(b.confidence, "none"); eq(b.behaviorKnown, false);
    eq(b.eligible, false); eq(b.reason, "insufficient_history"); eq(b.overdueDays, null); eq(b.dueAfterDays, null);
  });
  await t("1b) cliente sem nenhum atendimento: no_visits", () => {
    const b = computeBehavior([], NOW, TZ, P);
    eq(b.reason, "no_visits"); eq(b.daysSinceLastVisit, null); eq(b.eligible, false);
  });
  await t("2) cliente com 2 atendimentos: 1 intervalo, confiança BAIXA, não é comportamento conhecido (mín. 3)", () => {
    const b = computeBehavior(seq_([30], 60), NOW, TZ, P);
    eq(b.visits, 2); eq(b.intervals, [30]); eq(b.habitualIntervalDays, 30); eq(b.confidence, "low");
    eq(b.behaviorKnown, false); eq(b.eligible, false, "mesmo muito atrasado não é elegível com mínimo 3");
  });
  await t("2b) mínimo configurado para 2: passa a ser conhecido (confiança continua baixa)", () => {
    const b = computeBehavior(seq_([30], 40), NOW, TZ, { marginPercent: 15, minVisits: 2 });
    eq(b.behaviorKnown, true); eq(b.confidence, "low"); eq(b.eligible, true);
  });
  await t("3) histórico suficiente (5 visitas): comportamento conhecido, confiança média/alta", () => {
    const b = computeBehavior(seq_([30, 31, 29, 30], 20), NOW, TZ, P);
    eq(b.visits, 5); eq(b.behaviorKnown, true); assert(["medium", "high"].includes(b.confidence), b.confidence);
  });
  await t("3b) confiança cresce com mais histórico regular (2 < 3 < 6 visitas)", () => {
    const c = (n: number) => computeBehavior(seq_(Array(n - 1).fill(30), 10), NOW, TZ, { marginPercent: 15, minVisits: 2 }).confidenceScore;
    assert(c(2) < c(3) && c(3) < c(6), `${c(2)} ${c(3)} ${c(6)}`);
  });
  await t("4) intervalo regular: habitual = intervalo, confiança alta", () => {
    const b = computeBehavior(seq_([32, 32, 32, 32], 10), NOW, TZ, P);
    eq(b.habitualIntervalDays, 32); eq(b.meanIntervalDays, 32); eq(b.confidence, "high"); eq(b.outliersDropped, 0);
  });
  await t("5) outlier: 30,31,32,33,90 NÃO resulta em ~43 dias (a média simples); o 90 é descartado", () => {
    const b = computeBehavior(seq_([30, 31, 32, 33, 90], 10), NOW, TZ, P);
    eq(b.outliersDropped, 1); eq(b.intervalsUsed, [30, 31, 32, 33]);
    assert(b.habitualIntervalDays >= 31 && b.habitualIntervalDays <= 32, `habitual=${b.habitualIntervalDays}`);
    assert(Math.abs(b.habitualIntervalDays - 43.2) > 10, "não pode ficar perto da média 43,2");
  });
  await t("5b) filterOutliers: só age com 4+ intervalos e tolera variação normal", () => {
    eq(filterOutliers([30, 90, 30]).dropped, [], "3 intervalos: sem base para descartar");
    eq(filterOutliers([30, 30, 30, 30, 35]).dropped, [], "35 em torno de 30 é variação normal");
    eq(filterOutliers([30, 31, 32, 33, 90]).dropped, [90]);
  });
  await t("5c) mediana, não média: 28,30,31,33 com 120 no meio do histórico", () => {
    const b = computeBehavior(seq_([28, 30, 120, 31, 33], 5), NOW, TZ, P);
    assert(b.habitualIntervalDays <= 33, `habitual=${b.habitualIntervalDays}`);
  });
  await t("6) ainda dentro do ritmo (habitual 60, 35 dias sem vir): NÃO é candidato", () => {
    const b = computeBehavior(seq_([60, 60, 60], 35), NOW, TZ, P);
    eq(b.habitualIntervalDays, 60); eq(b.eligible, false); eq(b.reason, "within_habitual_range"); assert(b.overdueDays < 0);
  });
  await t("7) atrasado (habitual 32, 40 dias sem vir): candidato, atraso 8", () => {
    const b = computeBehavior(seq_([32, 32, 32], 40), NOW, TZ, P);
    eq(b.eligible, true); eq(b.reason, "behavior_due"); eq(b.overdueDays, 8); eq(b.daysSinceLastVisit, 40); eq(b.dueAfterDays, 36.8);
  });
  await t("7b) margem: habitual 30 com 15% → candidato só ACIMA de 34,5 dias", () => {
    const at = (d: number) => computeBehavior(seq_([30, 30, 30], d), NOW, TZ, P).eligible;
    eq(at(34), false); eq(at(35), true);
  });
  await t("7c) margem configurável: 0% e 50% mudam o limite", () => {
    const g = (m: number, d: number) => computeBehavior(seq_([30, 30, 30], d), NOW, TZ, { marginPercent: m, minVisits: 3 }).eligible;
    eq(g(0, 31), true); eq(g(50, 40), false); eq(g(50, 46), true);
  });
  await t("7d) o mesmo número de dias sem vir dá resultados diferentes para clientes diferentes", () => {
    const joao = computeBehavior(seq_([32, 32, 32], 40), NOW, TZ, P);
    const lucas = computeBehavior(seq_([60, 60, 60], 40), NOW, TZ, P);
    eq([joao.eligible, lucas.eligible], [true, false]);
  });
  await t("7e) dois atendimentos no MESMO dia contam como uma visita (sem intervalo 0)", () => {
    const base = seq_([30, 30, 30], 40);
    const dup = [...base, new Date(Date.parse(base[3]) + 3600_000).toISOString()];
    const b = computeBehavior(dup, NOW, TZ, P);
    eq(b.completedCount, 5); eq(b.visits, 4); assert(!b.intervals.includes(0));
  });
  await t("7f) atendimento 'concluído' no futuro é ignorado", () => {
    const b = computeBehavior([...seq_([30, 30, 30], 40), ago(-3)], NOW, TZ, P);
    eq(b.visits, 4); eq(b.daysSinceLastVisit, 40);
  });
  await t("7g) dias são contados no fuso da barbearia (23:00 local ≠ dia seguinte UTC)", () => {
    const now = new Date("2026-10-03T02:00:00Z"); // 02/10 23:00 em São Paulo
    const last = new Date("2026-09-02T14:00:00Z").toISOString();
    const b = computeBehavior([new Date("2026-08-03T14:00:00Z").toISOString(), new Date("2026-08-03T14:00:00Z").toISOString(),
      "2026-07-04T14:00:00Z", last], now, TZ, P);
    eq(b.daysSinceLastVisit, 30);
  });
}

// ================================================================== B. SERVICE
async function serviceTests() {
  section("B. Proteções, estados e persistência (service real + banco em memória)");

  await t("candidatos usam só atendimentos CONCLUÍDOS: cancelado, no-show e futuro não entram no histórico", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    addAppt(A, c.id, { status: "cancelled", startDaysAgo: 3 });
    addAppt(A, c.id, { status: "no_show", startDaysAgo: 2 });
    const o = await getOverview(ctxOf(A.orgId));
    const it = o.candidates.find((x) => x.client.id === c.id);
    assert(it, "João deveria ser candidato (cancelado/no-show não resetam o relógio)");
    eq(it.behavior.visits, 4); eq(it.behavior.daysSinceLastVisit, 40);
  });

  await t("candidato dinâmico: não é gravado em nenhuma tabela", async () => {
    const { A } = reset();
    regular(A, "João", 40);
    const before = JSON.stringify(T);
    const o = await getOverview(ctxOf(A.orgId));
    eq(o.candidates.length, 1);
    eq(JSON.stringify(T), before, "calcular candidatos não pode escrever nada");
    eq(T.reactivation_attempts.length, 0);
  });

  await t("João (32/40) é candidato; Lucas (60/35) não; 1 e 2 atendimentos não", async () => {
    const { A } = reset();
    const joao = regular(A, "João", 40, 32);
    const lucas = regular(A, "Lucas", 35, 60);
    const novo = addClient(A, "Novo"); visits(A, novo.id, [50]);
    const dois = addClient(A, "Dois"); visits(A, dois.id, [90, 40]);
    const ids = (await getOverview(ctxOf(A.orgId))).candidates.map((c) => c.client.id);
    eq(ids, [joao.id]);
    assert(!ids.includes(lucas.id) && !ids.includes(novo.id) && !ids.includes(dois.id));
  });

  await t("8) cliente com agendamento FUTURO: some da lista e o pedido é barrado no backend", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    addAppt(A, c.id, { status: "confirmed", startDaysAgo: -5, createdDaysAgo: 1 });
    eq((await getOverview(ctxOf(A.orgId))).candidates.length, 0);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "HAS_FUTURE_APPOINTMENT");
    setSettings(A, { block_if_future_appointment: false });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "NO_ERROR", "configurável: desligado libera");
  });

  await t("8b) agendamento futuro CANCELADO não bloqueia", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    addAppt(A, c.id, { status: "cancelled", startDaysAgo: -5, createdDaysAgo: 1 });
    eq((await getOverview(ctxOf(A.orgId))).candidates.length, 1);
  });

  await t("9) opt-out: some da lista, bloqueia manual e automático, cancela pedido pendente, é idempotente", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic" });
    const c = regular(A, "João", 40);
    const r = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    eq(r.attempt.status, "requested");
    const o1 = await recordOptOut(ctxOf(A.orgId), c.id, { source: "whatsapp" });
    eq([o1.optedOut, o1.replay, o1.cancelledPending], [true, false, 1]);
    eq(attemptsOf(c.id)[0].status, "cancelled");
    eq((await recordOptOut(ctxOf(A.orgId), c.id)).replay, true);
    eq(T.reactivation_opt_outs.length, 1);
    eq((await getOverview(ctxOf(A.orgId))).candidates.length, 0);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "OPTED_OUT");
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "automatic" })), "OPTED_OUT");
  });

  await t("10) limite diário: o N+1º pedido é barrado (429); cancelar libera; amanhã zera", async () => {
    const { A } = reset();
    setSettings(A, { daily_limit: 2 });
    const cs = [regular(A, "C1"), regular(A, "C2"), regular(A, "C3")];
    const r1 = await requestReactivation(ctxOf(A.orgId), cs[0].id, { origin: "manual" });
    await requestReactivation(ctxOf(A.orgId), cs[1].id, { origin: "manual" });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), cs[2].id, { origin: "manual" })), "DAILY_LIMIT_REACHED");
    eq(await status(() => requestReactivation(ctxOf(A.orgId), cs[2].id, { origin: "manual" })), 429);
    await cancelRequest(ctxOf(A.orgId), r1.attempt.id);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), cs[2].id, { origin: "manual" })), "NO_ERROR", "cancelado não conta");
    const tomorrow = new Date(NOW.getTime() + DAY);
    const o = await getOverview(ctxOf(A.orgId, tomorrow));
    eq(o.capacity.used, 0, "o limite é por dia local");
  });

  await t("10b) a mesma regra vale para o automático", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic", daily_limit: 1 });
    const [c1, c2] = [regular(A, "C1"), regular(A, "C2")];
    await requestReactivation(ctxOf(A.orgId), c1.id, { origin: "automatic" });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c2.id, { origin: "automatic" })), "DAILY_LIMIT_REACHED");
  });

  await t("11) intervalo mínimo entre tentativas: tentativa recente barra; antiga libera", async () => {
    const { A } = reset();
    const c = regular(A, "João", 90); // última visita há 90d; tentativas depois disso
    seedAttempt(A, c.id, { status: "expired", requestedDaysAgo: 10, sent_at: ago(10), closed_at: ago(0) });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "TOO_SOON_SINCE_LAST_ATTEMPT");
    eq((await getOverview(ctxOf(A.orgId))).candidates.length, 0, "não aparece como candidato");
    T.reactivation_attempts[0].requested_at = ago(40); T.reactivation_attempts[0].sent_at = ago(40);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "NO_ERROR");
  });

  await t("11b) tentativa FALHA ou CANCELADA não conta para intervalo mínimo nem limite", async () => {
    const { A } = reset();
    const c = regular(A, "João", 90);
    seedAttempt(A, c.id, { status: "failed", requestedDaysAgo: 1 });
    seedAttempt(A, c.id, { status: "cancelled", requestedDaysAgo: 2 });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "NO_ERROR");
  });

  await t("11c) máximo de tentativas desde a última visita; tentativas ANTES da última visita não contam", async () => {
    const { A } = reset();
    setSettings(A, { max_attempts: 2, min_days_between_attempts: 1 });
    const c = regular(A, "João", 100);
    seedAttempt(A, c.id, { status: "expired", requestedDaysAgo: 60, sent_at: ago(60) });
    seedAttempt(A, c.id, { status: "expired", requestedDaysAgo: 30, sent_at: ago(30) });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "MAX_ATTEMPTS_REACHED");
    // cliente volta (visita há 10 dias): o contador recomeça
    addAppt(A, c.id, { startDaysAgo: 10 });
    const o = await getOverview(ctxOf(A.orgId));
    assert(!o.candidates.some((x) => x.client.id === c.id), "acabou de voltar: não é candidato");
  });

  await t("12) cliente já reativado: sai da lista, tentativa vira reactivated e o contador recomeça", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    const r = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    const appt = addAppt(A, c.id, { status: "confirmed", startDaysAgo: -3, createdDaysAgo: 0 });
    appt.created_at = ago(0);
    await reconcileOutcomes(ctxOf(A.orgId));
    eq(attemptsOf(c.id)[0].status, "booked");
    appt.status = "completed"; appt.start_at = ago(0.1);
    const rec = await reconcileOutcomes(ctxOf(A.orgId));
    eq(rec.reactivated, 1);
    const a = attemptsOf(c.id)[0];
    eq([a.status, a.resulting_appointment_id], ["reactivated", appt.id]);
    assert(a.reactivated_at && a.booked_at && a.closed_at);
    const o = await getOverview(ctxOf(A.orgId));
    eq(o.candidates.length, 0); eq(o.inProgress.length, 0); eq(o.metrics.reactivated, 1);
    assert(r.attempt.id === a.id);
  });

  await t("13) mensagem ENVIADA sem novo agendamento: continua 'sent' (nunca reativado) e expira depois do prazo", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    await reconcileOutcomes(ctxOf(A.orgId));
    let a = attemptsOf(c.id)[0];
    eq(a.status, "sent"); eq(a.reactivated_at, null); eq(a.booked_at, null);
    const o = await getOverview(ctxOf(A.orgId));
    eq(o.metrics.sentToday, 1); eq(o.metrics.reactivated, 0); eq(o.metrics.booked, 0); eq(o.inProgress[0].state, "sent");
    await reconcileOutcomes(ctxOf(A.orgId, new Date(NOW.getTime() + 15 * DAY)));
    a = attemptsOf(c.id)[0];
    eq(a.status, "expired");
    eq(a.reactivated_at, null);
  });

  await t("14) novo agendamento DEPOIS da campanha: booked → concluído = reactivated", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    await markResponded(ctxOf(A.orgId), c.id);
    const appt = addAppt(A, c.id, { status: "confirmed", startDaysAgo: -2, createdDaysAgo: 0 });
    appt.created_at = new Date(NOW.getTime() + 60_000).toISOString();
    const later = new Date(NOW.getTime() + 3600_000);
    await reconcileOutcomes(ctxOf(A.orgId, later));
    let a = attemptsOf(c.id)[0];
    eq([a.status, a.resulting_appointment_id], ["booked", appt.id]);
    assert(a.responded_at, "responded_at é preservado");
    eq(a.reactivated_at, null, "agendou ≠ reativado");
    appt.status = "completed";
    await reconcileOutcomes(ctxOf(A.orgId, later));
    a = attemptsOf(c.id)[0];
    eq(a.status, "reactivated");
  });

  await t("14b) agendamento criado ANTES do envio ou FORA do prazo não é atribuído", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    const before = addAppt(A, c.id, { status: "confirmed", startDaysAgo: -4 });
    before.created_at = new Date(NOW.getTime() - 3600_000).toISOString();
    const late = addAppt(A, c.id, { status: "confirmed", startDaysAgo: -40 });
    late.created_at = new Date(NOW.getTime() + 20 * DAY).toISOString();
    await reconcileOutcomes(ctxOf(A.orgId, new Date(NOW.getTime() + 21 * DAY)));
    const a = attemptsOf(c.id)[0];
    eq(a.resulting_appointment_id, null); assert(a.status !== "booked" && a.status !== "reactivated", a.status);
  });

  await t("14c) agendamento cancelado volta a tentativa para sent/responded", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    const appt = addAppt(A, c.id, { status: "confirmed", startDaysAgo: -2 });
    appt.created_at = new Date(NOW.getTime() + 60_000).toISOString();
    const later = new Date(NOW.getTime() + 3600_000);
    await reconcileOutcomes(ctxOf(A.orgId, later));
    eq(attemptsOf(c.id)[0].status, "booked");
    appt.status = "cancelled";
    const rec = await reconcileOutcomes(ctxOf(A.orgId, later));
    eq(rec.reverted, 1);
    const a = attemptsOf(c.id)[0];
    eq([a.status, a.booked_at, a.resulting_appointment_id], ["sent", null, null]);
  });

  await t("14d) reconcile é idempotente", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    const appt = addAppt(A, c.id, { status: "completed", startDaysAgo: 0.1 });
    appt.created_at = new Date(NOW.getTime() + 1000).toISOString();
    const later = new Date(NOW.getTime() + 3600_000);
    eq((await reconcileOutcomes(ctxOf(A.orgId, later))).reactivated, 1);
    const snap = JSON.stringify(T.reactivation_attempts);
    const second = await reconcileOutcomes(ctxOf(A.orgId, later));
    eq(second, { booked: 0, reactivated: 0, reverted: 0, expired: 0 });
    eq(JSON.stringify(T.reactivation_attempts), snap);
  });

  await t("métricas: enviada, respondeu, agendou e reativado são contados SEPARADAMENTE", async () => {
    const { A } = reset();
    const mk = async (name: string) => { const c = regular(A, name); await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" }); return c; };
    const [c1, c2, c3, c4] = [await mk("C1"), await mk("C2"), await mk("C3"), await mk("C4")];
    for (const c of [c1, c2, c3, c4]) await markSent(ctxOf(A.orgId), c.id);
    for (const c of [c2, c3, c4]) await markResponded(ctxOf(A.orgId), c.id);
    const a3 = addAppt(A, c3.id, { status: "confirmed", startDaysAgo: -2 }); a3.created_at = new Date(NOW.getTime() + 1000).toISOString();
    const a4 = addAppt(A, c4.id, { status: "completed", startDaysAgo: 0.1 }); a4.created_at = new Date(NOW.getTime() + 1000).toISOString();
    const o = await getOverview(ctxOf(A.orgId, new Date(NOW.getTime() + 3600_000)), { reconcile: true });
    eq([o.metrics.requestedToday, o.metrics.sentToday, o.metrics.responded, o.metrics.booked, o.metrics.reactivated], [4, 4, 3, 2, 1]);
    eq(o.metrics.eligible, 0);
  });

  await t("dispensa: ignorar candidato (some até dismissed_until e não conta no limite)", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await dismissCandidate(ctxOf(A.orgId), c.id, {});
    eq((await getOverview(ctxOf(A.orgId))).candidates.length, 0);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "DISMISSED");
    eq((await getOverview(ctxOf(A.orgId))).capacity.used, 0);
    eq((await getOverview(ctxOf(A.orgId, new Date(NOW.getTime() + 31 * DAY)))).candidates.length, 1, "após 30 dias volta");
  });

  await t("campanhas simultâneas: duas requisições paralelas → UMA tentativa aberta (índice único)", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    const [r1, r2] = await Promise.all([
      requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" }),
      requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" }),
    ]);
    eq(attemptsOf(c.id).length, 1);
    eq(r1.attempt.id, r2.attempt.id); eq([r1.replay, r2.replay].sort(), [false, true]);
  });

  await t("campanha em andamento (sent): novo pedido é barrado com ALREADY_IN_PROGRESS", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "ALREADY_IN_PROGRESS");
  });

  await t("repetir o pedido ainda 'requested' é replay (não cria segunda tentativa nem gasta o limite)", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    const a = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    const b = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    eq([a.replay, b.replay, a.attempt.id === b.attempt.id], [false, true, true]);
    eq(attemptsOf(c.id).length, 1);
  });

  await t("snapshot gravado com o cálculo no momento do pedido", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    const r = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual", requestedBy: randomUUID() });
    const s = r.attempt.snapshot;
    eq([s.habitual_interval_days, s.days_since_last_visit, s.overdue_days, s.visits, s.confidence, s.margin_percent], [32, 40, 8, 4, "high", 15]);
    assert(s.last_visit_at && r.attempt.requested_by);
  });

  await t("transições de estado: sent/responded idempotentes, failed só antes do envio", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    eq(await code(() => markResponded(ctxOf(A.orgId), c.id)), "INVALID_STATE", "não responde mensagem não enviada");
    eq((await markSent(ctxOf(A.orgId), c.id)).replay, false);
    eq((await markSent(ctxOf(A.orgId), c.id)).replay, true);
    eq(await code(() => markFailed(ctxOf(A.orgId), c.id, "x")), "INVALID_STATE", "já enviada não pode falhar");
    eq((await markResponded(ctxOf(A.orgId), c.id)).replay, false);
    eq((await markResponded(ctxOf(A.orgId), c.id)).replay, true);
    eq(attemptsOf(c.id)[0].status, "responded");
  });

  await t("falha no envio: requested → failed, libera o cliente e não conta no limite", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    eq((await markFailed(ctxOf(A.orgId), c.id, "evolution_offline")).attempt.status, "failed");
    eq((await markFailed(ctxOf(A.orgId), c.id, "x")).replay, true);
    eq((await getOverview(ctxOf(A.orgId))).capacity.used, 0);
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "NO_ERROR");
  });

  await t("sem reativação em andamento: sent/responded → NO_ACTIVE_REACTIVATION (404)", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    eq(await code(() => markSent(ctxOf(A.orgId), c.id)), "NO_ACTIVE_REACTIVATION");
    eq(await status(() => markResponded(ctxOf(A.orgId), c.id)), 404);
  });

  await t("cancelar pedido só vale antes do envio", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    const r = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    eq(await code(() => cancelRequest(ctxOf(A.orgId), r.attempt.id)), "INVALID_STATE");
  });

  await t("telefone inválido: CLIENT_PHONE_INVALID (não registra tentativa)", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    c.phone = "123"; c.phone_normalized = "123";
    eq(await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" })), "CLIENT_PHONE_INVALID");
    eq(T.reactivation_attempts.length, 0);
  });

  await t("entrada inválida: clientId que não é UUID → INVALID_INPUT", async () => {
    const { A } = reset();
    eq(await code(() => requestReactivation(ctxOf(A.orgId), "abc", { origin: "manual" })), "INVALID_INPUT");
  });

  await t("paginação: com >1000 atendimentos concluídos a 2ª página também é lida (última visita correta)", async () => {
    const { A } = reset();
    const joao = regular(A, "João", 40); // a visita mais RECENTE do salão inteiro: cai na 2ª página (ordem por start_at)
    const other = addClient(A, "Muito frequente");
    for (let i = 0; i < 1100; i++) addAppt(A, other.id, { startDaysAgo: 41 + (i % 600), createdDaysAgo: 1 });
    const o = await getOverview(ctxOf(A.orgId));
    const j = o.candidates.find((x) => x.client.id === joao.id);
    assert(j, "João deveria ser candidato");
    eq([j.behavior.visits, j.behavior.daysSinceLastVisit], [4, 40], "se a 2ª página fosse ignorada, a última visita seria outra");
    const f = o.candidates.find((x) => x.client.id === other.id);
    assert(f, "o cliente frequente também é avaliado");
    eq(f.behavior.completedCount, 1100);
  });
}

// ================================================================== C. MANUAL x AUTOMÁTICO
async function modeTests() {
  section("C. Manual e automático compartilham a mesma infraestrutura");
  await t("16) MANUAL: dono registra o pedido; o endpoint automático é recusado (modo manual)", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    eq((await getRuntimeMode(A)), "manual");
    eq(await code(() => apiTrigger(ctxOf(A.orgId), c.id)), "AUTOMATIC_MODE_DISABLED");
    eq(T.reactivation_attempts.length, 0, "recusa não grava nada");
    const r = await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual", requestedBy: randomUUID() });
    eq([r.attempt.origin, r.attempt.status], ["manual", "requested"]);
  });

  await t("16b) MANUAL fora da janela: pedido é registrado (pendente) mas /pending só entrega dentro da janela", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId, NIGHT), c.id, { origin: "manual" });
    const night = await listPending(ctxOf(A.orgId, NIGHT));
    eq([night.window_open, night.count], [false, 0]);
    const day = await listPending(ctxOf(A.orgId, new Date(NIGHT.getTime() + 14 * 3600_000)));
    eq([day.window_open, day.count], [true, 1]);
  });

  await t("17) AUTOMÁTICO: trigger valida e devolve o evento; fora da janela é barrado", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic" });
    const c = regular(A, "João", 40);
    eq(await code(() => apiTrigger(ctxOf(A.orgId, NIGHT), c.id)), "OUTSIDE_SEND_WINDOW");
    eq(T.reactivation_attempts.length, 0);
    const r = await apiTrigger(ctxOf(A.orgId), c.id);
    eq([r.replay, r.data.event, r.data.attempt.origin, r.data.attempt.status], [false, "reactivation.requested", "automatic", "requested"]);
    eq(r.data.reactivation.habitual_interval_days, 32);
    eq(r.data.reactivation.days_since_last_visit, 40);
    eq((await apiTrigger(ctxOf(A.orgId), c.id)).replay, true, "trigger repetido é idempotente");
    eq(attemptsOf(c.id).length, 1);
  });

  await t("17b) MESMA lógica nos dois modos: as mesmas proteções barram manual e automático", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic" });
    const lucas = regular(A, "Lucas", 35, 60);                  // dentro do ritmo
    const futuro = regular(A, "Futuro", 40); addAppt(A, futuro.id, { status: "confirmed", startDaysAgo: -3, createdDaysAgo: 0 });
    for (const c of [lucas, futuro]) {
      const man = await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" }));
      const aut = await code(() => requestReactivation(ctxOf(A.orgId), c.id, { origin: "automatic" }));
      assert(man !== "NO_ERROR" && man === aut, `${c.name}: manual=${man} automático=${aut}`);
    }
  });

  await t("manual e automático gravam o MESMO tipo de registro e mesmo histórico", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic" });
    const [m, a] = [regular(A, "M"), regular(A, "A")];
    await requestReactivation(ctxOf(A.orgId), m.id, { origin: "manual" });
    await requestReactivation(ctxOf(A.orgId), a.id, { origin: "automatic" });
    const [x, y] = [attemptsOf(m.id)[0], attemptsOf(a.id)[0]];
    eq(Object.keys(x).sort(), Object.keys(y).sort());
    eq([x.origin, y.origin], ["manual", "automatic"]);
    eq((await listPending(ctxOf(A.orgId))).count, 2, "o n8n recebe os dois pelo mesmo endpoint");
  });

  await t("evento do n8n: dados do BarberFlow (snapshot), último serviço/barbeiro e orientação à IA; sem organization_id", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic" });
    const c = regular(A, "João da Silva", 40);
    const r = await apiTrigger(ctxOf(A.orgId), c.id);
    const ev = r.data;
    eq([ev.client.name, ev.client.first_name], ["João da Silva", "João"]);
    assert(/^55\d{10,11}$/.test(ev.client.whatsapp_phone), ev.client.whatsapp_phone);
    eq([ev.last_visit.service_name, ev.last_visit.barber_name], ["Corte", "Carlos"]);
    eq(ev.business.name, "Barbearia A");
    assert(ev.message_context.must_not.some((s: string) => /preço/.test(s)), "orienta a IA a não inventar preço");
    assert(!JSON.stringify(ev).includes(A.orgId), "organization_id não vaza no evento");
  });

  await t("API: candidates traz só elegíveis protegidos, com flags para o automático", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic", daily_limit: 5 });
    regular(A, "João", 40); regular(A, "Lucas", 35, 60);
    const r = await apiCandidates(ctxOf(A.orgId), { limit: undefined });
    eq([r.mode, r.window_open, r.can_trigger_now, r.total_eligible, r.count], ["automatic", true, true, 1, 1]);
    eq(r.candidates[0].client.name, "João");
    eq(r.candidates[0].reactivation.reason, "behavior_due");
    eq((await apiCandidates(ctxOf(A.orgId, NIGHT), { limit: "5" })).can_trigger_now, false);
    eq(await code(() => apiCandidates(ctxOf(A.orgId), { limit: "0" })), "INVALID_INPUT");
    eq(await code(() => apiCandidates(ctxOf(A.orgId), { limit: "abc" })), "INVALID_INPUT");
  });

  await t("API: settings reflete a organização (modo, janela, capacidade)", async () => {
    const { A, B } = reset();
    setSettings(A, { mode: "automatic", daily_limit: 7, margin_percent: 20 });
    const a = await apiSettings(ctxOf(A.orgId)); const b = await apiSettings(ctxOf(B.orgId));
    eq([a.mode, a.daily_limit, a.margin_percent, a.capacity.remaining], ["automatic", 7, 20, 7]);
    eq([b.mode, b.daily_limit, b.margin_percent], ["manual", 20, 15], "B sem linha: padrões");
    eq(a.send_window, { start: "09:00", end: "19:00", timezone: TZ, open_now: true });
  });

  await t("API: sent/responded/failed/opt-out com resposta padronizada e idempotência", async () => {
    const { A } = reset();
    setSettings(A, { mode: "automatic" });
    const c = regular(A, "João", 40);
    await apiTrigger(ctxOf(A.orgId), c.id);
    const s1 = await apiSent(ctxOf(A.orgId), c.id);
    eq([s1.attempt.status, s1.idempotent_replay], ["sent", false]);
    eq((await apiSent(ctxOf(A.orgId), c.id)).idempotent_replay, true);
    eq((await apiResponded(ctxOf(A.orgId), c.id)).attempt.status, "responded");
    const o = await apiOptOut(ctxOf(A.orgId), c.id, { note: "pediu para parar", organization_id: randomUUID() });
    eq([o.opted_out, o.idempotent_replay], [true, false]);
    eq(T.reactivation_opt_outs[0].organization_id, A.orgId, "organization_id do body é IGNORADO");
    eq(await code(() => apiFailed(ctxOf(A.orgId), c.id, {})), "INVALID_STATE");
    eq(await code(() => apiOptOut(ctxOf(A.orgId), c.id, { note: 123 })), "INVALID_INPUT");
  });
}
const getRuntimeMode = async (org: any) => (await apiSettings(ctxOf(org.orgId))).mode;

// ================================================================== D. SEGURANÇA / MULTI-TENANT
async function securityTests() {
  section("D. Isolamento por organization_id e autenticação");
  await t("15) org B não vê candidatos, tentativas nem métricas da org A", async () => {
    const { A, B } = reset();
    const ca = regular(A, "João A", 40); regular(B, "João B", 40);
    await requestReactivation(ctxOf(A.orgId), ca.id, { origin: "manual" });
    const ob = await getOverview(ctxOf(B.orgId));
    eq(ob.candidates.map((c) => c.client.name), ["João B"]);
    eq([ob.inProgress.length, ob.metrics.requestedToday, ob.capacity.used], [0, 0, 0]);
    eq((await listPending(ctxOf(B.orgId))).count, 0);
  });

  await t("15b) org B não consegue pedir/alterar/optout de cliente da org A (CLIENT_NOT_FOUND)", async () => {
    const { A, B } = reset();
    const ca = regular(A, "João A", 40);
    await requestReactivation(ctxOf(A.orgId), ca.id, { origin: "manual" });
    for (const fn of [
      () => requestReactivation(ctxOf(B.orgId), ca.id, { origin: "manual" }),
      () => markSent(ctxOf(B.orgId), ca.id), () => markResponded(ctxOf(B.orgId), ca.id), () => markFailed(ctxOf(B.orgId), ca.id, "x"),
      () => recordOptOut(ctxOf(B.orgId), ca.id), () => dismissCandidate(ctxOf(B.orgId), ca.id),
    ]) eq(await code(fn), "CLIENT_NOT_FOUND");
    eq(attemptsOf(ca.id)[0].status, "requested", "tentativa da A intacta");
    eq(T.reactivation_opt_outs.length, 0);
  });

  await t("15c) org B não cancela tentativa da org A", async () => {
    const { A, B } = reset();
    const ca = regular(A, "João A", 40);
    const r = await requestReactivation(ctxOf(A.orgId), ca.id, { origin: "manual" });
    eq(await code(() => cancelRequest(ctxOf(B.orgId), r.attempt.id)), "NOT_FOUND");
    eq(attemptsOf(ca.id)[0].status, "requested");
  });

  await t("15d) reconcile de uma org não toca nas tentativas da outra", async () => {
    const { A, B } = reset();
    const ca = regular(A, "João A", 40);
    await requestReactivation(ctxOf(A.orgId), ca.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), ca.id);
    const old = JSON.stringify(T.reactivation_attempts);
    await reconcileOutcomes(ctxOf(B.orgId, new Date(NOW.getTime() + 60 * DAY)));
    eq(JSON.stringify(T.reactivation_attempts), old);
  });

  await t("15e) configurações e limite diário são por organização", async () => {
    const { A, B } = reset();
    setSettings(A, { mode: "automatic", daily_limit: 1 });
    const [a1, a2, b1, b2] = [regular(A, "A1"), regular(A, "A2"), regular(B, "B1"), regular(B, "B2")];
    await requestReactivation(ctxOf(A.orgId), a1.id, { origin: "automatic" });
    eq(await code(() => requestReactivation(ctxOf(A.orgId), a2.id, { origin: "automatic" })), "DAILY_LIMIT_REACHED");
    eq(await code(() => requestReactivation(ctxOf(B.orgId), b1.id, { origin: "manual" })), "NO_ERROR");
    eq(await code(() => requestReactivation(ctxOf(B.orgId), b2.id, { origin: "automatic" })), "AUTOMATIC_MODE_DISABLED", "B continua manual");
  });

  await t("15f) FK composta emulada: tentativa não pode apontar para cliente de outra organização", async () => {
    const { A, B } = reset();
    const ca = regular(A, "João A", 40);
    const r = await db.from("reactivation_attempts").insert({ organization_id: B.orgId, client_id: ca.id, origin: "manual" });
    eq(r.error?.code, "23503");
  });

  await t("autenticação: toda rota nova responde 401 sem token válido (token só no header Bearer)", async () => {
    const routes = [
      ["settings", "GET"], ["candidates", "GET"], ["pending", "GET"],
      ["x/trigger", "POST"], ["x/sent", "POST"], ["x/failed", "POST"], ["x/responded", "POST"], ["x/opt-out", "POST"],
    ];
    const id = randomUUID();
    for (const [path, method] of routes) {
      const dir = path.startsWith("x/") ? `[clientId]/${path.slice(2)}` : path;
      const mod = await import(`../src/app/api/integration/reactivation/${dir}/route`);
      const h = mod[method];
      assert(typeof h === "function", `${path}: handler ${method} ausente`);
      const url = `http://localhost/api/integration/reactivation/${path.replace("x", id)}?organization_id=${randomUUID()}`;
      for (const headers of [{}, { authorization: "Bearer lixo" }, { authorization: `Bearer bf_live_${"a".repeat(63)}` }, { "x-organization-id": randomUUID() }]) {
        const res = await h(new Request(url, { method, headers }), { params: Promise.resolve({ clientId: id }) });
        const body = await res.json();
        eq([res.status, body.success, body.error], [401, false, "UNAUTHORIZED"], `${method} ${path}`);
      }
      // token na query string nunca é aceito
      const q = await h(new Request(`${url}&token=bf_live_${"a".repeat(64)}`, { method }), { params: Promise.resolve({ clientId: id }) });
      eq(q.status, 401);
    }
  });

  await t("configurações: validação no servidor (mín. 2 atendimentos, janela coerente, limites)", () => {
    const base = { ...{ mode: "manual", marginPercent: 15, minVisits: 3, windowStart: "09:00", windowEnd: "19:00", dailyLimit: 20,
      minDaysBetweenAttempts: 30, maxAttempts: 3, blockFutureAppointment: true, attributionDays: 14 } };
    eq(validateReactivationSettings(base).ok, true);
    eq(validateReactivationSettings({ ...base, minVisits: 2 }).ok, true, "permite reduzir para 2");
    eq(validateReactivationSettings({ ...base, minVisits: 1 }).ok, false, "1 atendimento nunca basta");
    eq(validateReactivationSettings({ ...base, mode: "x" }).ok, false);
    eq(validateReactivationSettings({ ...base, windowStart: "19:00", windowEnd: "09:00" }).ok, false);
    eq(validateReactivationSettings({ ...base, windowStart: "25:00" }).ok, false);
    eq(validateReactivationSettings({ ...base, dailyLimit: 0 }).ok, false);
    eq(validateReactivationSettings({ ...base, marginPercent: 101 }).ok, false);
    eq(validateReactivationSettings({ ...base, marginPercent: "15" }).ok, true, "aceita número em texto (formulário)");
    eq(validateReactivationSettings({ ...base, blockFutureAppointment: "sim" }).ok, false);
    eq(validateReactivationSettings(null).ok, false);
  });
}

// ================================================================== E. PERSISTÊNCIA
async function persistenceTests() {
  section("E. Persistência e recarga (nível service/banco; NÃO é teste de navegador)");
  await t("18) configurações persistem e voltam iguais por contexto novo; sem linha = padrões aprovados", async () => {
    const { A } = reset();
    eq(await loadReactivationSettings(db, A.orgId), DEFAULT_REACTIVATION_SETTINGS);
    const novo = { mode: "automatic", marginPercent: 20, minVisits: 2, windowStart: "08:30", windowEnd: "18:00", dailyLimit: 10,
      minDaysBetweenAttempts: 21, maxAttempts: 2, blockFutureAppointment: false, attributionDays: 10 };
    await saveReactivationSettings(db, A.orgId, novo);
    await saveReactivationSettings(db, A.orgId, novo); // upsert não duplica
    eq(T.reactivation_settings.length, 1);
    eq(await loadReactivationSettings(db, A.orgId), novo);
  });

  await t("padrões aprovados: mín. 3, margem 15%, 20/dia, 30 dias, 3 tentativas, 09:00–19:00, manual", () => {
    const d = DEFAULT_REACTIVATION_SETTINGS;
    eq([d.minVisits, d.marginPercent, d.dailyLimit, d.minDaysBetweenAttempts, d.maxAttempts, d.windowStart, d.windowEnd, d.mode],
      [3, 15, 20, 30, 3, "09:00", "19:00", "manual"]);
  });

  await t("18b) tentativa persiste com todos os campos e sobrevive a um novo contexto", async () => {
    const { A } = reset();
    const c = regular(A, "João", 40);
    await requestReactivation(ctxOf(A.orgId), c.id, { origin: "manual" });
    await markSent(ctxOf(A.orgId), c.id);
    const fresh = await getOverview(ctxOf(A.orgId));
    eq(fresh.inProgress.map((i) => [i.client.name, i.state]), [["João", "sent"]]);
    eq(fresh.candidates.length, 0, "já está em andamento: não aparece duas vezes");
  });

  await t("19) 'recarregar' (nível service): reavaliar do zero dá exatamente o mesmo resultado", async () => {
    const { A } = reset();
    const c1 = regular(A, "João", 40); regular(A, "Pedro", 45, 30); regular(A, "Lucas", 35, 60);
    await requestReactivation(ctxOf(A.orgId), c1.id, { origin: "manual" });
    const a = await getOverview(ctxOf(A.orgId));
    const b = await getOverview(ctxOf(A.orgId));
    eq(JSON.stringify(a), JSON.stringify(b));
    eq(a.candidates.map((c) => c.client.name), ["Pedro"]);
  });

  await t("candidatos ordenados pelo maior atraso e desempate por nome", async () => {
    const { A } = reset();
    regular(A, "Zeca", 50, 30); regular(A, "Ana", 45, 30); regular(A, "Bia", 45, 30);
    eq((await getOverview(ctxOf(A.orgId))).candidates.map((c) => c.client.name), ["Zeca", "Ana", "Bia"]);
  });

  skip("19) reload no NAVEGADOR (F5 na tela do Dashboard/Configurações)", "exige navegador + Supabase real; não executável neste ambiente. Verificar manualmente (CONTEXT.md, checklist).");
  skip("20) mobile (layout em celular)", "exige navegador/dispositivo; não executável neste ambiente. Apenas as classes responsivas foram revisadas em código (CONTEXT.md).");
}

(async () => {
  await behaviorTests();
  await serviceTests();
  await modeTests();
  await securityTests();
  await persistenceTests();
  console.log(`\nResultado: ${pass} ok, ${failCount} falhas, ${skipped} não verificáveis neste ambiente (skip)`);
  if (failCount) { console.log("Falhas:\n - " + failures.join("\n - ")); process.exit(1); }
})();
